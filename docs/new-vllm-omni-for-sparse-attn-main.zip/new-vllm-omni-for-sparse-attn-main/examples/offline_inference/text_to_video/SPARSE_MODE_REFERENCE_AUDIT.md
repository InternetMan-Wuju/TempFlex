# Sparse Mode Reference Audit

This note records the reference-code check for the Wan real-QKV sparse-mask
profiling modes that are adapted to the FlashInfer per-head BSA kernel.

## Reference Repositories

| Mode | Reference path | Commit |
| --- | --- | --- |
| LongCat-Video | `/data/daizijian/daizijian/LongCat-Video` | `8334da9343fcf9bc8156a35d1df19d4cdfa98615` |
| VMoBA | `/data/daizijian/daizijian/VMoBA` | `48aaccd4f14c5adb7db961058bfbb2113e392003` |
| MInference | `/data/daizijian/daizijian/MInference` | `a4eb395f949ea39e871f9bc586d683390692c6be` |
| FlexPrefill | `/data/daizijian/daizijian/FlexPrefill` | `a24b27bf117fd6ad4ba34b0db82c598e7786fd59` |

## Experiment Contract

The NCU sweeps intentionally profile one common backend:

- Real Wan QKV dump, not synthetic tensors.
- Non-causal `(H, MB, NB)` block masks.
- `block_m = block_n = 128` for the new-mode sweep.
- FlashInfer per-head BSA kernel, observed by NCU as
  `BatchPrefillWithPagedKVCacheKernel`.

Therefore, these modes should be described as reference-inspired mask builders
running on FlashInfer BSA, not as the original libraries' end-to-end kernels.

## LongCat

Reference implementation:

- `longcat_video/block_sparse_attention/bsa_interface.py`
- `flash_attn_bsa_3d` first rearranges THW tokens into 3D blocks with default
  `chunk_3d_shape_q = chunk_3d_shape_k = [4, 4, 8]`.
- It computes block means, block QK scores, then uses CDF selection through
  `torch.searchsorted(cdf, cdf_threshold, right=True)`.
- It calls LongCat's Triton `flash_attn_bsa` kernel.

Current profiling implementation:

- `longcat_cdf` in `build_sparse_param_profile_inputs.py` uses the same
  block-mean QK softmax CDF rule and has been aligned to the reference
  `searchsorted(..., right=True)` count.
- The offline profile path does not apply LongCat's THW-to-3D token reorder and
  does not run the LongCat Triton kernel. It produces a LongCat-style CDF mask
  and sends that mask to FlashInfer BSA.

Recommended label: `LongCat-style CDF mask + FlashInfer BSA`.

## VMoBA

Reference implementation:

- `src/vmoba.py`
- VMoBA computes a token-level gate with shape `(chunk, head, seq)`.
- Threshold mode supports `query_head`, `block`, `overall`, and `head_global`.
- In `query_head`, it min-max normalizes gate values across chunks for each
  `(head, query)`, accounts for self-chunk contribution, selects extra chunks
  to reach `simsum_threshold`, then removes self chunks from the MoBA branch.
- The final output is a mixed dense self-attention branch plus MoBA varlen
  FlashAttention branch with LSE correction.

Current profiling implementation:

- `vmoba_thr` implements a block-level `query_head`-style gate:
  block-mean Q/K, per-row min-max normalization, cumulative threshold
  selection, and forced diagonal.
- It does not implement the token-level gate, VMoBA's self-branch removal, LSE
  mixing, or alternate threshold types.
- It profiles the resulting block mask with FlashInfer BSA.

Recommended label: `VMoBA-style query-head threshold mask + FlashInfer BSA`.

## MInference Vertical/Slash

Reference implementation:

- `minference/modules/minference_forward.py`
- The vertical/slash pattern is derived from the last 64 query tokens under a
  causal mask.
- MInference uses fixed per-head pattern parameters from model configs, such as
  `(vertical_size, slash_size)`, and executes specialized sparse attention
  kernels.

Current profiling implementation:

- `minference_vs` is a non-causal adapter for Wan self-attention.
- `budget_ratio` is interpreted as a total block budget. The budget is split as
  20% vertical columns and 80% slash offsets.
- Vertical columns are broadcast to all query rows.
- Slash offsets are expanded in both positive and negative directions to match
  the non-causal experiment contract.
- Diagonal blocks are forced and the resulting mask is profiled with FlashInfer
  BSA.

Recommended label: `MInference-style vertical/slash mask + FlashInfer BSA`.

## FlexPrefill

Reference implementation:

- `flex_prefill/ops/flex_prefill_attention.py`
- `get_active_blocks` uses last-block causal QK attention to derive vertical
  and slash scores.
- `gamma` is an attention-coverage target; `min_budget` and `max_budget` are
  token budgets converted to block budgets.
- Heads with JS divergence below `tau` fall back to a block-sparse top-k path.
- The original path runs FlexPrefill/Triton kernels.

Current profiling implementation:

- `flexprefill` is a non-causal adapter.
- It uses last-query attention without causal triangular pruning, maps `gamma`
  to adaptive vertical/slash block budgets, applies `tau`-based fallback using
  full block QK CDF selection, forces diagonal blocks, and profiles the mask
  with FlashInfer BSA.

Recommended label: `FlexPrefill-style active-block mask + FlashInfer BSA`.

## Test Coverage

The focused validation for this commit checks:

- Python compilation for the runtime backend, shared builders, and profile
  scripts.
- Builder smoke on real Wan QKV for `longcat_cdf`, `vmoba_thr`,
  `minference_vs`, and `flexprefill`.
- Mask shape `(12, MB, NB)`, `int32` dtype, nonzero density in `(0, 1]`, and
  diagonal coverage for the modes that explicitly force diagonal blocks.
- LongCat CDF count parity with the reference `searchsorted(..., right=True)`
  selection rule on a small real-QKV slice.
