#!/usr/bin/env python3
"""Analyze NCU-calibrated sparse row-reorder gains.

This reads the benchmark logs produced by ``ncu_xattn_qkv_reorder.py`` and the
NCU report summary CSVs generated from the corresponding ``.ncu-rep`` files.
It is intentionally offline analysis tooling: production reorder paths should
not depend on NCU.

The main purpose is to separate three questions that otherwise get mixed:

  1. Is any reorder worth doing versus no_reorder?
  2. Which candidate reorder has the lowest DRAM read for this mask family?
  3. How many FA4 calls are needed to amortize the reorder permutation cost?
"""

import argparse
import csv
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path


RESULT_FIELDS = [
    "dump",
    "threshold",
    "method",
    "density",
    "avg_nnz_per_row",
    "reorder_ms",
    "mask_ms",
    "kernel_ms",
    "dram_read",
    "dram_write",
    "l2_hit",
    "wave_nnz_cv",
    "wave_nnz_range",
    "wave_reuse",
]


def _float(value, default=math.nan):
    try:
        if value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _rank(values):
    pairs = sorted((value, idx) for idx, value in enumerate(values))
    out = [0.0] * len(values)
    i = 0
    while i < len(pairs):
        j = i + 1
        while j < len(pairs) and pairs[j][0] == pairs[i][0]:
            j += 1
        avg_rank = (i + j - 1) / 2.0
        for _, idx in pairs[i:j]:
            out[idx] = avg_rank
        i = j
    return out


def _pearson(xs, ys):
    if len(xs) < 2:
        return math.nan
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    vx = sum((x - mx) ** 2 for x in xs)
    vy = sum((y - my) ** 2 for y in ys)
    if vx <= 0.0 or vy <= 0.0:
        return math.nan
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / math.sqrt(vx * vy)


def _load_ncu_reports(root):
    reports = {}
    for csv_path in root.rglob("*all_reports.csv"):
        with csv_path.open(newline="") as f:
            for row in csv.DictReader(f):
                report = row.get("report")
                if not report:
                    continue
                reports[report] = {
                    "dram_read_GB": _float(row.get("dram_read_GB")),
                    "dram_write_GB": _float(row.get("dram_write_GB")),
                    "ncu_time_ms": _float(row.get("ncu_time_ms")),
                    "ncu_summary_csv": str(csv_path),
                }
    return reports


def _parse_log(log_path, ncu_reports):
    text = log_path.read_text(errors="ignore")
    result = None
    for line in text.splitlines():
        if line.startswith("RESULT_CSV,"):
            result = line.strip().split(",", 1)[1]
    if result is None:
        return None

    values = next(csv.reader([result]))
    if len(values) < len(RESULT_FIELDS):
        return None
    row = dict(zip(RESULT_FIELDS, values))

    match = re.search(r"Report: .*?/([^/]+\.ncu-rep)", text)
    report = match.group(1) if match else ""
    ncu = ncu_reports.get(report, {})

    parsed = {
        "log": str(log_path),
        "report": report,
        "dump": row["dump"],
        "threshold": _float(row["threshold"]),
        "method": row["method"],
        "density": _float(row["density"]),
        "avg_nnz_per_row": _float(row["avg_nnz_per_row"]),
        "reorder_ms": _float(row["reorder_ms"]),
        "mask_ms": _float(row["mask_ms"]),
        "kernel_ms": _float(row["kernel_ms"]),
        "wave_nnz_cv": _float(row["wave_nnz_cv"]),
        "wave_nnz_range": _float(row["wave_nnz_range"]),
        "wave_reuse": _float(row["wave_reuse"]),
        "dram_read_GB": ncu.get("dram_read_GB", _float(row["dram_read"])),
        "dram_write_GB": ncu.get("dram_write_GB", _float(row["dram_write"])),
        "ncu_time_ms": ncu.get("ncu_time_ms", math.nan),
    }
    if math.isnan(parsed["dram_read_GB"]):
        return None
    return parsed


def load_rows(root):
    ncu_reports = _load_ncu_reports(root)
    rows = []
    for log_path in sorted(root.rglob("*.log")):
        row = _parse_log(log_path, ncu_reports)
        if row is not None:
            rows.append(row)
    return rows


def group_cases(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["dump"], row["threshold"])].append(row)
    return grouped


def case_summary(grouped):
    summaries = []
    for (dump, threshold), rows in sorted(grouped.items()):
        baseline_rows = [r for r in rows if r["method"] == "no_reorder"]
        if not baseline_rows:
            continue
        baseline = min(baseline_rows, key=lambda r: r["dram_read_GB"])
        best = min(rows, key=lambda r: r["dram_read_GB"])
        kernel_saved_ms = baseline["kernel_ms"] - best["kernel_ms"]
        ncu_saved_ms = baseline["ncu_time_ms"] - best["ncu_time_ms"]
        break_even_iters = (
            best["reorder_ms"] / kernel_saved_ms if kernel_saved_ms > 0.0 else math.inf
        )
        ncu_break_even_iters = (
            best["reorder_ms"] / ncu_saved_ms
            if ncu_saved_ms > 0.0 and not math.isnan(ncu_saved_ms)
            else math.inf
        )
        dram_gain = 1.0 - best["dram_read_GB"] / baseline["dram_read_GB"]
        kernel_gain = (
            1.0 - best["kernel_ms"] / baseline["kernel_ms"]
            if baseline["kernel_ms"] > 0.0
            else math.nan
        )
        ncu_time_gain = (
            1.0 - best["ncu_time_ms"] / baseline["ncu_time_ms"]
            if baseline["ncu_time_ms"] > 0.0
            and not math.isnan(baseline["ncu_time_ms"])
            and not math.isnan(best["ncu_time_ms"])
            else math.nan
        )
        kernel_per_dram_gain = (
            kernel_gain / dram_gain if dram_gain > 0.0 and not math.isnan(kernel_gain) else math.nan
        )
        ncu_time_per_dram_gain = (
            ncu_time_gain / dram_gain
            if dram_gain > 0.0 and not math.isnan(ncu_time_gain)
            else math.nan
        )
        summaries.append(
            {
                "dump": dump,
                "threshold": threshold,
                "n_methods": len(rows),
                "density": baseline["density"],
                "avg_nnz_per_row": baseline["avg_nnz_per_row"],
                "baseline_wave_nnz_cv": baseline["wave_nnz_cv"],
                "baseline_wave_nnz_range": baseline["wave_nnz_range"],
                "baseline_wave_reuse": baseline["wave_reuse"],
                "baseline_dram_read_GB": baseline["dram_read_GB"],
                "baseline_kernel_ms": baseline["kernel_ms"],
                "best_method": best["method"],
                "best_dram_read_GB": best["dram_read_GB"],
                "best_kernel_ms": best["kernel_ms"],
                "baseline_ncu_time_ms": baseline["ncu_time_ms"],
                "best_ncu_time_ms": best["ncu_time_ms"],
                "best_reorder_ms": best["reorder_ms"],
                "dram_gain": dram_gain,
                "kernel_gain": kernel_gain,
                "ncu_time_gain": ncu_time_gain,
                "kernel_per_dram_gain": kernel_per_dram_gain,
                "ncu_time_per_dram_gain": ncu_time_per_dram_gain,
                "kernel_saved_ms": kernel_saved_ms,
                "ncu_saved_ms": ncu_saved_ms,
                "break_even_iters": break_even_iters,
                "ncu_break_even_iters": ncu_break_even_iters,
            }
        )
    return summaries


def print_case_summary(summaries):
    print("\nCASE BESTS")
    for row in summaries:
        print(
            f"{row['dump']:28s} thr={row['threshold']:<4g} "
            f"dens={row['density']:.3f} cv0={row['baseline_wave_nnz_cv']:.3f} "
            f"reuse0={row['baseline_wave_reuse']:.3f} "
            f"dram_gain={100 * row['dram_gain']:.1f}% "
            f"kernel_gain={100 * row['kernel_gain']:.1f}% "
            f"sens={row['kernel_per_dram_gain']:.2f} "
            f"breakeven={row['break_even_iters']:.1f}x "
            f"best={row['best_method']}"
        )


def print_feature_correlations(summaries):
    features = [
        "density",
        "avg_nnz_per_row",
        "baseline_wave_nnz_cv",
        "baseline_wave_nnz_range",
        "baseline_wave_reuse",
    ]
    targets = [
        "dram_gain",
        "kernel_gain",
        "ncu_time_gain",
        "kernel_per_dram_gain",
        "break_even_iters",
    ]
    print(f"\nBASE FEATURE CORRELATIONS (n={len(summaries)})")
    for target in targets:
        filtered = [
            row
            for row in summaries
            if not math.isnan(row[target]) and not math.isinf(row[target])
        ]
        print(f"{target}:")
        for feature in features:
            xs = [row[feature] for row in filtered]
            ys = [row[target] for row in filtered]
            print(
                f"  {feature:24s} pear={_pearson(xs, ys):+.3f} "
                f"spear={_pearson(_rank(xs), _rank(ys)):+.3f}"
            )


def print_method_regret(grouped):
    method_regrets = defaultdict(list)
    method_rel_to_no = defaultdict(list)
    for rows in grouped.values():
        baseline_rows = [r for r in rows if r["method"] == "no_reorder"]
        if not baseline_rows:
            continue
        baseline = min(baseline_rows, key=lambda r: r["dram_read_GB"])
        best = min(rows, key=lambda r: r["dram_read_GB"])
        for row in rows:
            method_rel_to_no[row["method"]].append(
                row["dram_read_GB"] / baseline["dram_read_GB"]
            )
            method_regrets[row["method"]].append(
                row["dram_read_GB"] / best["dram_read_GB"] - 1.0
            )

    print("\nMETHOD DRAM / NO_REORDER")
    for method, values in sorted(
        method_rel_to_no.items(), key=lambda item: statistics.median(item[1])
    ):
        if len(values) < 3:
            continue
        print(
            f"{method:45s} med={statistics.median(values):.3f} "
            f"mean={sum(values) / len(values):.3f} n={len(values)}"
        )

    print("\nMETHOD REGRET VS BEST")
    for method, values in sorted(
        method_regrets.items(), key=lambda item: statistics.median(item[1])
    ):
        if len(values) < 3:
            continue
        print(
            f"{method:45s} med={100 * statistics.median(values):5.1f}% "
            f"max={100 * max(values):5.1f}% n={len(values)}"
        )


def write_case_csv(path, summaries):
    fieldnames = [
        "dump",
        "threshold",
        "n_methods",
        "density",
        "avg_nnz_per_row",
        "baseline_wave_nnz_cv",
        "baseline_wave_nnz_range",
        "baseline_wave_reuse",
        "baseline_dram_read_GB",
        "baseline_kernel_ms",
        "baseline_ncu_time_ms",
        "best_method",
        "best_dram_read_GB",
        "best_kernel_ms",
        "best_ncu_time_ms",
        "best_reorder_ms",
        "dram_gain",
        "kernel_gain",
        "ncu_time_gain",
        "kernel_per_dram_gain",
        "ncu_time_per_dram_gain",
        "kernel_saved_ms",
        "ncu_saved_ms",
        "break_even_iters",
        "ncu_break_even_iters",
    ]
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summaries)


def normalized_points(grouped):
    points = []
    for (dump, threshold), rows in sorted(grouped.items()):
        baseline_rows = [r for r in rows if r["method"] == "no_reorder"]
        if not baseline_rows:
            continue
        baseline = min(baseline_rows, key=lambda r: r["dram_read_GB"])
        for row in rows:
            if row["method"] == "no_reorder":
                continue
            if baseline["dram_read_GB"] <= 0.0 or baseline["kernel_ms"] <= 0.0:
                continue
            points.append(
                {
                    "case": f"{dump} thr={threshold:g}",
                    "dump": dump,
                    "threshold": threshold,
                    "method": row["method"],
                    "dram_ratio": row["dram_read_GB"] / baseline["dram_read_GB"],
                    "kernel_ratio": row["kernel_ms"] / baseline["kernel_ms"],
                    "ncu_time_ratio": (
                        row["ncu_time_ms"] / baseline["ncu_time_ms"]
                        if baseline["ncu_time_ms"] > 0.0
                        and not math.isnan(row["ncu_time_ms"])
                        and not math.isnan(baseline["ncu_time_ms"])
                        else math.nan
                    ),
                }
            )
    return points


def write_plots(plot_dir, grouped):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plot_dir.mkdir(parents=True, exist_ok=True)
    points = normalized_points(grouped)
    if not points:
        return

    xs = [p["dram_ratio"] for p in points]
    ys = [p["kernel_ratio"] for p in points]
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    vx = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / vx
    intercept = my - slope * mx
    floors = [(y - x) / (1.0 - x) for x, y in zip(xs, ys) if x < 0.98]
    median_floor = statistics.median(floors)

    plt.figure(figsize=(8.0, 5.4), dpi=160)
    seen = set()
    for p in points:
        family = p["dump"].replace("output_ltx_", "ltx_")
        label = family if family not in seen else None
        seen.add(family)
        plt.scatter(
            p["dram_ratio"],
            p["kernel_ratio"],
            s=26,
            alpha=0.72,
            label=label,
            edgecolors="none",
        )
    line_x = [0.0, 1.0]
    plt.plot(
        line_x,
        [intercept + slope * x for x in line_x],
        color="black",
        linewidth=2.0,
        label=f"linear fit: y={intercept:.2f}+{slope:.2f}x",
    )
    plt.plot(
        line_x,
        [median_floor + (1.0 - median_floor) * x for x in line_x],
        color="#c43c39",
        linestyle="--",
        linewidth=2.0,
        label=f"Amdahl floor fit: floor={median_floor:.2f}",
    )
    plt.axvspan(0.15, 0.25, color="#7aa6c2", alpha=0.14, label="dense low-DRAM cluster")
    plt.xlabel("DRAM read / no_reorder")
    plt.ylabel("Kernel time / no_reorder")
    plt.title("Sparse Reorder: DRAM Reduction vs Kernel-Time Reduction")
    plt.xlim(0.0, 1.02)
    plt.ylim(0.75, 1.02)
    plt.grid(True, alpha=0.25)
    plt.legend(loc="lower right", fontsize=7, frameon=True)
    plt.tight_layout()
    scatter_path = plot_dir / "dram_vs_kernel_ratio.png"
    plt.savefig(scatter_path)
    plt.close()

    bins = [(0.0, 0.15), (0.15, 0.25), (0.25, 0.40), (0.40, 0.70), (0.70, 1.01)]
    labels = [f"{lo:.2f}-{hi:.2f}" for lo, hi in bins]
    grouped_y = [
        [p["kernel_ratio"] for p in points if lo <= p["dram_ratio"] < hi]
        for lo, hi in bins
    ]
    plt.figure(figsize=(8.0, 4.8), dpi=160)
    plt.boxplot(
        grouped_y,
        labels=labels,
        showfliers=False,
        patch_artist=True,
        boxprops={"facecolor": "#d9e8f5", "edgecolor": "#376c8a"},
        medianprops={"color": "#c43c39", "linewidth": 2.0},
    )
    for i, values in enumerate(grouped_y, start=1):
        if not values:
            continue
        jitter = [i + (j % 7 - 3) * 0.018 for j in range(len(values))]
        plt.scatter(jitter, values, s=18, alpha=0.55, color="#2f5d73", edgecolors="none")
        plt.text(i, max(values) + 0.006, f"n={len(values)}", ha="center", va="bottom", fontsize=8)
    plt.xlabel("DRAM read / no_reorder bin")
    plt.ylabel("Kernel time / no_reorder")
    plt.title("Kernel-Time Weak Sensitivity After DRAM Read Is Reduced")
    plt.ylim(0.78, 1.01)
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    bins_path = plot_dir / "kernel_ratio_by_dram_bin.png"
    plt.savefig(bins_path)
    plt.close()

    print(f"\nWrote plots:\n  {scatter_path}\n  {bins_path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("examples/offline_inference/text_to_video"),
        help="Directory containing ncu_*_profiles subdirectories",
    )
    parser.add_argument(
        "--case-csv",
        type=Path,
        default=None,
        help="Optional output CSV for per-case best/gain summaries",
    )
    parser.add_argument(
        "--plot-dir",
        type=Path,
        default=None,
        help="Optional output directory for normalized DRAM/time plots",
    )
    args = parser.parse_args()

    rows = load_rows(args.root)
    grouped = group_cases(rows)
    summaries = case_summary(grouped)

    print(f"Loaded {len(rows)} profiled runs across {len(grouped)} cases")
    print_case_summary(summaries)
    print_feature_correlations(summaries)
    print_method_regret(grouped)

    if args.case_csv is not None:
        write_case_csv(args.case_csv, summaries)
        print(f"\nWrote {args.case_csv}")
    if args.plot_dir is not None:
        write_plots(args.plot_dir, grouped)


if __name__ == "__main__":
    main()
