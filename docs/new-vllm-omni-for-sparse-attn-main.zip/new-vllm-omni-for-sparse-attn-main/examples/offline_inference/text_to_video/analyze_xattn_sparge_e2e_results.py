#!/usr/bin/env python3
"""Aggregate xattn/sparge reorder E2E benchmark logs.

The Wan2.2 A14B path prints one MY_LOG/MFU block per transformer stage.  This
parser sums timing counters across all blocks in a log before comparing modes.
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable


LOG_RE = re.compile(
    r"vllm_(?P<sparse>[^_]+)_(?P<mode>.+)_thr(?P<thr>[^_]+)_f(?P<frames>\d+)\.log"
)


@dataclass
class Row:
    sparse: str
    mode: str
    threshold: str
    frames: int
    tp: int | None
    length: int | None
    blocks: int | None
    density: float | None
    sparse_ms: float | None
    reorder_ms: float | None
    algo_ms: float | None
    q_gather_ms: float | None
    metadata_ms: float | None
    kernel_ms: float | None
    oshuffle_ms: float | None
    count: int | None
    total_ms: float | None
    log: str


def _sum(pattern: str, text: str, cast=float):
    values = re.findall(pattern, text)
    if not values:
        return None
    return sum(cast(v.replace(",", "")) for v in values)


def _first(pattern: str, text: str, cast=int):
    match = re.search(pattern, text)
    if not match:
        return None
    return cast(match.group(1).replace(",", ""))


def parse_log(path: str) -> Row | None:
    match = LOG_RE.match(os.path.basename(path))
    if not match:
        return None
    text = open(path, errors="ignore").read()
    sparse_ms = _sum(r"总计稀疏 \(Sparse\):\s+([0-9.]+) ms", text)
    reorder_ms = _sum(r"总计重排 \(Reorder\):\s+([0-9.]+) ms", text)
    kernel_ms = _sum(r"总计算子 \(Pure Attn\):\s+([0-9.]+) ms", text)
    oshuffle_ms = _sum(r"总计O_shuffle \(O_shuffle\):\s+([0-9.]+) ms", text)
    if kernel_ms is None:
        return None

    densities = [float(x) for x in re.findall(r"\[MFU\] Avg block density:\s+([0-9.]+)", text)]
    total_ms = sum(x or 0.0 for x in (sparse_ms, reorder_ms, kernel_ms, oshuffle_ms))
    return Row(
        sparse=match.group("sparse"),
        mode=match.group("mode"),
        threshold=match.group("thr"),
        frames=int(match.group("frames")),
        tp=_first(r"\[SPARSE_SHAPE\].*?tp=([0-9]+)", text),
        length=_first(r"\[SPARSE_SHAPE\].*?L_orig=([0-9]+)", text),
        blocks=_first(r"\[SPARSE_SHAPE\].*?blocks=\(([0-9]+),", text),
        density=sum(densities) / len(densities) if densities else None,
        sparse_ms=sparse_ms,
        reorder_ms=reorder_ms,
        algo_ms=_sum(r"├─ algo:\s+([0-9.]+) ms", text),
        q_gather_ms=_sum(r"├─ Q_gather:\s+([0-9.]+) ms", text),
        metadata_ms=_sum(r"├─ sparse:\s+([0-9.]+) ms", text),
        kernel_ms=kernel_ms,
        oshuffle_ms=oshuffle_ms,
        count=_sum(r"总计count\s+([0-9]+)", text, int),
        total_ms=total_ms,
        log=path,
    )


def collect(patterns: Iterable[str]) -> list[Row]:
    rows: list[Row] = []
    for pattern in patterns:
        for path in glob.glob(pattern):
            row = parse_log(path)
            if row is not None:
                rows.append(row)
    return rows


def add_gains(rows: list[Row]) -> list[dict[str, object]]:
    baselines: dict[tuple[str, str, int], Row] = {}
    for row in rows:
        key = (row.sparse, row.threshold, row.frames)
        if row.mode == "no_reorder":
            old = baselines.get(key)
            if old is None or (row.total_ms or float("inf")) < (old.total_ms or float("inf")):
                baselines[key] = row

    out = []
    for row in rows:
        base = baselines.get((row.sparse, row.threshold, row.frames))
        total_gain = None
        kernel_gain = None
        if base and base.total_ms and row.total_ms:
            total_gain = (base.total_ms - row.total_ms) / base.total_ms * 100.0
        if base and base.kernel_ms and row.kernel_ms:
            kernel_gain = (base.kernel_ms - row.kernel_ms) / base.kernel_ms * 100.0
        item = row.__dict__.copy()
        item["total_gain_pct"] = total_gain
        item["kernel_gain_pct"] = kernel_gain
        item["baseline_log"] = base.log if base else None
        out.append(item)
    return out


def write_csv(path: str, rows: list[dict[str, object]]) -> None:
    fieldnames = [
        "sparse",
        "threshold",
        "frames",
        "tp",
        "length",
        "blocks",
        "density",
        "mode",
        "total_ms",
        "total_gain_pct",
        "kernel_ms",
        "kernel_gain_pct",
        "sparse_ms",
        "reorder_ms",
        "algo_ms",
        "q_gather_ms",
        "metadata_ms",
        "oshuffle_ms",
        "count",
        "log",
    ]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in sorted(rows, key=lambda r: (r["sparse"], str(r["threshold"]), int(r["frames"]), float(r["total_ms"] or 1e30))):
            writer.writerow({k: row.get(k) for k in fieldnames})


def write_markdown(path: str, rows: list[dict[str, object]]) -> None:
    groups: dict[tuple[str, str, int], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        groups[(str(row["sparse"]), str(row["threshold"]), int(row["frames"]))].append(row)

    lines = ["# XAttention/Sparge E2E Reorder Results", ""]
    for key in sorted(groups):
        group = sorted(groups[key], key=lambda r: float(r["total_ms"] or 1e30))
        sparse, threshold, frames = key
        base = next((r for r in group if r["mode"] == "no_reorder"), None)
        length = group[0].get("length")
        density = group[0].get("density")
        lines.append(f"## {sparse} threshold={threshold} frames={frames}")
        lines.append("")
        lines.append(
            f"- L={length}, density={density:.4f}" if isinstance(density, float) else f"- L={length}"
        )
        if base:
            lines.append(f"- baseline total={base['total_ms']:.1f} ms, kernel={base['kernel_ms']:.1f} ms")
        lines.append("")
        lines.append("| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | log |")
        lines.append("|---:|---|---:|---:|---:|---:|---:|---|")
        for idx, row in enumerate(group, start=1):
            total_gain = row.get("total_gain_pct")
            kernel_gain = row.get("kernel_gain_pct")
            lines.append(
                "| "
                f"{idx} | {row['mode']} | {row['total_ms']:.1f} | "
                f"{total_gain:.2f}% | " if isinstance(total_gain, float) else
                f"{idx} | {row['mode']} | {row['total_ms']:.1f} | N/A | "
            )
            lines[-1] += (
                f"{row['kernel_ms']:.1f} | "
                f"{kernel_gain:.2f}% | " if isinstance(kernel_gain, float) else
                f"{row['kernel_ms']:.1f} | N/A | "
            )
            lines[-1] += f"{row['reorder_ms']:.1f} | `{row['log']}` |"
        lines.append("")

    with open(path, "w") as f:
        f.write("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--glob",
        action="append",
        default=["output_xattn_sparge_reorder_e2e_*/*.log"],
        help="Log glob. Can be passed multiple times.",
    )
    parser.add_argument("--csv", default="xattn_sparge_e2e_reorder_results.csv")
    parser.add_argument("--md", default="xattn_sparge_e2e_reorder_results.md")
    parser.add_argument("--max-density", type=float, default=None)
    args = parser.parse_args()

    rows = collect(args.glob)
    if args.max_density is not None:
        rows = [row for row in rows if row.density is None or row.density <= args.max_density]
    rows_with_gains = add_gains(rows)
    write_csv(args.csv, rows_with_gains)
    write_markdown(args.md, rows_with_gains)
    print(f"wrote {args.csv} ({len(rows_with_gains)} rows)")
    print(f"wrote {args.md}")


if __name__ == "__main__":
    main()
