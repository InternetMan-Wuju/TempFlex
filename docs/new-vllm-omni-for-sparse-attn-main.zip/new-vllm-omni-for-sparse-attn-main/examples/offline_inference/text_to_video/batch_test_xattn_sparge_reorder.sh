#!/bin/bash
# End-to-end reorder sweep for generic sparse paths:
#   SPARSE_MODE=xattn and SPARSE_MODE=sparge.
#
# This intentionally stays separate from batch_test.sh / LongCat scripts so the
# generic sparse path can be validated without changing production defaults.

set -u

export CC=/usr/bin/gcc-11
export CXX=/usr/bin/g++-11

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
export PYTHONPATH="$REPO_ROOT:${PYTHONPATH:-}"

# Use separate model defaults because the available tuned Sparge dictionaries
# are for Wan2.1 1.3B (12 heads), while the requested xattn validation is on
# Wan2.2 A14B.
XATTN_MODEL=${XATTN_MODEL:-/data1/dhelix_shared/daizijian/Wan2.2-T2V-A14B-Diffusers}
SPARGE_MODEL=${SPARGE_MODEL:-/data1/dhelix_shared/daizijian/Wan2.1-T2V-1.3B-Diffusers}
MODEL=${MODEL:-}
HEIGHT=${HEIGHT:-1280}
WIDTH=${WIDTH:-720}
STEPS=${STEPS:-4}
TP=${TP:-1}
XATTN_TP=${XATTN_TP:-$TP}
SPARGE_TP=${SPARGE_TP:-$TP}
GUIDANCE_SCALE=${GUIDANCE_SCALE:-1.0}
GUIDANCE_SCALE_HIGH=${GUIDANCE_SCALE_HIGH:-1.0}
FLOW_SHIFT=${FLOW_SHIFT:-12.0}

THRESHOLDS_STR=${THRESHOLDS_STR:-0.7}
FRAMES_LIST_STR=${FRAMES_LIST_STR:-"65 169 305"}
SPARSE_MODES_STR=${SPARSE_MODES_STR:-"xattn sparge"}
XATTN_MODES_STR=${XATTN_MODES_STR:-"no_reorder wave_reorder fiedler_mixed_nnz_reorder spectral_morton_wave_reorder auction_union_reorder_cuda"}
SPARGE_MODES_STR=${SPARGE_MODES_STR:-"no_reorder wave_reorder fiedler_mixed_nnz_reorder spectral_morton_wave_reorder auction_union_reorder_cuda"}
GPU_IDS_STR=${GPU_IDS_STR:-"0 1 2 3 4 5 6 7"}

SPARGE_STATE_DIR=${SPARGE_STATE_DIR:-$SCRIPT_DIR/sparge_model_dict_wan2113_tp1}
TUNE_MODE=${TUNE_MODE:-0}
VLLM_LOGGING_LEVEL=${VLLM_LOGGING_LEVEL:-WARNING}
VLLM_RPC_BASE_PATH=${VLLM_RPC_BASE_PATH:-/tmp}
CACHE_ROOT=${CACHE_ROOT:-/data1/dhelix_shared/daizijian/tmp/runtime_cache}
RUN_TAG=${RUN_TAG:-$(date +%Y%m%d_%H%M%S)}
LOG_DIR=${LOG_DIR:-output_xattn_sparge_reorder_${RUN_TAG}}
OUT_DIR=${OUT_DIR:-output_mp4}
VLLM_DUMP_QKV=${VLLM_DUMP_QKV:-0}
VLLM_DUMP_QKV_LAYER=${VLLM_DUMP_QKV_LAYER:-1}
VLLM_DUMP_QKV_DIR=${VLLM_DUMP_QKV_DIR:-$LOG_DIR/qkv_dump}

export TMPDIR=${TMPDIR:-$CACHE_ROOT/tmp}
export XDG_CACHE_HOME=${XDG_CACHE_HOME:-$CACHE_ROOT/xdg_cache}
export TRITON_CACHE_DIR=${TRITON_CACHE_DIR:-$CACHE_ROOT/triton_cache}
export TORCHINDUCTOR_CACHE_DIR=${TORCHINDUCTOR_CACHE_DIR:-$CACHE_ROOT/torchinductor_cache}
export VLLM_CACHE_ROOT=${VLLM_CACHE_ROOT:-$CACHE_ROOT/vllm_cache}
if [[ -n "${CONDA_PREFIX:-}" && -d "$CONDA_PREFIX/lib" ]]; then
  export LD_LIBRARY_PATH="$CONDA_PREFIX/lib:${LD_LIBRARY_PATH:-}"
fi
export VLLM_LOGGING_LEVEL
export HF_HUB_DISABLE_PROGRESS_BARS=1
export TRANSFORMERS_VERBOSITY=error
export PYTORCH_CUDA_ALLOC_CONF=${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}

read -r -a THRESHOLDS <<< "$THRESHOLDS_STR"
read -r -a FRAMES_LIST <<< "$FRAMES_LIST_STR"
read -r -a SPARSE_MODES <<< "$SPARSE_MODES_STR"
read -r -a XATTN_MODES <<< "$XATTN_MODES_STR"
read -r -a SPARGE_MODES <<< "$SPARGE_MODES_STR"
read -r -a GPU_IDS <<< "$GPU_IDS_STR"

mkdir -p "$TMPDIR" "$XDG_CACHE_HOME" "$TRITON_CACHE_DIR" "$TORCHINDUCTOR_CACHE_DIR" "$VLLM_CACHE_ROOT"
mkdir -p "$LOG_DIR" "$OUT_DIR"

if (( ${#GPU_IDS[@]} < 1 )); then
  echo "[ERROR] Empty GPU_IDS_STR"
  exit 1
fi
if (( XATTN_TP < 1 || SPARGE_TP < 1 )); then
  echo "[ERROR] XATTN_TP and SPARGE_TP must be >= 1. Got XATTN_TP=$XATTN_TP SPARGE_TP=$SPARGE_TP"
  exit 1
fi

kv_order_for_mode() {
  local mode="$1"
  case "$mode" in
    auction_union_reorder_cuda|auction_union_reorder|auction_startfirst|adaptive_elastic_wave_reorder_cuda)
      echo "boundary_dp"
      ;;
    *)
      echo "asc"
      ;;
  esac
}

prepare_mode_spec() {
  local spec="$1"
  MODE_ACTUAL="${spec%%@*}"
  MODE_LABEL="${spec//[^a-zA-Z0-9_.@-]/_}"
  MODE_EXTRA_ENV=()

  if [[ "$spec" == *"@d1m05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=1 VLLM_SPECTRAL_TRIVIAL_MIX=0.5)
  elif [[ "$spec" == *"@d1m075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=1 VLLM_SPECTRAL_TRIVIAL_MIX=0.75)
  elif [[ "$spec" == *"@d2m05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=2 VLLM_SPECTRAL_TRIVIAL_MIX=0.5)
  elif [[ "$spec" == *"@d2m075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=2 VLLM_SPECTRAL_TRIVIAL_MIX=0.75)
  elif [[ "$spec" == *"@d3m05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=3 VLLM_SPECTRAL_TRIVIAL_MIX=0.5)
  elif [[ "$spec" == *"@d3m075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=3 VLLM_SPECTRAL_TRIVIAL_MIX=0.75)
  elif [[ "$spec" == *"@d4m05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=4 VLLM_SPECTRAL_TRIVIAL_MIX=0.5)
  elif [[ "$spec" == *"@d4m075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SPECTRAL_DIM=4 VLLM_SPECTRAL_TRIVIAL_MIX=0.75)
  fi

  if [[ "$spec" == *"@it2"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_FIEDLER_ITERS=2)
  elif [[ "$spec" == *"@it4"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_FIEDLER_ITERS=4)
  elif [[ "$spec" == *"@it6"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_FIEDLER_ITERS=6)
  elif [[ "$spec" == *"@it8"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_FIEDLER_ITERS=8)
  fi

  if [[ "$spec" == *"@cpw4"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CHUNK_PER_WAVE=4)
  elif [[ "$spec" == *"@cpw8"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CHUNK_PER_WAVE=8)
  elif [[ "$spec" == *"@cpw16"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CHUNK_PER_WAVE=16)
  elif [[ "$spec" == *"@cpw32"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CHUNK_PER_WAVE=32)
  fi

  if [[ "$spec" == *"@cw528"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CANDIDATE_WINDOW=528)
  elif [[ "$spec" == *"@cw1056"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CANDIDATE_WINDOW=1056)
  elif [[ "$spec" == *"@cw2112"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_AUCTION_CANDIDATE_WINDOW=2112)
  fi

  if [[ "$spec" == *"@acw132"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_CANDIDATE_WINDOW=132)
  elif [[ "$spec" == *"@acw264"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_CANDIDATE_WINDOW=264)
  elif [[ "$spec" == *"@acw396"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_CANDIDATE_WINDOW=396)
  elif [[ "$spec" == *"@acw528"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_CANDIDATE_WINDOW=528)
  fi

  if [[ "$spec" == *"@aw2"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_WINDOW_WAVES=2)
  elif [[ "$spec" == *"@aw3"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_WINDOW_WAVES=3)
  elif [[ "$spec" == *"@aw4"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_WINDOW_WAVES=4)
  fi

  if [[ "$spec" == *"@amw1"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_MACRO_WAVES=1)
  elif [[ "$spec" == *"@amw2"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_MACRO_WAVES=2)
  elif [[ "$spec" == *"@amw3"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_MACRO_WAVES=3)
  elif [[ "$spec" == *"@amw4"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_MAX_MACRO_WAVES=4)
  fi

  if [[ "$spec" == *"@dm0"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_DIM2_MIX=0.0)
  elif [[ "$spec" == *"@dm025"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_DIM2_MIX=0.25)
  elif [[ "$spec" == *"@dm05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_WAVE_DIM2_MIX=0.5)
  fi

  if [[ "$spec" == *"@ip0"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_POWER=0.0)
  elif [[ "$spec" == *"@ip025"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_POWER=0.25)
  elif [[ "$spec" == *"@ip05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_POWER=0.5)
  elif [[ "$spec" == *"@ip075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_POWER=0.75)
  elif [[ "$spec" == *"@ip1"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_POWER=1.0)
  fi

  if [[ "$spec" == *"@os8"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_STRIDE=8)
  elif [[ "$spec" == *"@os16"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_STRIDE=16)
  elif [[ "$spec" == *"@os32"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_STRIDE=32)
  elif [[ "$spec" == *"@os66"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_STRIDE=66)
  fi

  if [[ "$spec" == *"@tw0"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_TAIL_WEIGHT=0.0)
  elif [[ "$spec" == *"@tw01"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_TAIL_WEIGHT=0.1)
  elif [[ "$spec" == *"@tw02"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_TAIL_WEIGHT=0.2)
  elif [[ "$spec" == *"@tw05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_SLIDING_PHASE_TAIL_WEIGHT=0.5)
  fi

  if [[ "$spec" == *"@pc025035"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_PHASE_LOW_CUT=0.25 VLLM_ADAPTIVE_PHASE_MID_CUT=0.35)
  elif [[ "$spec" == *"@pc030035"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_PHASE_LOW_CUT=0.30 VLLM_ADAPTIVE_PHASE_MID_CUT=0.35)
  elif [[ "$spec" == *"@pc025040"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_ADAPTIVE_PHASE_LOW_CUT=0.25 VLLM_ADAPTIVE_PHASE_MID_CUT=0.40)
  fi

  if [[ "$spec" == *"@b0"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_DEGREE_CORRECTION=0.0)
  elif [[ "$spec" == *"@b025"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_DEGREE_CORRECTION=0.25)
  elif [[ "$spec" == *"@b05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_DEGREE_CORRECTION=0.5)
  elif [[ "$spec" == *"@b075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_DEGREE_CORRECTION=0.75)
  elif [[ "$spec" == *"@b1"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_DEGREE_CORRECTION=1.0)
  fi

  if [[ "$spec" == *"@mix0"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_MIX=0.0)
  elif [[ "$spec" == *"@mix025"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_MIX=0.25)
  elif [[ "$spec" == *"@mix05"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_MIX=0.5)
  elif [[ "$spec" == *"@mix075"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_MIX=0.75)
  elif [[ "$spec" == *"@mix1"* ]]; then
    MODE_EXTRA_ENV+=(VLLM_IDF_MIX=1.0)
  fi
}

sparge_state_exists() {
  local frames="$1"
  local rank
  for ((rank=0; rank<SPARGE_TP; rank++)); do
    local state="$SPARGE_STATE_DIR/wan_saved_state_dict_frame${frames}.rank${rank}.pt"
    [[ -f "$state" ]] || return 1
  done
  return 0
}

tp_for_sparse_mode() {
  local sparse_mode="$1"
  if [[ "$sparse_mode" == "xattn" ]]; then
    echo "$XATTN_TP"
  else
    echo "$SPARGE_TP"
  fi
}

gpu_slice() {
  local start="$1"
  local count="$2"
  local out=""
  local i
  for ((i=0; i<count; i++)); do
    if [[ -n "$out" ]]; then
      out+=","
    fi
    out+="${GPU_IDS[$((start + i))]}"
  done
  echo "$out"
}

TASKS=()
for SPARSE_MODE_ITEM in "${SPARSE_MODES[@]}"; do
  if [[ "$SPARSE_MODE_ITEM" == "xattn" ]]; then
    MODES=("${XATTN_MODES[@]}")
  elif [[ "$SPARSE_MODE_ITEM" == "sparge" ]]; then
    MODES=("${SPARGE_MODES[@]}")
  else
    echo "[ERROR] Unsupported sparse mode: $SPARSE_MODE_ITEM"
    exit 1
  fi
  for FRAMES in "${FRAMES_LIST[@]}"; do
    if [[ "$SPARSE_MODE_ITEM" == "sparge" ]] && ! sparge_state_exists "$FRAMES"; then
      echo "[SKIP] sparge frames=$FRAMES has no tuned state in $SPARGE_STATE_DIR"
      continue
    fi
    for THR in "${THRESHOLDS[@]}"; do
      for MODE in "${MODES[@]}"; do
        TASKS+=("$SPARSE_MODE_ITEM $MODE $THR $FRAMES")
      done
    done
  done
done

echo "[INFO] log_dir=$LOG_DIR"
echo "[INFO] sparse_modes=${SPARSE_MODES[*]} frames=${FRAMES_LIST[*]} thresholds=${THRESHOLDS[*]}"
echo "[INFO] xattn_modes=${XATTN_MODES[*]}"
echo "[INFO] sparge_modes=${SPARGE_MODES[*]}"
echo "[INFO] xattn_model=${XATTN_MODEL}"
echo "[INFO] sparge_model=${SPARGE_MODEL}"
echo "[INFO] sparge_state_dir=$SPARGE_STATE_DIR"
echo "[INFO] steps=$STEPS TP(default)=$TP xattn_tp=$XATTN_TP sparge_tp=$SPARGE_TP GPUs=${GPU_IDS[*]} tasks=${#TASKS[@]}"

CUR=0
while (( CUR < ${#TASKS[@]} )); do
  JOBS=()
  GPU_POS=0
  while (( GPU_POS < ${#GPU_IDS[@]} && CUR < ${#TASKS[@]} )); do
    set -- ${TASKS[$CUR]}
    SPARSE_MODE_ITEM=$1
    MODE_SPEC=$2
    THR=$3
    FRAMES=$4
    prepare_mode_spec "$MODE_SPEC"
    MODE=$MODE_ACTUAL
    TASK_TP=$(tp_for_sparse_mode "$SPARSE_MODE_ITEM")
    if (( GPU_POS + TASK_TP > ${#GPU_IDS[@]} )); then
      break
    fi
    GPUS=$(gpu_slice "$GPU_POS" "$TASK_TP")
    GPU_POS=$((GPU_POS + TASK_TP))
    CUR=$((CUR + 1))
    KV_ORDER=${VLLM_KV_ORDER_OVERRIDE:-$(kv_order_for_mode "$MODE")}
    if [[ -n "$MODEL" ]]; then
      MODEL_FOR_TASK="$MODEL"
    elif [[ "$SPARSE_MODE_ITEM" == "xattn" ]]; then
      MODEL_FOR_TASK="$XATTN_MODEL"
    else
      MODEL_FOR_TASK="$SPARGE_MODEL"
    fi
    OUT="${OUT_DIR}/e2e_${SPARSE_MODE_ITEM}_${MODE_LABEL}_thr${THR}_f${FRAMES}_${RUN_TAG}.mp4"
    LOG="${LOG_DIR}/vllm_${SPARSE_MODE_ITEM}_${MODE_LABEL}_thr${THR}_f${FRAMES}.log"
    echo "[GPU $GPUS] sparse=$SPARSE_MODE_ITEM mode=$MODE_SPEC actual=$MODE tp=$TASK_TP kv=$KV_ORDER thr=$THR frames=$FRAMES model=$MODEL_FOR_TASK -> $LOG"

    env \
      CUDA_VISIBLE_DEVICES=$GPUS \
      TORCH_COMPILE_DISABLE=1 \
      TUNE_MODE=$TUNE_MODE \
      SPARSE_MODE=$SPARSE_MODE_ITEM \
      SPARGE_FRAME=$FRAMES \
      SPARGE_STATE_DIR=$SPARGE_STATE_DIR \
      SPARGE_AUTOTUNE_LOG_LEVEL=${SPARGE_AUTOTUNE_LOG_LEVEL:-0} \
      SPARGE_AUTOTUNE_PRINT_LEVEL=${SPARGE_AUTOTUNE_PRINT_LEVEL:-0} \
      SPARGE_AUTOTUNE_SIM_GRANULARITY=${SPARGE_AUTOTUNE_SIM_GRANULARITY:-4} \
      SPARGE_TUNE_PV=${SPARGE_TUNE_PV:-0} \
      VLLM_THRESHOLD=$THR \
      VLLM_MODE=$MODE \
      VLLM_KV_ORDER=$KV_ORDER \
      VLLM_FRAMES=$FRAMES \
      VLLM_HEIGHT=$HEIGHT \
      VLLM_WIDTH=$WIDTH \
      VLLM_STEPS=$STEPS \
      VLLM_TP=$TASK_TP \
      VLLM_SEQUENCE_START_FIRST=1 \
      VLLM_FIEDLER_ITERS=${VLLM_FIEDLER_ITERS:-8} \
      VLLM_FIEDLER_TRIVIAL_MIX=${VLLM_FIEDLER_TRIVIAL_MIX:-0.5} \
      VLLM_SPECTRAL_DIM=${VLLM_SPECTRAL_DIM:-2} \
      VLLM_SPECTRAL_TRIVIAL_MIX=${VLLM_SPECTRAL_TRIVIAL_MIX:-0.75} \
      VLLM_AUCTION_GROUP_WAVES=${VLLM_AUCTION_GROUP_WAVES:-8} \
      VLLM_AUCTION_CANDIDATE_WINDOW=${VLLM_AUCTION_CANDIDATE_WINDOW:-1056} \
      VLLM_AUCTION_CHUNK_PER_WAVE=${VLLM_AUCTION_CHUNK_PER_WAVE:-adaptive} \
      VLLM_RPC_BASE_PATH=$VLLM_RPC_BASE_PATH \
      VLLM_DUMP_QKV=$VLLM_DUMP_QKV \
      VLLM_DUMP_QKV_LAYER=$VLLM_DUMP_QKV_LAYER \
      VLLM_DUMP_QKV_DIR=$VLLM_DUMP_QKV_DIR \
      LONGCAT_PROFILE=1 \
      "${MODE_EXTRA_ENV[@]}" \
      python "$SCRIPT_DIR/text_to_video.py" \
        --model "$MODEL_FOR_TASK" \
        --prompt "Two anthropomorphic cats in comfy boxing gear and bright gloves fight intensely on a spotlighted stage." \
        --height "$HEIGHT" --width "$WIDTH" --num-frames "$FRAMES" \
        --guidance-scale "$GUIDANCE_SCALE" --guidance-scale-high "$GUIDANCE_SCALE_HIGH" --flow-shift "$FLOW_SHIFT" \
        --num-inference-steps "$STEPS" --tensor-parallel-size "$TASK_TP" --fps 16 --output "$OUT" \
      > "$LOG" 2>&1 &
    JOBS+=("$!")
    sleep 5
  done
  if (( ${#JOBS[@]} == 0 )); then
    set -- ${TASKS[$CUR]}
    TASK_TP=$(tp_for_sparse_mode "$1")
    echo "[ERROR] Not enough GPUs for next task sparse=$1 requires TP=$TASK_TP but only ${#GPU_IDS[@]} GPU IDs are available"
    exit 1
  fi
  for PID in "${JOBS[@]}"; do
    wait "$PID"
  done
done

echo ""
echo "================ XAttention/Sparge Reorder E2E Summary ================"
python - "$LOG_DIR" <<'PY'
import glob
import os
import re
import sys

log_dir = sys.argv[1]

def one(pattern, text, cast=float):
    m = re.search(pattern, text)
    if not m:
        return None
    value = m.group(1).replace(",", "")
    return cast(value)

def total(pattern, text, cast=float):
    values = re.findall(pattern, text)
    if not values:
        return None
    return sum(cast(v.replace(",", "")) for v in values)

rows = []
for path in sorted(glob.glob(os.path.join(log_dir, "*.log"))):
    base = os.path.basename(path)
    m = re.match(r"vllm_(?P<sparse>[^_]+)_(?P<mode>.+)_thr(?P<thr>[^_]+)_f(?P<frames>\d+)\.log", base)
    if not m:
        continue
    text = open(path, errors="ignore").read()
    shape = re.search(
        r"\[SPARSE_SHAPE\].*?L_orig=(\d+) L_padded=(\d+) blocks=\((\d+),(\d+)\).*?H=(\d+) D=(\d+).*?BLK=(\d+)",
        text,
    )
    densities = [float(x) for x in re.findall(r"\[MFU\] Avg block density:\s+([0-9.]+)", text)]
    rows.append({
        "sparse": m.group("sparse"),
        "mode": m.group("mode"),
        "thr": m.group("thr"),
        "frames": int(m.group("frames")),
        "tp": one(r"\[SPARSE_SHAPE\].*?tp=([0-9]+)", text, int),
        "L": int(shape.group(1)) if shape else None,
        "blocks": int(shape.group(3)) if shape else None,
        "density": sum(densities) / len(densities) if densities else None,
        "density_list": ",".join(f"{x:.4f}" for x in densities),
        "sparse_ms": total(r"总计稀疏 \(Sparse\):\s+([0-9.]+) ms", text),
        "reorder_ms": total(r"总计重排 \(Reorder\):\s+([0-9.]+) ms", text),
        "algo_ms": total(r"├─ algo:\s+([0-9.]+) ms", text),
        "q_gather_ms": total(r"├─ Q_gather:\s+([0-9.]+) ms", text),
        "metadata_ms": total(r"├─ sparse:\s+([0-9.]+) ms", text),
        "expand_ms": total(r"└─ expand:\s+([0-9.]+) ms", text),
        "kernel_ms": total(r"总计算子 \(Pure Attn\):\s+([0-9.]+) ms", text),
        "oshuffle_ms": total(r"总计O_shuffle \(O_shuffle\):\s+([0-9.]+) ms", text),
        "count": total(r"总计count\s+([0-9]+)", text, int),
        "log": path,
    })

rows.sort(key=lambda r: (r["sparse"], r["frames"], r["mode"]))
print(
    f"{'sparse':<8} {'frames':>6} {'tp':>3} {'mode':<34} {'L':>9} {'blocks':>7} "
    f"{'dens':>6} {'mask':>9} {'reorder':>9} {'algo':>9} {'qgath':>9} "
    f"{'meta':>9} {'kernel':>10} {'oshuf':>9} {'count':>6}"
)
for r in rows:
    def fmt(x, w=9, p=1):
        if x is None:
            return "N/A".rjust(w)
        return f"{x:.{p}f}".rjust(w)
    dens = "N/A" if r["density"] is None else f"{r['density']:.4f}"
    print(
        f"{r['sparse']:<8} {r['frames']:>6} {str(r['tp'] or 'N/A'):>3} {r['mode']:<34} "
        f"{str(r['L'] or 'N/A'):>9} {str(r['blocks'] or 'N/A'):>7} "
        f"{dens:>6} {fmt(r['sparse_ms'])} {fmt(r['reorder_ms'])} "
        f"{fmt(r['algo_ms'])} {fmt(r['q_gather_ms'])} {fmt(r['metadata_ms'])} "
        f"{fmt(r['kernel_ms'],10)} {fmt(r['oshuffle_ms'])} {str(r['count'] or 'N/A'):>6}"
    )

print("\nSpeedup vs no_reorder by sparse/frame:")
groups = {}
for r in rows:
    groups.setdefault((r["sparse"], r["frames"]), []).append(r)
for key, group in sorted(groups.items()):
    base = next((r for r in group if r["mode"] == "no_reorder"), None)
    if not base or not base["kernel_ms"]:
        continue
    base_total = sum(x or 0.0 for x in (base["sparse_ms"], base["reorder_ms"], base["kernel_ms"], base["oshuffle_ms"]))
    print(f"\n{key[0]} frames={key[1]} baseline_total={base_total:.1f}ms baseline_kernel={base['kernel_ms']:.1f}ms")
    for r in sorted(group, key=lambda x: sum(y or 0.0 for y in (x["sparse_ms"], x["reorder_ms"], x["kernel_ms"], x["oshuffle_ms"]))):
        total = sum(x or 0.0 for x in (r["sparse_ms"], r["reorder_ms"], r["kernel_ms"], r["oshuffle_ms"]))
        total_gain = (base_total - total) / base_total * 100.0
        kernel_gain = (base["kernel_ms"] - (r["kernel_ms"] or 0.0)) / base["kernel_ms"] * 100.0
        print(f"  {r['mode']:<34} total={total:>10.1f}ms gain={total_gain:>7.2f}% kernel_gain={kernel_gain:>7.2f}%")
PY
