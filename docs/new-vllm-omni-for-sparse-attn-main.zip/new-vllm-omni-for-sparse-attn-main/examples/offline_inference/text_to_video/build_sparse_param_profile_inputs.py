#!/usr/bin/env python3
"""Build FlashInfer profile inputs for sparse-parameter sweeps.

The generated files keep the same Q/K/V dump and differ only in the block mask.
They are intended for no-reorder profiling with profile_reorder_l2.py.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import torch
import torch.nn.functional as F

from vllm_omni.diffusion.attention.backends.sparse_mask_builders import (
    build_flexprefill_mask,
    build_minference_vs_mask,
    build_vmoba_thr_mask,
    build_xattn_threshold_mask,
)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--qkv-dump",
        type=Path,
        default=Path("/data/daizijian/daizijian/sparge-attn/real_qkv_dump_wan_513f.pt"),
    )
    parser.add_argument("--seq-len", type=int, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--method",
        choices=(
            "sparge_topk",
            "vsa_topk",
            "sla_topk",
            "longcat_cdf",
            "bsa_cdf",
            "xattn",
            "vmoba_thr",
            "minference_vs",
            "flexprefill",
            "random",
        ),
        required=True,
    )
    parser.add_argument("--block-m", type=int, default=128)
    parser.add_argument("--block-n", type=int, default=128)
    parser.add_argument("--density", type=float, default=0.30)
    parser.add_argument("--topk-ratio", type=float, default=None)
    parser.add_argument("--cdf-threshold", type=float, default=0.50)
    parser.add_argument("--q-keep-ratio", type=float, default=0.50)
    parser.add_argument("--min-blocks", type=int, default=4)
    parser.add_argument("--flexprefill-tau", type=float, default=0.10)
    parser.add_argument("--min-budget-tokens", type=int, default=1024)
    parser.add_argument("--max-budget-tokens", type=int, default=None)
    parser.add_argument("--row-mode", choices=("uniform", "target_cv", "high_cv"), default="target_cv")
    parser.add_argument("--target-cv", type=float, default=0.50)
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--device", default="cuda:0")
    return parser.parse_args()


def _pad_bhld(x: torch.Tensor, block: int) -> tuple[torch.Tensor, int]:
    original_len = x.shape[2]
    padded_len = math.ceil(original_len / block) * block
    pad_len = padded_len - original_len
    if pad_len:
        x = F.pad(x, (0, 0, 0, pad_len))
    return x, pad_len


def _load_qkv(path: Path, block_m: int, block_n: int, seq_len: int | None) -> dict[str, torch.Tensor | int | float]:
    dump = torch.load(path, map_location="cpu")
    q = dump["q"].contiguous()
    k = dump["k"].contiguous()
    v = dump["v"].contiguous()
    if seq_len is not None:
        max_len = min(q.shape[2], k.shape[2], v.shape[2])
        if seq_len > max_len:
            raise ValueError(f"--seq-len={seq_len} exceeds dump length {max_len}")
        q = q[:, :, :seq_len].contiguous()
        k = k[:, :, :seq_len].contiguous()
        v = v[:, :, :seq_len].contiguous()
    q, q_pad = _pad_bhld(q, block_m)
    k, k_pad = _pad_bhld(k, block_n)
    v, v_pad = _pad_bhld(v, block_n)
    return {
        "query": q.transpose(1, 2).contiguous(),
        "key": k.transpose(1, 2).contiguous(),
        "value": v.transpose(1, 2).contiguous(),
        "softmax_scale": float(dump.get("softmax_scale", q.shape[-1] ** -0.5)),
        "q_pad": q_pad,
        "k_pad": k_pad,
        "v_pad": v_pad,
    }


def _topk_mask(
    q: torch.Tensor,
    k: torch.Tensor,
    block_m: int,
    block_n: int,
    topk_ratio: float,
    device: str,
    *,
    center_k: bool = False,
) -> torch.Tensor:
    batch, seq_q, heads, dim = q.shape
    seq_k = k.shape[1]
    mb = seq_q // block_m
    nb = seq_k // block_n
    topk = max(1, min(nb, int(round(topk_ratio * nb))))
    q_gpu = q.to(device, non_blocking=True)
    k_gpu = k.to(device, non_blocking=True)
    out = torch.empty((heads, mb, nb), dtype=torch.int32, device=device)
    for h in range(heads):
        qh = q_gpu[:, :, h].view(batch, mb, block_m, dim).float().mean(dim=2)
        kh_full = k_gpu[:, :, h].float()
        if center_k:
            kh_full = kh_full - kh_full.mean(dim=1, keepdim=True)
        kh = kh_full.view(batch, nb, block_n, dim).mean(dim=2)
        score = torch.matmul(qh, kh.transpose(-1, -2))
        if not center_k:
            score = score / (dim ** 0.5)
        cols = torch.topk(score[0], k=topk, dim=-1, largest=True, sorted=False).indices
        mask_h = torch.zeros((mb, nb), dtype=torch.int32, device=device)
        mask_h.scatter_(-1, cols, 1)
        out[h] = mask_h
        del qh, kh_full, kh, score, cols, mask_h
    return out.cpu().contiguous()


def _longcat_cdf_mask(q: torch.Tensor, k: torch.Tensor, block_m: int, block_n: int, threshold: float, min_blocks: int, device: str) -> torch.Tensor:
    batch, seq_q, heads, dim = q.shape
    seq_k = k.shape[1]
    mb = seq_q // block_m
    nb = seq_k // block_n
    q_gpu = q.to(device, non_blocking=True)
    k_gpu = k.to(device, non_blocking=True)
    out = torch.empty((heads, mb, nb), dtype=torch.int32, device=device)
    for h in range(heads):
        qh = q_gpu[:, :, h].view(batch, mb, block_m, dim).float().mean(dim=2)
        kh = k_gpu[:, :, h].view(batch, nb, block_n, dim).float().mean(dim=2)
        score = torch.matmul(qh, kh.transpose(-1, -2)) / (dim ** 0.5)
        weights = torch.softmax(score[0], dim=-1)
        sorted_weights, sorted_idx = weights.sort(dim=-1, descending=True)
        cdf = sorted_weights.cumsum(dim=-1)
        nnz = torch.searchsorted(
            cdf.contiguous(),
            torch.full((mb, 1), threshold, device=device),
            right=True,
        ).squeeze(-1)
        nnz = nnz.clamp(min=min_blocks, max=nb)
        keep = torch.arange(nb, device=device).view(1, nb) < nnz.unsqueeze(-1)
        mask_h = torch.zeros((mb, nb), dtype=torch.bool, device=device)
        mask_h.scatter_(-1, sorted_idx, keep)
        out[h] = mask_h.to(torch.int32)
        del qh, kh, score, weights, sorted_weights, sorted_idx, cdf, nnz, keep, mask_h
    return out.cpu().contiguous()


def _bsa_cdf_mask(
    q: torch.Tensor,
    k: torch.Tensor,
    block_m: int,
    block_n: int,
    q_keep_ratio: float,
    threshold: float,
    min_blocks: int,
    device: str,
) -> torch.Tensor:
    if block_m != block_n:
        raise ValueError("bsa_cdf builder follows FastVideo BSA and requires square blocks.")
    batch, seq_q, heads, dim = q.shape
    seq_k = k.shape[1]
    mb = seq_q // block_m
    nb = seq_k // block_n
    if mb != nb:
        raise ValueError("bsa_cdf builder expects equal Q/K block counts.")
    keep_size = max(1, min(block_m, int(block_m * q_keep_ratio)))
    q_gpu = q.to(device, non_blocking=True)
    k_gpu = k.to(device, non_blocking=True)
    out = torch.empty((heads, mb, nb), dtype=torch.int32, device=device)
    for h in range(heads):
        q_blocks = q_gpu[:, :, h].view(batch, mb, block_m, dim)
        k_blocks = k_gpu[:, :, h].view(batch, nb, block_n, dim)
        center = q_blocks[:, :, block_m // 2 : block_m // 2 + 1]
        sim = (F.normalize(q_blocks.float(), dim=-1) * F.normalize(center.float(), dim=-1)).sum(dim=-1)
        prune_idx = sim.topk(keep_size, dim=-1, largest=False).indices
        gather_idx = prune_idx.unsqueeze(-1).expand(-1, -1, -1, dim)
        sparse_q = torch.gather(q_blocks.float(), 2, gather_idx)
        q_repr = sparse_q.mean(dim=2)
        k_repr = k_blocks.float().mean(dim=2)
        score = torch.matmul(q_repr, k_repr.transpose(-1, -2)) / (dim ** 0.5)
        weights = torch.softmax(score[0], dim=-1)
        sorted_weights, sorted_idx = weights.sort(dim=-1, descending=True)
        cdf = sorted_weights.cumsum(dim=-1)
        keep = torch.ones_like(cdf, dtype=torch.bool)
        keep[:, 1:] = cdf[:, :-1] < threshold
        keep[:, : min(min_blocks, nb)] = True
        mask_h = torch.zeros((mb, nb), dtype=torch.bool, device=device)
        mask_h.scatter_(-1, sorted_idx, keep)
        out[h] = mask_h.to(torch.int32)
        del q_blocks, k_blocks, center, sim, prune_idx, gather_idx, sparse_q, q_repr, k_repr
        del score, weights, sorted_weights, sorted_idx, cdf, keep, mask_h
    return out.cpu().contiguous()


def _counts_with_target_cv(mb: int, nb: int, density: float, target_cv: float, generator: torch.Generator) -> torch.Tensor:
    mean = density * nb
    if target_cv <= 1e-6:
        return torch.full((mb,), max(1, min(nb, int(round(mean)))), dtype=torch.int64)
    sigma2 = math.log1p(target_cv * target_cv)
    sigma = math.sqrt(sigma2)
    mu = math.log(max(mean, 1e-6)) - 0.5 * sigma2
    vals = torch.exp(torch.randn((mb,), generator=generator) * sigma + mu)
    counts = vals.round().clamp(1, nb).to(torch.int64)
    target_total = int(round(density * mb * nb))
    diff = target_total - int(counts.sum().item())
    order = torch.randperm(mb, generator=generator)
    pos = 0
    while diff != 0:
        i = int(order[pos % mb].item())
        if diff > 0 and counts[i] < nb:
            counts[i] += 1
            diff -= 1
        elif diff < 0 and counts[i] > 1:
            counts[i] -= 1
            diff += 1
        pos += 1
        if pos > mb * nb * 4:
            break
    return counts


def _random_mask(heads: int, mb: int, nb: int, density: float, row_mode: str, target_cv: float, seed: int) -> torch.Tensor:
    generator = torch.Generator(device="cpu").manual_seed(seed)
    mask = torch.zeros((heads, mb, nb), dtype=torch.int32)
    for h in range(heads):
        if row_mode == "uniform":
            counts = torch.full((mb,), max(1, min(nb, int(round(density * nb)))), dtype=torch.int64)
        elif row_mode == "target_cv":
            counts = _counts_with_target_cv(mb, nb, density, target_cv, generator)
        else:
            target_total = int(round(density * mb * nb))
            counts = torch.ones((mb,), dtype=torch.int64)
            remaining = target_total - mb
            order = torch.randperm(mb, generator=generator)
            for idx in order:
                if remaining <= 0:
                    break
                add = min(nb - 1, remaining)
                counts[int(idx.item())] += add
                remaining -= add
        scores = torch.rand((mb, nb), generator=generator)
        cols = torch.topk(scores, int(counts.max().item()), dim=-1, largest=True, sorted=False).indices
        for r in range(mb):
            mask[h, r, cols[r, : int(counts[r].item())]] = 1
    return mask.contiguous()


def main() -> None:
    args = _parse_args()
    if args.topk_ratio is None:
        args.topk_ratio = args.density
    if not (0.0 < args.topk_ratio <= 1.0):
        raise ValueError("--topk-ratio must be in (0, 1].")
    if not (0.0 < args.density <= 1.0):
        raise ValueError("--density must be in (0, 1].")

    payload = _load_qkv(args.qkv_dump, args.block_m, args.block_n, args.seq_len)
    q = payload["query"]
    k = payload["key"]
    heads = q.shape[2]
    mb = q.shape[1] // args.block_m
    nb = k.shape[1] // args.block_n

    if args.method in ("sparge_topk", "vsa_topk"):
        mask = _topk_mask(q, k, args.block_m, args.block_n, args.topk_ratio, args.device, center_k=False)
    elif args.method == "sla_topk":
        mask = _topk_mask(q, k, args.block_m, args.block_n, args.topk_ratio, args.device, center_k=True)
    elif args.method == "longcat_cdf":
        mask = _longcat_cdf_mask(q, k, args.block_m, args.block_n, args.cdf_threshold, args.min_blocks, args.device)
    elif args.method == "bsa_cdf":
        mask = _bsa_cdf_mask(
            q,
            k,
            args.block_m,
            args.block_n,
            args.q_keep_ratio,
            args.cdf_threshold,
            args.min_blocks,
            args.device,
        )
    elif args.method == "xattn":
        estimator_block = min(args.block_m, args.block_n)
        mask = build_xattn_threshold_mask(
            q.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            k.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            estimator_block,
            args.cdf_threshold,
            stride=estimator_block // 4,
            norm=1.0,
            chunk_size=4096,
            block_m=args.block_m,
            block_n=args.block_n,
        ).cpu().contiguous()
    elif args.method == "vmoba_thr":
        mask = build_vmoba_thr_mask(
            q.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            k.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            args.block_m,
            args.block_n,
            args.cdf_threshold,
        ).cpu().contiguous()
    elif args.method == "minference_vs":
        mask = build_minference_vs_mask(
            q.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            k.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            args.block_m,
            args.block_n,
            args.cdf_threshold,
        ).cpu().contiguous()
    elif args.method == "flexprefill":
        mask = build_flexprefill_mask(
            q.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            k.transpose(1, 2).contiguous().to(args.device, non_blocking=True),
            args.block_m,
            args.block_n,
            args.cdf_threshold,
            tau=args.flexprefill_tau,
            min_budget_tokens=args.min_budget_tokens,
            max_budget_tokens=args.max_budget_tokens,
        ).cpu().contiguous()
    else:
        mask = _random_mask(heads, mb, nb, args.density, args.row_mode, args.target_cv, args.seed)

    row_nnz = mask.sum(dim=-1).float()
    out = {
        **payload,
        "mask_all_heads": mask,
        "blk": int(args.block_m),
        "block_m": int(args.block_m),
        "block_n": int(args.block_n),
        "sparse_kernel": "perhead_bsa",
        "source_qkv": str(args.qkv_dump),
        "mask_builder": args.method,
        "topk_ratio": float(args.topk_ratio),
        "cdf_threshold": float(args.cdf_threshold),
        "q_keep_ratio": float(args.q_keep_ratio),
        "min_blocks": int(args.min_blocks),
        "flexprefill_tau": float(args.flexprefill_tau),
        "min_budget_tokens": int(args.min_budget_tokens),
        "max_budget_tokens": None if args.max_budget_tokens is None else int(args.max_budget_tokens),
        "target_density": float(args.density),
        "density": float(mask.float().mean().item()),
        "density_min": float(mask.float().mean(dim=(1, 2)).min().item()),
        "density_max": float(mask.float().mean(dim=(1, 2)).max().item()),
        "row_nnz_mean": float(row_nnz.mean().item()),
        "row_nnz_std": float(row_nnz.std(unbiased=False).item()),
        "row_nnz_cv": float((row_nnz.std(unbiased=False) / row_nnz.mean().clamp_min(1e-6)).item()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(out, args.output)
    print(f"saved: {args.output}")
    print(
        f"method={args.method} q={tuple(q.shape)} mask={tuple(mask.shape)} "
        f"block={args.block_m}x{args.block_n} density={out['density']:.6f} "
        f"row_cv={out['row_nnz_cv']:.4f}"
    )


if __name__ == "__main__":
    main()
