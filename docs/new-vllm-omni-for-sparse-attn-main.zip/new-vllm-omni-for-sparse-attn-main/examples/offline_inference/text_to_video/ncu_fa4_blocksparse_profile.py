#!/usr/bin/env python3
"""Portable FA4 block-sparse NCU profiler.

This script isolates FlashAttention-4 block-sparse kernel behavior from xattn,
QKV dump loading, and reorder implementations.  It creates synthetic block
sparse metadata with fixed sparse-block count, runs FA4 once inside an explicit
cudaProfilerStart/Stop region, and prints enough static information to compare
different GPUs.

Typical NCU command:

  CUDA_VISIBLE_DEVICES=0 ncu --target-processes all --profile-from-start off \
    --metrics gpu__time_duration.sum,gpu__cycles_elapsed.avg,gpc__cycles_elapsed.avg,sm__cycles_elapsed.avg,smsp__inst_executed.sum,sm__pipe_tensor_op_hmma_cycles_active.avg.pct_of_peak_sustained_elapsed,sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed,sm__issue_active.avg.pct_of_peak_sustained_elapsed,smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct,dram__bytes_read.sum,dram__bytes_write.sum,lts__t_sector_hit_rate.pct,gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed,lts__throughput.avg.pct_of_peak_sustained_elapsed,sm__throughput.avg.pct_of_peak_sustained_elapsed,dram__cycles_active.avg,lts__cycles_active.avg \
    -f -o fa4_random \
    python examples/offline_inference/text_to_video/ncu_fa4_blocksparse_profile.py \
      --pattern random --heads 40 --blocks 2320 --nnz 480 --warmup 2 --repeat 5 --profile

Compare against:

  ... --pattern regular_shared ...
  ... --pattern regular_sliding ...
  ... --pattern pooled_random --pool-blocks 960 ...

The key derived metric is HBM per sparse block:

  dram__bytes_read.sum / (batch * heads * blocks * nnz)

If random and regular layouts execute the same sparse-block count but random has
much higher DRAM bytes, lower L2 hit, and higher time, the kernel is sensitive to
KV reuse-distance / memory-system pressure on that GPU.

The script also supports rectangular FA4 tiles via --q-block-size and
--kv-block-size.  Lowering only the Q tile reduces FLOPs per sparse block while
leaving K/V traffic per sparse block roughly unchanged, which is useful for
stress-testing when the kernel crosses from tensor-pipe limited to memory-system
limited behavior.
"""

from __future__ import annotations

import argparse
import csv
import inspect
import math
import sys
import time
from pathlib import Path

import torch


REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


NCU_METRICS = (
    "gpu__time_duration.sum",
    "gpu__cycles_elapsed.avg",
    "gpc__cycles_elapsed.avg",
    "sm__cycles_elapsed.avg",
    "smsp__inst_executed.sum",
    "smsp__inst_issued.sum",
    "smsp__inst_issued_per_issue_active.ratio",
    "sm__inst_executed_pipe_tensor.sum",
    "sm__inst_executed_pipe_tensor_op_gmma.sum",
    "smsp__sass_inst_executed_op_shared_gmma.sum",
    "sm__pipe_tensor_op_hmma_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__pipe_tma_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__issue_active.avg.pct_of_peak_sustained_elapsed",
    "smsp__warp_issue_stalled_barrier_per_warp_active.pct",
    "smsp__warp_issue_stalled_dispatch_stall_per_warp_active.pct",
    "smsp__warp_issue_stalled_gmma_per_warp_active.pct",
    "smsp__warp_issue_stalled_lg_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct",
    "smsp__warp_issue_stalled_membar_per_warp_active.pct",
    "smsp__warp_issue_stalled_mio_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_no_instruction_per_warp_active.pct",
    "smsp__warp_issue_stalled_not_selected_per_warp_active.pct",
    "smsp__warp_issue_stalled_short_scoreboard_per_warp_active.pct",
    "smsp__warp_issue_stalled_tex_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_wait_per_warp_active.pct",
    "dram__bytes_read.sum",
    "dram__bytes_write.sum",
    "dram__cycles_active_read.sum",
    "lts__t_sector_hit_rate.pct",
    "lts__t_requests_aperture_device_op_read.sum",
    "lts__t_requests_aperture_device_op_read_lookup_hit.sum",
    "lts__t_requests_aperture_device_op_read_lookup_miss.sum",
    "gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed",
    "lts__throughput.avg.pct_of_peak_sustained_elapsed",
    "sm__throughput.avg.pct_of_peak_sustained_elapsed",
    "dram__cycles_active.avg",
    "lts__cycles_active.avg",
    "l1tex__tmain_requests.sum",
    "l1tex__m_xbar2l1tex_read_bytes_mem_global_op_tma_ld.sum",
    "l1tex__m_xbar2l1tex_read_sectors_mem_global_op_tma_ld.sum",
    "l1tex__m_l1tex2xbar_read_requests_replayed_mem_global_op_tma_ld_dest_multicast.sum",
)


def parse_dtype(name: str) -> torch.dtype:
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    raise ValueError(f"Unsupported dtype={name}")


def get_kv_blocks(args: argparse.Namespace) -> int:
    return args.kv_blocks if getattr(args, "kv_blocks", -1) > 0 else args.blocks


def get_q_blocks(args: argparse.Namespace, q_block_size: int, kv_block_size: int) -> int:
    if getattr(args, "q_blocks", -1) > 0:
        return args.q_blocks
    if getattr(args, "same_seqlen", False) and q_block_size != kv_block_size:
        return int(math.ceil(get_kv_blocks(args) * kv_block_size / q_block_size))
    return args.blocks


def calc_nnz(args: argparse.Namespace) -> int:
    kv_blocks = get_kv_blocks(args)
    if args.nnz > 0:
        nnz = args.nnz
    else:
        nnz = int(round(kv_blocks * args.density))
    if nnz <= 0 or nnz > kv_blocks:
        raise ValueError(f"Invalid nnz={nnz}; must be in [1, kv_blocks={kv_blocks}]")
    return nnz


def fill_random_exact(
    idx_flat: torch.Tensor,
    rows: int,
    nb: int,
    nnz: int,
    generator: torch.Generator,
    chunk_rows: int,
):
    """Fill each row with exactly nnz unique random columns.

    This chunked top-k implementation avoids materializing H * MB * NB random
    scores at once, which is important for long-sequence H=40 cases.
    """

    for start in range(0, rows, chunk_rows):
        end = min(start + chunk_rows, rows)
        scores = torch.rand((end - start, nb), device=idx_flat.device, generator=generator)
        cols = torch.topk(scores, k=nnz, dim=-1, largest=False).indices
        cols = cols.sort(dim=-1).values.to(torch.int32)
        idx_flat[start:end, :nnz] = cols


def make_variable_nnz_counts(
    rows: int,
    nb: int,
    mean_nnz: int,
    cv: float,
    min_nnz: int,
    max_nnz: int,
    generator: torch.Generator,
    device: torch.device,
) -> torch.Tensor:
    """Generate integer row counts with fixed total and approximately target CV."""
    if cv <= 0:
        return torch.full((rows,), mean_nnz, dtype=torch.int32, device=device)
    min_nnz = max(1, int(min_nnz))
    max_nnz = min(int(max_nnz), nb)
    if min_nnz > max_nnz:
        raise ValueError(f"Invalid NNZ bounds: min={min_nnz} max={max_nnz}")

    sigma2 = math.log(cv * cv + 1.0)
    sigma = math.sqrt(sigma2)
    mu = math.log(max(float(mean_nnz), 1.0)) - 0.5 * sigma2
    samples = torch.empty((rows,), device=device).normal_(mean=mu, std=sigma, generator=generator).exp()
    counts = samples.round().clamp(min=min_nnz, max=max_nnz).to(torch.int32)

    target = int(mean_nnz) * int(rows)
    delta = target - int(counts.long().sum().item())
    if delta == 0:
        return counts

    # Adjust to an exact target total so sparse-block count matches fixed-NNZ runs.
    order = torch.randperm(rows, device=device, generator=generator)
    if delta > 0:
        remaining = delta
        while remaining > 0:
            eligible = counts[order] < max_nnz
            if not bool(eligible.any().item()):
                break
            pick = order[eligible][:remaining]
            counts[pick] += 1
            remaining -= int(pick.numel())
    else:
        remaining = -delta
        while remaining > 0:
            eligible = counts[order] > min_nnz
            if not bool(eligible.any().item()):
                break
            pick = order[eligible][:remaining]
            counts[pick] -= 1
            remaining -= int(pick.numel())
    return counts


def make_variable_nnz_counts_per_head(
    heads: int,
    mb: int,
    nb: int,
    mean_nnz: int,
    cv: float,
    min_nnz: int,
    max_nnz: int,
    generator: torch.Generator,
    device: torch.device,
) -> torch.Tensor:
    """Generate variable row counts while keeping every head's total identical."""
    per_head = []
    for _ in range(heads):
        per_head.append(
            make_variable_nnz_counts(
                rows=mb,
                nb=nb,
                mean_nnz=mean_nnz,
                cv=cv,
                min_nnz=min_nnz,
                max_nnz=max_nnz,
                generator=generator,
                device=device,
            )
        )
    return torch.stack(per_head, dim=0)


def fill_random_variable(
    idx_flat: torch.Tensor,
    counts: torch.Tensor,
    nb: int,
    generator: torch.Generator,
    chunk_rows: int,
):
    """Fill each row with exactly counts[row] unique random columns."""
    rows = int(counts.numel())
    for start in range(0, rows, chunk_rows):
        end = min(start + chunk_rows, rows)
        count_chunk = counts[start:end]
        max_k = int(count_chunk.max().item())
        if max_k <= 0:
            continue
        scores = torch.rand((end - start, nb), device=idx_flat.device, generator=generator)
        cols = torch.topk(scores, k=max_k, dim=-1, largest=False).indices
        cols = cols.sort(dim=-1).values.to(torch.int32)
        idx_flat[start:end, :max_k] = cols


def build_synthetic_metadata(
    pattern: str,
    heads: int,
    mb: int,
    nb: int,
    nnz: int,
    device: torch.device,
    seed: int,
    chunk_rows: int,
    pool_blocks: int,
    nnz_cv: float = 0.0,
    min_nnz: int = 1,
    max_nnz: int = -1,
):
    if pattern == "random_variable_nnz":
        gen = torch.Generator(device=device)
        gen.manual_seed(seed)
        counts = make_variable_nnz_counts_per_head(
            heads=heads,
            mb=mb,
            nb=nb,
            mean_nnz=nnz,
            cv=nnz_cv,
            min_nnz=min_nnz,
            max_nnz=nb if max_nnz <= 0 else max_nnz,
            generator=gen,
            device=device,
        )
        cnt = counts.view(1, heads, mb).contiguous()
    else:
        cnt = torch.full((1, heads, mb), nnz, dtype=torch.int32, device=device)
    idx = torch.zeros((1, heads, mb, nb), dtype=torch.int32, device=device)

    if pattern == "regular_shared":
        cols = torch.arange(nnz, device=device, dtype=torch.int32)
        idx[:, :, :, :nnz] = cols.view(1, 1, 1, nnz)
    elif pattern == "regular_sliding":
        row = torch.arange(mb, device=device, dtype=torch.int32).view(1, mb, 1)
        off = torch.arange(nnz, device=device, dtype=torch.int32).view(1, 1, nnz)
        start = (row - nnz // 2).remainder(nb)
        cols = (start + off).remainder(nb).sort(dim=-1).values
        idx[:, :, :, :nnz] = cols.view(1, 1, mb, nnz).expand(1, heads, mb, nnz)
    elif pattern == "random_shared_per_head":
        gen = torch.Generator(device=device)
        gen.manual_seed(seed)
        scores = torch.rand((heads, nb), device=device, generator=gen)
        cols = torch.topk(scores, k=nnz, dim=-1, largest=False).indices
        cols = cols.sort(dim=-1).values.to(torch.int32)
        idx[:, :, :, :nnz] = cols.view(1, heads, 1, nnz).expand(1, heads, mb, nnz)
    elif pattern == "random":
        gen = torch.Generator(device=device)
        gen.manual_seed(seed)
        idx_flat = idx.view(heads * mb, nb)
        fill_random_exact(
            idx_flat,
            rows=heads * mb,
            nb=nb,
            nnz=nnz,
            generator=gen,
            chunk_rows=chunk_rows,
        )
    elif pattern == "random_variable_nnz":
        idx_flat = idx.view(heads * mb, nb)
        fill_random_variable(
            idx_flat,
            counts=cnt.view(-1),
            nb=nb,
            generator=gen,
            chunk_rows=chunk_rows,
        )
    elif pattern == "pooled_random":
        pool = pool_blocks if pool_blocks > 0 else nb
        if pool < nnz or pool > nb:
            raise ValueError(f"Invalid pool_blocks={pool}; expected nnz <= pool_blocks <= kv_blocks")
        gen = torch.Generator(device=device)
        gen.manual_seed(seed)
        idx_flat = idx.view(heads * mb, nb)
        for start in range(0, heads * mb, chunk_rows):
            end = min(start + chunk_rows, heads * mb)
            scores = torch.rand((end - start, pool), device=device, generator=gen)
            cols = torch.topk(scores, k=nnz, dim=-1, largest=False).indices
            cols = cols.sort(dim=-1).values.to(torch.int32)
            idx_flat[start:end, :nnz] = cols
    else:
        raise ValueError(f"Unknown pattern={pattern}")

    return cnt.contiguous(), idx.contiguous()


def load_mask_metadata(path: Path, device: torch.device):
    """Load a dense block mask and convert to FA4 block-sparse metadata.

    Accepted shapes:
      - (H, MB, NB)
      - (B, H, MB, NB), with B currently required to be 1
    """

    obj = torch.load(path, map_location="cpu", weights_only=False)
    if isinstance(obj, dict):
        for key in ("mask", "mask_orig", "simple_mask", "simple_masks"):
            if key in obj:
                obj = obj[key]
                break
    if isinstance(obj, (list, tuple)):
        obj = obj[0]
    mask = torch.as_tensor(obj)
    if mask.ndim == 4:
        if mask.shape[0] != 1:
            raise ValueError("Only batch=1 dense masks are supported")
        mask = mask[0]
    if mask.ndim != 3:
        raise ValueError(f"Expected mask shape (H, MB, NB), got {tuple(mask.shape)}")
    mask = mask.to(device=device, dtype=torch.bool).contiguous()
    heads, mb, nb = mask.shape
    cnt = mask.sum(dim=-1, dtype=torch.int32).unsqueeze(0).contiguous()
    idx = torch.zeros((1, heads, mb, nb), dtype=torch.int32, device=device)
    sorted_cols = torch.argsort(~mask, dim=-1, stable=True).to(torch.int32)
    valid = torch.arange(nb, device=device).view(1, 1, nb) < cnt[0].unsqueeze(-1)
    idx[0] = sorted_cols * valid.to(torch.int32)
    return cnt, idx


def apply_row_order(
    cnt: torch.Tensor,
    idx: torch.Tensor,
    row_order: str,
    seed: int,
):
    if row_order == "identity":
        return cnt, idx
    _, heads, mb = cnt.shape
    device = cnt.device
    if row_order == "reverse":
        perm = torch.arange(mb - 1, -1, -1, device=device).view(1, mb).expand(heads, mb)
    elif row_order == "random":
        gen = torch.Generator(device=device)
        gen.manual_seed(seed + 1009)
        perm = torch.stack([torch.randperm(mb, device=device, generator=gen) for _ in range(heads)])
    else:
        raise ValueError(f"Unknown row_order={row_order}")
    cnt2 = torch.gather(cnt[0], 1, perm).unsqueeze(0).contiguous()
    idx2 = torch.gather(idx[0], 1, perm.unsqueeze(-1).expand_as(idx[0])).unsqueeze(0).contiguous()
    return cnt2, idx2


def make_qkv(
    batch: int,
    q_seq_len: int,
    kv_seq_len: int,
    heads: int,
    dim: int,
    dtype: torch.dtype,
    device: torch.device,
    seed: int,
):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    q = torch.randn(batch, q_seq_len, heads, dim, dtype=dtype, device=device)
    k = torch.randn(batch, kv_seq_len, heads, dim, dtype=dtype, device=device)
    v = torch.randn(batch, kv_seq_len, heads, dim, dtype=dtype, device=device)
    return q, k, v


def make_block_sparse_tensors(
    cnt: torch.Tensor,
    idx: torch.Tensor,
    q_block_size: int,
    kv_block_size: int,
):
    try:
        from flash_attn.cute.block_sparsity import BlockSparseTensorsTorch
    except Exception:
        from vllm_omni.diffusion.attention.backends.flash_attn import BlockSparseTensorsTorch

    batch, heads, mb = cnt.shape
    nb = idx.shape[-1]
    zeros_cnt = torch.zeros_like(cnt)
    zeros_idx = torch.zeros(batch, heads, mb, nb, dtype=torch.int32, device=cnt.device)
    return BlockSparseTensorsTorch(
        full_block_cnt=cnt,
        full_block_idx=idx,
        mask_block_cnt=zeros_cnt,
        mask_block_idx=zeros_idx,
        block_size=(q_block_size, kv_block_size),
    )


def run_fa4(
    q,
    k,
    v,
    bst,
    q_block_size: int,
    kv_block_size: int,
    warmup: int,
    repeat: int,
    profile: bool,
):
    from flash_attn.cute.interface import _flash_attn_fwd as fa4_fwd

    sig = inspect.signature(fa4_fwd)
    if "tile_mn" in sig.parameters:
        block_kwargs = {"tile_mn": (q_block_size, kv_block_size)}
    else:
        block_kwargs = {"m_block_size": q_block_size, "n_block_size": kv_block_size}

    out = None
    for _ in range(warmup):
        out, _ = fa4_fwd(
            q,
            k,
            v,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(repeat):
        out, _ = fa4_fwd(
            q,
            k,
            v,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
    end.record()
    torch.cuda.synchronize()
    avg_ms = start.elapsed_time(end) / max(repeat, 1)

    if profile:
        print("=== NCU PROFILE REGION ===", flush=True)
        torch.cuda.cudart().cudaProfilerStart()
        out, _ = fa4_fwd(
            q,
            k,
            v,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStop()
        print("=== NCU PROFILE DONE ===", flush=True)

    return avg_ms, out


def append_csv(path: str, row: dict):
    if not path:
        return
    csv_path = Path(path)
    exists = csv_path.exists()
    with csv_path.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def print_ncu_command(args: argparse.Namespace):
    metrics = ",".join(NCU_METRICS)
    q_block_size = args.q_block_size if args.q_block_size > 0 else args.block_size
    kv_block_size = args.kv_block_size if args.kv_block_size > 0 else args.block_size
    q_blocks = get_q_blocks(args, q_block_size, kv_block_size)
    kv_blocks = get_kv_blocks(args)
    cmd = (
        "CUDA_VISIBLE_DEVICES=0 ncu --target-processes all --profile-from-start off "
        f"--metrics {metrics} -f -o fa4_{args.pattern}_{q_blocks}x{kv_blocks}b_{calc_nnz(args)}nnz "
        "python examples/offline_inference/text_to_video/ncu_fa4_blocksparse_profile.py "
        f"--pattern {args.pattern} --heads {args.heads} --q-blocks {q_blocks} --kv-blocks {kv_blocks} "
        f"--nnz {calc_nnz(args)} --q-block-size {q_block_size} --kv-block-size {kv_block_size} --dim {args.dim} "
        f"--dtype {args.dtype} --pool-blocks {args.pool_blocks} "
        f"--warmup {args.warmup} --repeat {args.repeat} --profile"
    )
    print("\nRecommended NCU command:\n" + cmd + "\n", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--pattern",
        default="random",
        choices=(
            "random",
            "random_variable_nnz",
            "regular_shared",
            "regular_sliding",
            "random_shared_per_head",
            "pooled_random",
        ),
        help="Synthetic KV block pattern. Ignored when --mask is provided.",
    )
    parser.add_argument("--mask", default="", help="Optional dense block mask .pt file")
    parser.add_argument("--row-order", default="identity", choices=("identity", "reverse", "random"))
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--heads", type=int, default=40)
    parser.add_argument(
        "--broadcast-metadata-heads",
        action="store_true",
        help=(
            "Build synthetic block-sparse metadata with head dimension 1 and "
            "broadcast it across QKV heads. This reduces metadata memory for "
            "very long sequence sweeps."
        ),
    )
    parser.add_argument("--blocks", type=int, default=2320, help="Number of Q/KV blocks")
    parser.add_argument("--q-blocks", type=int, default=-1,
                        help="Number of Q block rows. Default: --blocks, or same sequence length with --same-seqlen.")
    parser.add_argument("--kv-blocks", type=int, default=-1,
                        help="Number of KV block columns. Default: --blocks.")
    parser.add_argument("--nnz", type=int, default=-1, help="Sparse KV blocks per row")
    parser.add_argument("--density", type=float, default=0.2068965517, help="Used when --nnz <= 0")
    parser.add_argument("--nnz-cv", type=float, default=1.0,
                        help="Target per-row NNZ coefficient of variation for random_variable_nnz")
    parser.add_argument("--min-nnz", type=int, default=1,
                        help="Minimum row NNZ for random_variable_nnz")
    parser.add_argument("--max-nnz", type=int, default=-1,
                        help="Maximum row NNZ for random_variable_nnz; default blocks")
    parser.add_argument("--block-size", type=int, default=128,
                        help="Backward-compatible square tile size used when q/kv block sizes are omitted.")
    parser.add_argument("--q-block-size", type=int, default=-1,
                        help="FA4 M tile / Q block size. Default: --block-size.")
    parser.add_argument("--kv-block-size", type=int, default=-1,
                        help="FA4 N tile / KV block size. Default: --block-size.")
    parser.add_argument("--same-seqlen", action="store_true",
                        help="If --q-blocks is omitted, choose Q blocks so Q sequence length matches KV length.")
    parser.add_argument("--dim", type=int, default=128)
    parser.add_argument("--dtype", default="bf16", choices=("bf16", "fp16"))
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--metadata-chunk-rows", type=int, default=512)
    parser.add_argument(
        "--pool-blocks",
        type=int,
        default=-1,
        help="For pooled_random: number of KV blocks sampled by all rows. Smaller means higher L2 reuse.",
    )
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--repeat", type=int, default=5)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--csv", default="")
    parser.add_argument("--print-ncu-command", action="store_true")
    args = parser.parse_args()

    if args.print_ncu_command:
        print_ncu_command(args)

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    if args.batch != 1:
        raise ValueError("This script currently supports batch=1 for FA4 block-sparse metadata")

    device = torch.device("cuda")
    dtype = parse_dtype(args.dtype)
    q_block_size = args.q_block_size if args.q_block_size > 0 else args.block_size
    kv_block_size = args.kv_block_size if args.kv_block_size > 0 else args.block_size
    q_blocks = get_q_blocks(args, q_block_size, kv_block_size)
    kv_blocks = get_kv_blocks(args)
    nnz = calc_nnz(args)

    if args.mask:
        print(f"Loading dense block mask from {args.mask}", flush=True)
        cnt, idx = load_mask_metadata(Path(args.mask), device=device)
        _, mask_heads, mb = cnt.shape
        nb = idx.shape[-1]
        if mask_heads != args.heads:
            print(f"Overriding heads from mask: {args.heads} -> {mask_heads}", flush=True)
            args.heads = mask_heads
        if mb != q_blocks:
            print(f"Overriding q_blocks from mask: {q_blocks} -> {mb}", flush=True)
            q_blocks = mb
        if nb != kv_blocks:
            print(f"Overriding kv_blocks from mask: {kv_blocks} -> {nb}", flush=True)
            kv_blocks = nb
        nnz_mean = cnt.float().mean().item()
        nnz = int(round(nnz_mean))
    else:
        metadata_heads = 1 if args.broadcast_metadata_heads else args.heads
        print(
            f"Building synthetic metadata pattern={args.pattern} "
            f"H={args.heads} metadata_H={metadata_heads} MB={q_blocks} NB={kv_blocks} nnz={nnz} "
            f"density={nnz / kv_blocks:.4f}",
            flush=True,
        )
        t0 = time.perf_counter()
        cnt, idx = build_synthetic_metadata(
            args.pattern,
            heads=metadata_heads,
            mb=q_blocks,
            nb=kv_blocks,
            nnz=nnz,
            device=device,
            seed=args.seed,
            chunk_rows=args.metadata_chunk_rows,
            pool_blocks=args.pool_blocks,
            nnz_cv=args.nnz_cv,
            min_nnz=args.min_nnz,
            max_nnz=args.max_nnz,
        )
        torch.cuda.synchronize()
        print(f"metadata_build_ms={(time.perf_counter() - t0) * 1000.0:.2f}", flush=True)

    cnt, idx = apply_row_order(cnt, idx, args.row_order, seed=args.seed)

    batch, metadata_heads, mb = cnt.shape
    nb = idx.shape[-1]
    heads = args.heads
    q_seq_len = mb * q_block_size
    kv_seq_len = nb * kv_block_size
    metadata_scale = heads // metadata_heads if metadata_heads == 1 else 1
    if metadata_heads not in (1, heads):
        raise ValueError(f"metadata heads must be 1 or heads={heads}, got {metadata_heads}")
    sparse_blocks = int(cnt.long().sum().item() * metadata_scale)
    flops_per_sparse_block = 4 * q_block_size * kv_block_size * args.dim
    total_tflops = sparse_blocks * flops_per_sparse_block / 1e12
    avg_nnz = cnt.float().mean().item()
    nnz_std = cnt.float().std(unbiased=False).item()
    nnz_cv_actual = nnz_std / max(avg_nnz, 1e-6)
    nnz_min = int(cnt.min().item())
    nnz_max = int(cnt.max().item())
    density = avg_nnz / nb
    head_totals = cnt[0].long().sum(dim=-1)
    head_total_min = int(head_totals.min().item())
    head_total_max = int(head_totals.max().item())
    head_total_mean = float(head_totals.float().mean().item())
    head_total_cv = float(
        head_totals.float().std(unbiased=False).item() / max(head_total_mean, 1e-6)
    )

    print(
        f"FA4 case: B={batch} H={heads} metadata_H={metadata_heads} Sq={q_seq_len} Skv={kv_seq_len} "
        f"MB={mb} NB={nb} q_block={q_block_size} kv_block={kv_block_size} D={args.dim} dtype={args.dtype}",
        flush=True,
    )
    print(
        f"sparse_blocks={sparse_blocks} avg_nnz={avg_nnz:.2f} "
        f"nnz_cv={nnz_cv_actual:.4f} nnz_min={nnz_min} nnz_max={nnz_max} "
        f"density={density:.6f} head_total_min={head_total_min} "
        f"head_total_max={head_total_max} head_total_cv={head_total_cv:.6f} "
        f"approx_flops={total_tflops:.3f} TFLOP",
        flush=True,
    )

    q, k, v = make_qkv(
        batch=batch,
        q_seq_len=q_seq_len,
        kv_seq_len=kv_seq_len,
        heads=heads,
        dim=args.dim,
        dtype=dtype,
        device=device,
        seed=args.seed,
    )
    bst = make_block_sparse_tensors(cnt, idx, q_block_size, kv_block_size)

    kernel_ms, out = run_fa4(
        q,
        k,
        v,
        bst,
        q_block_size=q_block_size,
        kv_block_size=kv_block_size,
        warmup=args.warmup,
        repeat=args.repeat,
        profile=args.profile,
    )
    torch.cuda.synchronize()

    achieved_tflops = total_tflops / (kernel_ms / 1000.0)
    row = {
        "pattern": args.pattern if not args.mask else "mask",
        "mask": args.mask,
        "row_order": args.row_order,
        "batch": batch,
        "heads": heads,
        "metadata_heads": metadata_heads,
        "blocks": mb,
        "q_blocks": mb,
        "kv_blocks": nb,
        "block_size": args.block_size,
        "q_block_size": q_block_size,
        "kv_block_size": kv_block_size,
        "q_seq_len": q_seq_len,
        "kv_seq_len": kv_seq_len,
        "dim": args.dim,
        "dtype": args.dtype,
        "seed": args.seed,
        "pool_blocks": args.pool_blocks if args.pattern == "pooled_random" else "",
        "avg_nnz": avg_nnz,
        "nnz_cv": nnz_cv_actual,
        "nnz_min": nnz_min,
        "nnz_max": nnz_max,
        "head_total_min": head_total_min,
        "head_total_max": head_total_max,
        "head_total_cv": head_total_cv,
        "density": density,
        "sparse_blocks": sparse_blocks,
        "approx_tflops": total_tflops,
        "kernel_ms": kernel_ms,
        "achieved_tflops": achieved_tflops,
    }
    print(f"RESULT {row}", flush=True)
    print("RESULT_CSV," + ",".join(str(v) for v in row.values()), flush=True)
    append_csv(args.csv, row)

    del out, q, k, v, bst, cnt, idx
    torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
