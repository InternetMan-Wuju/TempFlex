#!/usr/bin/env python3
"""NCU benchmark: real dense QKV -> XAttention threshold mask -> FA4 sparse attention.

This script intentionally does not consume pre-dumped sparse masks.  It loads
real dense QKV tensors, derives the sparse block mask with xattn threshold mode,
applies one row-reorder strategy, and profiles the FA4 block-sparse forward.

Example:
  python ncu_xattn_qkv_reorder.py --dump dense_dump_161f --threshold 0.9 --mode wave_reorder

NCU:
  ncu --profile-from-start off \
      --metrics dram__bytes_read,dram__bytes_write,gpu__time_duration,lts__t_request_hit_rate \
      -f -o ncu_xattn_wave \
      python ncu_xattn_qkv_reorder.py --dump dense_dump_161f --threshold 0.9 --mode wave_reorder
"""

import argparse
import csv
import inspect
import math
import os
import re
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F


REPO_ROOT = Path(__file__).resolve().parents[3]
XATTN_ROOT = Path("/data1/dhelix_shared/daizijian/x-attention")
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(XATTN_ROOT) not in sys.path:
    sys.path.insert(0, str(XATTN_ROOT))


DUMP_PRESETS = {
    "dense_dump_161f": Path("/data1/dhelix_shared/daizijian/QKVtensor/dense_dump_161f/longcat_layer0.pt"),
    "dense_dump_401f": Path("/data1/dhelix_shared/daizijian/QKVtensor/dense_dump_401f/longcat_layer0.pt"),
}

REORDER_MODES = (
    "no_reorder",
    "nnz_reorder",
    "nnz_macro_wave_reorder",
    "nnz_macro_svd1_reorder",
    "nnz_macro_svd2_reorder",
    "nnz_macro_fiedler_reorder",
    "nnz_macro_centroid_reorder",
    "nnz_macro_spectral_bisect_reorder",
    "nnz_3step_reorder",
    "wave_reorder",
    "wave_1d_reorder",
    "wave_2d_reorder",
    "svd_u2u3_reorder",
    "svd_deflation_reorder",
    "fiedler_wave_reorder",
    "fiedler_local_nnz_reorder",
    "fiedler_mixed_nnz_reorder",
    "fiedler_seeded_wave_reorder",
    "bootes_spectral_wave_reorder",
    "spectral_morton_wave_reorder",
    "spectral_morton_path_reorder",
    "centered_morton_wave_reorder",
    "adaptive_spectral_reorder",
    "adaptive_spectral_grouped_reorder",
    "adaptive_seeded_grouped_reorder",
    "capacity_refined_wave_reorder",
    "hypergraph_fm_nnz_reorder",
    "balanced_assignment_wave_reorder",
    "marginal_union_wave_reorder",
    "banded_union_wave_reorder",
    "banded_weighted_union_wave_reorder",
    "banded_union_sequenced_wave_reorder",
    "auction_union_reorder_cuda",
    "auction_exact_path_reorder",
    "partition_refined_union_reorder",
    "segment_partition_reorder",
    "rolling_union_wave_reorder",
    "spectral_union_wave_reorder",
    "optimal_reorder_cuda",
    "bcg_l2_reorder_cuda",
    "hybrid_block_reorder",
    "joint_overlap_nnz_reorder",
)


def parse_csv_list(value, cast):
    return [cast(x.strip()) for x in value.split(",") if x.strip()]


def is_ltx_dump_dir(path):
    return path.is_dir() and any(path.glob("q_block*_ts*.pkl"))


def infer_ltx_timestep(path):
    match = re.search(r"step(\d+)", path.name)
    if match:
        return int(match.group(1))
    candidates = sorted(path.glob("q_block0_ts*.pkl"))
    if not candidates:
        raise FileNotFoundError(f"Cannot infer LTX timestep from {path}")
    match = re.search(r"_ts(\d+)\.pkl$", candidates[0].name)
    if not match:
        raise FileNotFoundError(f"Cannot infer LTX timestep from {candidates[0]}")
    return int(match.group(1))


def resolve_dump(value):
    if value in DUMP_PRESETS:
        return DUMP_PRESETS[value]
    path = Path(value)
    if path.is_dir():
        if is_ltx_dump_dir(path):
            return path
        return path / "longcat_layer0.pt"
    return path


def pad_sequence(x, target_len):
    pad = target_len - x.shape[2]
    if pad <= 0:
        return x.contiguous()
    return F.pad(x, (0, 0, 0, pad)).contiguous()


def load_dense_qkv(dump_path):
    try:
        data = torch.load(dump_path, map_location="cpu", weights_only=False)
        if isinstance(data, dict) and "q_3d" in data:
            return data["q_3d"], data["k_3d"], data["v_3d"], dump_path.parent.name
    except Exception:
        pass

    name = dump_path.name
    parent = dump_path.parent
    match = re.search(r"layer(\d+)", name)
    if not match:
        match = re.search(r"layer(\d+)", parent.name)
        
    if match:
        layer_idx = match.group(1)
        q_path = parent / f"q_layer{layer_idx}.pt"
        k_path = parent / f"k_layer{layer_idx}.pt"
        v_path = parent / f"v_layer{layer_idx}.pt"
    else:
        q_path = parent / "q_layer0.pt"
        k_path = parent / "k_layer0.pt"
        v_path = parent / "v_layer0.pt"
        
    if not q_path.exists():
        test_dir = Path("/home/ubuntu/test")
        q_path = test_dir / q_path.name
        k_path = test_dir / k_path.name
        v_path = test_dir / v_path.name

    if not q_path.exists():
        raise FileNotFoundError(f"Could not find QKV files. Tried {q_path}")
        
    print(f"Loading separate QKV files: {q_path.name}, {k_path.name}, {v_path.name}", flush=True)
    q = torch.load(q_path, map_location="cpu", weights_only=False)
    k = torch.load(k_path, map_location="cpu", weights_only=False)
    v = torch.load(v_path, map_location="cpu", weights_only=False)
    
    if q.ndim == 4 and q.shape[2] == 40 and q.shape[3] == 128:
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        
    return q, k, v, f"layer{match.group(1) if match else 0}"



def load_ltx_qkv(dump_dir, layer, timestep):
    if timestep < 0:
        timestep = infer_ltx_timestep(dump_dir)
    q_path = dump_dir / f"q_block{layer}_ts{timestep}.pkl"
    k_path = dump_dir / f"k_block{layer}_ts{timestep}.pkl"
    v_path = dump_dir / f"v_block{layer}_ts{timestep}.pkl"
    for path in (q_path, k_path, v_path):
        if not path.exists():
            raise FileNotFoundError(path)
    q = torch.load(q_path, map_location="cpu", weights_only=False)
    k = torch.load(k_path, map_location="cpu", weights_only=False)
    v = torch.load(v_path, map_location="cpu", weights_only=False)
    return q, k, v, f"{dump_dir.name}_layer{layer}"


def load_qkv(
    dump_path,
    block_size,
    chunk_size,
    heads=-1,
    blocks=-1,
    layer=0,
    timestep=-1,
    head_start=0,
):
    if is_ltx_dump_dir(dump_path):
        q, k, v, label = load_ltx_qkv(dump_path, layer=layer, timestep=timestep)
    else:
        q, k, v, label = load_dense_qkv(dump_path)

    if heads > 0 or head_start > 0:
        h0 = max(0, int(head_start))
        h1 = None if heads <= 0 else h0 + int(heads)
        q = q[:, h0:h1]
        k = k[:, h0:h1]
        v = v[:, h0:h1]

    if blocks > 0:
        max_tokens = blocks * block_size
        q = q[:, :, :max_tokens]
        k = k[:, :, :max_tokens]
        v = v[:, :, :max_tokens]

    orig_len = q.shape[2]
    padded_len = ((orig_len + chunk_size - 1) // chunk_size) * chunk_size
    q = pad_sequence(q.cuda(), padded_len)
    k = pad_sequence(k.cuda(), padded_len)
    v = pad_sequence(v.cuda(), padded_len)

    if padded_len % block_size != 0:
        raise ValueError(
            f"padded_len={padded_len} must be divisible by block_size={block_size}"
        )

    return q, k, v, orig_len, padded_len, label


@torch.no_grad()
def build_xattn_threshold_mask(q, k, block_size, stride, threshold, chunk_size):
    if threshold < 0:
        # Generate random mask with exact density = abs(threshold)
        density = abs(threshold)
        B, H, S, D = q.shape
        MB = S // block_size
        NB = MB
        nnz = int(round(NB * density))
        nnz = max(1, min(nnz, NB))
        
        print(f"[Random Mask] Generating random mask: heads={H}, blocks={MB}, density={density:.4f}, nnz={nnz}", flush=True)
        generator = torch.Generator(device=q.device)
        generator.manual_seed(42)  # Fixed seed for reproducibility
        random_values = torch.rand((H, MB, NB), device=q.device, generator=generator)
        _, indices = torch.topk(random_values, k=nnz, dim=2, largest=True)
        mask = torch.zeros((H, MB, NB), dtype=torch.bool, device=q.device)
        mask.scatter_(2, indices, True)
        return mask.contiguous()

    from xattn.src.Xattention import xattn_estimate

    _, simple_masks = xattn_estimate(
        q,
        k,
        block_size=block_size,
        stride=stride,
        norm=1,
        softmax=True,
        threshold=threshold,
        chunk_size=chunk_size,
        select_mode="inverse",
        use_triton=False,
        causal=False,
        kdb=1,
    )
    return simple_masks[0].bool().contiguous()



def compute_perm(
    mask,
    mode,
    wave_size,
    waves_per_block,
    fiedler_iters,
    fiedler_trivial_mix,
    spectral_dim,
    cluster_waves,
    kmeans_iters,
    adaptive_min_gain,
    adaptive_reuse_iters,
    band_size,
    max_band_rows,
    greedy_window,
    refine_init,
    refine_passes,
    refine_neighbor_waves,
    refine_candidate_rows,
    refine_shear_weight,
    joint_window,
    joint_nnz_weight,
    center_scale_floor,
    union_candidate_window,
    union_select_chunk,
    union_rank_weight,
    union_shear_weight,
    union_popularity_power,
    auction_group_waves,
    auction_oversample,
    auction_candidate_window,
    auction_chunk_per_wave,
    auction_rank_weight,
    auction_shear_weight,
    auction_borrow_weight,
    auction_elastic_window,
    auction_max_candidate_window,
    auction_tie_tol,
    auction_guarded_elastic,
    auction_elastic_margin,
    auction_sequence_start_first,
    auction_sequence_overlap_window,
    auction_sliding_cache_waves,
    auction_sliding_cache_weight,
    auction_row_window_size,
    auction_row_window_weight,
    rolling_cache_waves,
    rolling_current_weight,
    rolling_cache_weight,
    union_spectral_window,
    union_spectral_weight,
    segment_union_weight,
    segment_transition_weight,
    segment_interval_weight,
    segment_q_span_weight,
):
    H, MB, _ = mask.shape
    if mode == "no_reorder":
        return torch.arange(MB, device=mask.device).unsqueeze(0).expand(H, -1).contiguous()
    if mode == "nnz_reorder":
        return torch.argsort(mask.sum(dim=2), descending=True, dim=1)

    mask = mask.float()

    try:
        from vllm_omni.diffusion.attention.backends.greedy_reorder_cuda import (
            adaptive_spectral_reorder,
            adaptive_spectral_grouped_reorder,
            adaptive_seeded_grouped_reorder,
            auction_exact_path_reorder,
            auction_union_reorder_cuda,
            banded_union_wave_reorder,
            banded_union_sequenced_wave_reorder,
            banded_weighted_union_wave_reorder,
            bcg_l2_reorder_cuda,
            balanced_assignment_wave_reorder,
            bootes_spectral_wave_reorder,
            capacity_refined_wave_reorder,
            centered_morton_wave_reorder,
            fiedler_local_nnz_reorder,
            fiedler_mixed_nnz_reorder,
            fiedler_seeded_wave_reorder,
            fiedler_wave_reorder,
            hybrid_block_reorder,
            hypergraph_fm_nnz_reorder,
            joint_overlap_nnz_reorder,
            marginal_union_wave_reorder,
            nnz_macro_centroid_reorder,
            nnz_3step_reorder,
            nnz_macro_structural_reorder,
            nnz_macro_spectral_bisect_reorder,
            optimal_reorder_cuda,
            partition_refined_union_reorder,
            rolling_union_wave_reorder,
            spectral_union_wave_reorder,
            segment_partition_reorder,
            spectral_morton_path_reorder,
            spectral_morton_wave_reorder,
            svd_deflation_reorder,
            svd_u2u3_reorder,
            wave_1d_reorder,
            wave_2d_reorder,
            wave_overlap_reorder,
        )
    except ImportError:
        import vllm_omni.diffusion.attention.backends.greedy_reorder_cuda as _mod
        adaptive_spectral_reorder = getattr(_mod, "adaptive_spectral_reorder", None)
        adaptive_spectral_grouped_reorder = getattr(_mod, "adaptive_spectral_grouped_reorder", None)
        adaptive_seeded_grouped_reorder = getattr(_mod, "adaptive_seeded_grouped_reorder", None)
        auction_exact_path_reorder = getattr(_mod, "auction_exact_path_reorder", None)
        auction_union_reorder_cuda = getattr(_mod, "auction_union_reorder_cuda", None)
        banded_union_wave_reorder = getattr(_mod, "banded_union_wave_reorder", None)
        banded_union_sequenced_wave_reorder = getattr(_mod, "banded_union_sequenced_wave_reorder", None)
        banded_weighted_union_wave_reorder = getattr(_mod, "banded_weighted_union_wave_reorder", None)
        bcg_l2_reorder_cuda = getattr(_mod, "bcg_l2_reorder_cuda", None)
        balanced_assignment_wave_reorder = getattr(_mod, "balanced_assignment_wave_reorder", None)
        bootes_spectral_wave_reorder = getattr(_mod, "bootes_spectral_wave_reorder", None)
        capacity_refined_wave_reorder = getattr(_mod, "capacity_refined_wave_reorder", None)
        centered_morton_wave_reorder = getattr(_mod, "centered_morton_wave_reorder", None)
        fiedler_local_nnz_reorder = getattr(_mod, "fiedler_local_nnz_reorder", None)
        fiedler_mixed_nnz_reorder = getattr(_mod, "fiedler_mixed_nnz_reorder", None)
        fiedler_seeded_wave_reorder = getattr(_mod, "fiedler_seeded_wave_reorder", None)
        fiedler_wave_reorder = getattr(_mod, "fiedler_wave_reorder", None)
        hybrid_block_reorder = getattr(_mod, "hybrid_block_reorder", None)
        hypergraph_fm_nnz_reorder = getattr(_mod, "hypergraph_fm_nnz_reorder", None)
        joint_overlap_nnz_reorder = getattr(_mod, "joint_overlap_nnz_reorder", None)
        marginal_union_wave_reorder = getattr(_mod, "marginal_union_wave_reorder", None)
        nnz_macro_centroid_reorder = getattr(_mod, "nnz_macro_centroid_reorder", None)
        nnz_3step_reorder = getattr(_mod, "nnz_3step_reorder", None)
        nnz_macro_structural_reorder = getattr(_mod, "nnz_macro_structural_reorder", None)
        nnz_macro_spectral_bisect_reorder = getattr(_mod, "nnz_macro_spectral_bisect_reorder", None)
        optimal_reorder_cuda = getattr(_mod, "optimal_reorder_cuda", None)
        partition_refined_union_reorder = getattr(_mod, "partition_refined_union_reorder", None)
        rolling_union_wave_reorder = getattr(_mod, "rolling_union_wave_reorder", None)
        spectral_union_wave_reorder = getattr(_mod, "spectral_union_wave_reorder", None)
        segment_partition_reorder = getattr(_mod, "segment_partition_reorder", None)
        spectral_morton_path_reorder = getattr(_mod, "spectral_morton_path_reorder", None)
        spectral_morton_wave_reorder = getattr(_mod, "spectral_morton_wave_reorder", None)
        svd_deflation_reorder = getattr(_mod, "svd_deflation_reorder", None)
        svd_u2u3_reorder = getattr(_mod, "svd_u2u3_reorder", None)
        wave_1d_reorder = getattr(_mod, "wave_1d_reorder", None)
        wave_2d_reorder = getattr(_mod, "wave_2d_reorder", None)
        wave_overlap_reorder = getattr(_mod, "wave_overlap_reorder", None)

    if mode == "nnz_3step_reorder":
        return nnz_3step_reorder(mask, wave_size=wave_size)
    if mode == "nnz_macro_wave_reorder":
        return nnz_macro_structural_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            method="identity",
            n_iter=fiedler_iters,
            sequence_start_first=auction_sequence_start_first,
        )
    if mode == "nnz_macro_svd1_reorder":
        return nnz_macro_structural_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            method="svd1",
            n_iter=fiedler_iters,
            sequence_start_first=auction_sequence_start_first,
        )
    if mode == "nnz_macro_svd2_reorder":
        return nnz_macro_structural_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            method="svd2",
            n_iter=fiedler_iters,
            sequence_start_first=auction_sequence_start_first,
        )
    if mode == "nnz_macro_fiedler_reorder":
        return nnz_macro_structural_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            method="fiedler",
            n_iter=fiedler_iters,
            sequence_start_first=auction_sequence_start_first,
        )
    if mode == "nnz_macro_centroid_reorder":
        return nnz_macro_centroid_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            sequence_waves=auction_sequence_start_first,
        )
    if mode == "nnz_macro_spectral_bisect_reorder":
        return nnz_macro_spectral_bisect_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            spectral_dim=spectral_dim,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
        )
    if mode == "wave_reorder":
        return wave_overlap_reorder(mask, wave_size=wave_size)
    if mode == "wave_1d_reorder":
        return wave_1d_reorder(mask, wave_size=wave_size)
    if mode == "wave_2d_reorder":
        return wave_2d_reorder(mask, wave_size=wave_size)
    if mode == "svd_u2u3_reorder":
        return svd_u2u3_reorder(mask, wave_size=wave_size, n_iter=fiedler_iters)
    if mode == "svd_deflation_reorder":
        return svd_deflation_reorder(mask, wave_size=wave_size, n_iter=fiedler_iters)
    if mode == "fiedler_wave_reorder":
        return fiedler_wave_reorder(mask, wave_size=wave_size, n_iter=fiedler_iters)
    if mode == "fiedler_local_nnz_reorder":
        return fiedler_local_nnz_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            n_iter=fiedler_iters,
        )
    if mode == "fiedler_mixed_nnz_reorder":
        return fiedler_mixed_nnz_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
        )
    if mode == "fiedler_seeded_wave_reorder":
        return fiedler_seeded_wave_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
            candidate_multiplier=max(1, joint_window // max(1, wave_size)),
            rank_weight=joint_nnz_weight,
        )
    if mode == "bootes_spectral_wave_reorder":
        return bootes_spectral_wave_reorder(
            mask,
            wave_size=wave_size,
            spectral_dim=spectral_dim,
            waves_per_cluster=cluster_waves,
            n_iter=fiedler_iters,
            kmeans_iter=kmeans_iters,
        )
    if mode == "spectral_morton_wave_reorder":
        return spectral_morton_wave_reorder(
            mask,
            wave_size=wave_size,
            spectral_dim=spectral_dim,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
        )
    if mode == "spectral_morton_path_reorder":
        return spectral_morton_path_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            spectral_dim=spectral_dim,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
        )
    if mode == "centered_morton_wave_reorder":
        return centered_morton_wave_reorder(
            mask,
            wave_size=wave_size,
            spectral_dim=spectral_dim,
            n_iter=fiedler_iters,
            scale_floor=center_scale_floor,
        )
    if mode == "adaptive_spectral_reorder":
        return adaptive_spectral_reorder(
            mask,
            wave_size=wave_size,
            n_iter=fiedler_iters,
            min_expected_gain=adaptive_min_gain,
            reuse_iters=adaptive_reuse_iters,
        )
    if mode == "adaptive_spectral_grouped_reorder":
        return adaptive_spectral_grouped_reorder(
            mask,
            wave_size=wave_size,
            n_iter=fiedler_iters,
            min_expected_gain=adaptive_min_gain,
        )
    if mode == "adaptive_seeded_grouped_reorder":
        return adaptive_seeded_grouped_reorder(
            mask,
            wave_size=wave_size,
            n_iter=fiedler_iters,
            min_expected_gain=adaptive_min_gain,
        )
    if mode == "capacity_refined_wave_reorder":
        return capacity_refined_wave_reorder(
            mask,
            wave_size=wave_size,
            init=refine_init,
            n_iter=fiedler_iters,
            refine_passes=refine_passes,
            neighbor_waves=refine_neighbor_waves,
            candidate_rows=refine_candidate_rows,
            shear_weight=refine_shear_weight,
        )
    if mode == "hypergraph_fm_nnz_reorder":
        return hypergraph_fm_nnz_reorder(
            mask,
            wave_size=wave_size,
            refine_passes=refine_passes,
            neighbor_waves=refine_neighbor_waves,
            candidate_rows=refine_candidate_rows,
            shear_weight=refine_shear_weight,
        )
    if mode == "balanced_assignment_wave_reorder":
        return balanced_assignment_wave_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            n_iter=fiedler_iters,
            trivial_mix=fiedler_trivial_mix,
            rank_weight=joint_nnz_weight,
        )
    if mode == "marginal_union_wave_reorder":
        return marginal_union_wave_reorder(
            mask,
            wave_size=wave_size,
            candidate_window=union_candidate_window,
            select_chunk=union_select_chunk,
            rank_weight=union_rank_weight,
            shear_weight=union_shear_weight,
        )
    if mode == "banded_union_wave_reorder":
        return banded_union_wave_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            candidate_window=union_candidate_window,
            select_chunk=union_select_chunk,
        )
    if mode == "banded_weighted_union_wave_reorder":
        return banded_weighted_union_wave_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            candidate_window=union_candidate_window,
            select_chunk=union_select_chunk,
            popularity_power=union_popularity_power,
        )
    if mode == "banded_union_sequenced_wave_reorder":
        return banded_union_sequenced_wave_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
            candidate_window=union_candidate_window,
            select_chunk=union_select_chunk,
        )
    if mode == "auction_union_reorder_cuda":
        return auction_union_reorder_cuda(
            mask,
            wave_size=wave_size,
            group_waves=auction_group_waves,
            oversample=auction_oversample,
            candidate_window=auction_candidate_window,
            chunk_per_wave=auction_chunk_per_wave,
            rank_weight=auction_rank_weight,
            shear_weight=auction_shear_weight,
            borrow_weight=auction_borrow_weight,
            elastic_window=auction_elastic_window,
            max_candidate_window=auction_max_candidate_window,
            tie_tol=auction_tie_tol,
            guarded_elastic=auction_guarded_elastic,
            elastic_margin=auction_elastic_margin,
            sequence_start_first=auction_sequence_start_first,
            sequence_overlap_window=auction_sequence_overlap_window,
            sliding_cache_waves=auction_sliding_cache_waves,
            sliding_cache_weight=auction_sliding_cache_weight,
            row_window_size=auction_row_window_size,
            row_window_weight=auction_row_window_weight,
        )
    if mode == "auction_exact_path_reorder":
        return auction_exact_path_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
        )
    if mode == "partition_refined_union_reorder":
        return partition_refined_union_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            refine_passes=refine_passes,
            candidate_rows=refine_candidate_rows,
            neighbor_waves=refine_neighbor_waves,
        )
    if mode == "segment_partition_reorder":
        return segment_partition_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=auction_group_waves,
            refine_passes=refine_passes,
            candidate_rows=refine_candidate_rows,
            neighbor_waves=refine_neighbor_waves,
            union_weight=segment_union_weight,
            transition_weight=segment_transition_weight,
            interval_weight=segment_interval_weight,
            q_span_weight=segment_q_span_weight,
        )
    if mode == "rolling_union_wave_reorder":
        return rolling_union_wave_reorder(
            mask,
            wave_size=wave_size,
            candidate_window=union_candidate_window,
            select_chunk=union_select_chunk,
            cache_waves=rolling_cache_waves,
            current_weight=rolling_current_weight,
            cache_weight=rolling_cache_weight,
            rank_weight=union_rank_weight,
            shear_weight=union_shear_weight,
        )
    if mode == "spectral_union_wave_reorder":
        return spectral_union_wave_reorder(
            mask,
            wave_size=wave_size,
            candidate_window=union_candidate_window,
            spectral_window=union_spectral_window,
            select_chunk=union_select_chunk,
            rank_weight=union_rank_weight,
            spectral_weight=union_spectral_weight,
            n_iter=fiedler_iters,
        )
    if mode == "optimal_reorder_cuda":
        return optimal_reorder_cuda(
            mask,
            band_size=band_size,
            max_band_rows=max_band_rows,
            window=greedy_window,
        )
    if mode == "bcg_l2_reorder_cuda":
        return bcg_l2_reorder_cuda(
            mask,
            band_size=band_size,
            max_band_rows=max_band_rows,
            window=greedy_window,
        )
    if mode == "hybrid_block_reorder":
        return hybrid_block_reorder(
            mask,
            wave_size=wave_size,
            waves_per_block=waves_per_block,
        )
    if mode == "joint_overlap_nnz_reorder":
        return joint_overlap_nnz_reorder(
            mask,
            wave_size=wave_size,
            candidate_window=joint_window,
            nnz_weight=joint_nnz_weight,
        )
    raise ValueError(f"Unknown mode: {mode}")


def format_method_label(args, mode):
    if mode == "fiedler_local_nnz_reorder":
        return f"{mode}_wpb{args.waves_per_block}"
    if mode == "fiedler_mixed_nnz_reorder":
        mix = f"{args.fiedler_trivial_mix:g}".replace(".", "p")
        return f"{mode}_mix{mix}_wpb{args.waves_per_block}"
    if mode.startswith("nnz_macro_"):
        start = "_startfirst" if args.auction_sequence_start_first else ""
        return f"{mode}_gw{args.auction_group_waves}_it{args.fiedler_iters}{start}"
    if mode == "bootes_spectral_wave_reorder":
        return f"{mode}_d{args.spectral_dim}_cw{args.cluster_waves}"
    if mode == "spectral_morton_wave_reorder":
        mix = f"{args.fiedler_trivial_mix:g}".replace(".", "p")
        return f"{mode}_d{args.spectral_dim}_mix{mix}"
    if mode == "spectral_morton_path_reorder":
        mix = f"{args.fiedler_trivial_mix:g}".replace(".", "p")
        return f"{mode}_d{args.spectral_dim}_mix{mix}_gw{args.auction_group_waves}"
    if mode == "hybrid_block_reorder":
        return f"{mode}_wpb{args.waves_per_block}"
    if mode == "joint_overlap_nnz_reorder":
        weight = f"{args.joint_nnz_weight:g}".replace(".", "p")
        return f"{mode}_win{args.joint_window}_nw{weight}"
    if args.kv_order == "asc":
        suffix = ""
    elif args.kv_order == "edge_dp":
        suffix = f"_kv{args.kv_order}{args.kv_edge_blocks}"
    else:
        suffix = f"_kv{args.kv_order}"
    if mode == "auction_union_reorder_cuda":
        rw = f"{args.auction_rank_weight:g}".replace(".", "p")
        sw = f"{args.auction_shear_weight:g}".replace(".", "p")
        bw = f"{args.auction_borrow_weight:g}".replace(".", "p")
        elastic = ""
        if args.auction_elastic_window:
            tol = f"{args.auction_tie_tol:g}".replace(".", "p")
            elastic = f"_elastic{args.auction_max_candidate_window}_tol{tol}"
            if args.auction_guarded_elastic:
                margin = f"{args.auction_elastic_margin:g}".replace(".", "p")
                elastic += f"_guard{margin}"
        start = "_startfirst" if args.auction_sequence_start_first else ""
        seq = ""
        if args.auction_sequence_overlap_window != 1:
            seq = f"_seqwin{args.auction_sequence_overlap_window}"
        slide = ""
        if args.auction_sliding_cache_waves > 0 and args.auction_sliding_cache_weight != 0.0:
            scw = f"{args.auction_sliding_cache_weight:g}".replace(".", "p")
            slide = f"_slide{args.auction_sliding_cache_waves}w{scw}"
        rowwin = ""
        if args.auction_row_window_size > 0 and args.auction_row_window_weight != 0.0:
            rww = f"{args.auction_row_window_weight:g}".replace(".", "p")
            rowwin = f"_rowwin{args.auction_row_window_size}w{rww}"
        return (
            f"{mode}_gw{args.auction_group_waves}"
            f"_cw{args.auction_candidate_window}"
            f"_cpw{args.auction_chunk_per_wave}"
            f"_rw{rw}_sw{sw}_bw{bw}"
            f"{elastic}"
            f"{start}"
            f"{seq}"
            f"{slide}"
            f"{rowwin}"
            f"{suffix}"
        )
    if mode == "partition_refined_union_reorder":
        return (
            f"{mode}_gw{args.auction_group_waves}"
            f"_p{args.refine_passes}"
            f"_cr{args.refine_candidate_rows}"
            f"_nw{args.refine_neighbor_waves}"
            f"{suffix}"
        )
    if mode == "hypergraph_fm_nnz_reorder":
        sw = f"{args.refine_shear_weight:g}".replace(".", "p")
        return (
            f"{mode}"
            f"_p{args.refine_passes}"
            f"_cr{args.refine_candidate_rows}"
            f"_nw{args.refine_neighbor_waves}"
            f"_sw{sw}"
            f"{suffix}"
        )
    if mode == "auction_exact_path_reorder":
        return f"{mode}_gw{args.auction_group_waves}{suffix}"
    if mode == "segment_partition_reorder":
        uw = f"{args.segment_union_weight:g}".replace(".", "p")
        tw = f"{args.segment_transition_weight:g}".replace(".", "p")
        iw = f"{args.segment_interval_weight:g}".replace(".", "p")
        qw = f"{args.segment_q_span_weight:g}".replace(".", "p")
        return (
            f"{mode}_gw{args.auction_group_waves}"
            f"_p{args.refine_passes}"
            f"_cr{args.refine_candidate_rows}"
            f"_nw{args.refine_neighbor_waves}"
            f"_uw{uw}_tw{tw}"
            f"_iw{iw}_qw{qw}"
            f"{suffix}"
        )
    return f"{mode}{suffix}"


def validate_perm(perm):
    H, MB = perm.shape
    expected = torch.arange(MB, device=perm.device).unsqueeze(0).expand(H, -1)
    if not torch.equal(perm.sort(dim=1).values, expected):
        raise ValueError("Invalid permutation: duplicate or out-of-range row index")


def apply_row_perm(mask, perm):
    return torch.gather(mask, 1, perm.unsqueeze(-1).expand_as(mask))


def compute_static_metrics(mask, perm, wave_size):
    reordered = apply_row_perm(mask, perm).bool()
    H, MB, NB = reordered.shape
    nnz = reordered.sum(dim=2).float()
    n_waves = (MB + wave_size - 1) // wave_size
    pad = n_waves * wave_size - MB
    valid_rows = torch.ones(H, MB, device=mask.device, dtype=torch.bool)

    if pad > 0:
        reordered = torch.cat(
            [reordered, torch.zeros(H, pad, NB, device=mask.device, dtype=torch.bool)],
            dim=1,
        )
        nnz = torch.cat([nnz, torch.zeros(H, pad, device=mask.device)], dim=1)
        valid_rows = torch.cat(
            [valid_rows, torch.zeros(H, pad, device=mask.device, dtype=torch.bool)],
            dim=1,
        )

    wave_nnz = nnz.view(H, n_waves, wave_size)
    wave_valid = valid_rows.view(H, n_waves, wave_size)
    wave_mask = reordered.view(H, n_waves, wave_size, NB)
    total = wave_mask.sum(dim=(2, 3)).float()
    unique = wave_mask.any(dim=2).sum(dim=2).float()
    reuse = ((total - unique) / total.clamp(min=1)).mean()

    valid_count = wave_valid.sum(dim=2).float().clamp(min=1)
    wave_sum = (wave_nnz * wave_valid.float()).sum(dim=2)
    wave_mean = wave_sum / valid_count
    centered = torch.where(wave_valid, wave_nnz - wave_mean.unsqueeze(2), torch.zeros_like(wave_nnz))
    wave_std = (centered.square().sum(dim=2) / valid_count).sqrt()
    wave_cv = (wave_std / wave_mean.clamp(min=1)).mean()
    wave_max = wave_nnz.masked_fill(~wave_valid, -1e30).max(dim=2).values
    wave_min = wave_nnz.masked_fill(~wave_valid, 1e30).min(dim=2).values
    wave_range = (wave_max - wave_min).mean()

    return {
        "density": mask.float().mean().item(),
        "avg_nnz_per_row": mask.sum(dim=2).float().mean().item(),
        "wave_nnz_cv": wave_cv.item(),
        "wave_nnz_range": wave_range.item(),
        "wave_reuse": reuse.item(),
    }


def compute_boundary_dp_desc_waves(reordered, wave_size):
    """Choose per-wave KV direction by minimizing adjacent boundary jumps."""
    H, MB, NB = reordered.shape
    n_waves = (MB + wave_size - 1) // wave_size
    pad = n_waves * wave_size - MB
    if pad > 0:
        reordered = torch.cat(
            [reordered, torch.zeros(H, pad, NB, device=reordered.device, dtype=torch.bool)],
            dim=1,
        )
    wave_union = reordered.view(H, n_waves, wave_size, NB).any(dim=2)
    cols = torch.arange(NB, device=reordered.device).view(1, 1, NB)
    lo = torch.where(wave_union, cols, torch.full_like(cols, NB)).min(dim=2).values.float()
    hi = torch.where(wave_union, cols, torch.full_like(cols, -1)).max(dim=2).values.float()
    empty = hi < 0
    lo = torch.where(empty, torch.zeros_like(lo), lo)
    hi = torch.where(empty, torch.zeros_like(hi), hi)

    desc_waves = torch.zeros(H, n_waves, device=reordered.device, dtype=torch.bool)
    if n_waves <= 1:
        return desc_waves[:, :MB]

    for h in range(H):
        start = torch.stack([lo[h], hi[h]], dim=1)
        end = torch.stack([hi[h], lo[h]], dim=1)
        dp = torch.zeros(n_waves, 2, device=reordered.device, dtype=torch.float32)
        parent = torch.zeros(n_waves, 2, device=reordered.device, dtype=torch.long)
        for w in range(1, n_waves):
            cost = dp[w - 1].view(2, 1) + (end[w - 1].view(2, 1) - start[w].view(1, 2)).abs()
            dp[w], parent[w] = cost.min(dim=0)
        cur = int(dp[-1].argmin().item())
        for w in range(n_waves - 1, -1, -1):
            desc_waves[h, w] = bool(cur)
            cur = int(parent[w, cur].item()) if w > 0 else 0
    return desc_waves


def compute_edge_dp_desc_waves(sorted_cols, cnt_all, wave_size, edge_blocks):
    """Choose per-wave KV direction by maximizing adjacent edge-set overlap."""
    H, MB, NB = sorted_cols.shape
    device = sorted_cols.device
    n_waves = (MB + wave_size - 1) // wave_size
    edge_blocks = max(1, int(edge_blocks))
    pos = torch.arange(NB, device=device).view(1, 1, NB)
    edge = cnt_all.clamp(max=edge_blocks).unsqueeze(-1)
    edge_valid = pos < edge

    desc_src = torch.where(
        pos < cnt_all.unsqueeze(-1),
        (cnt_all.unsqueeze(-1) - 1 - pos).clamp(min=0),
        pos,
    )
    desc_cols = torch.gather(sorted_cols, 2, desc_src.long())

    start_mask = torch.zeros(H, MB, NB, device=device, dtype=torch.bool)
    end_mask = torch.zeros(H, MB, NB, device=device, dtype=torch.bool)
    start_mask.scatter_(2, sorted_cols.long(), edge_valid)
    end_mask.scatter_(2, desc_cols.long(), edge_valid)

    pad = n_waves * wave_size - MB
    if pad > 0:
        start_mask = torch.cat(
            [start_mask, torch.zeros(H, pad, NB, device=device, dtype=torch.bool)],
            dim=1,
        )
        end_mask = torch.cat(
            [end_mask, torch.zeros(H, pad, NB, device=device, dtype=torch.bool)],
            dim=1,
        )

    wave_start = start_mask.view(H, n_waves, wave_size, NB).any(dim=2)
    wave_end = end_mask.view(H, n_waves, wave_size, NB).any(dim=2)
    desc_waves = torch.zeros(H, n_waves, device=device, dtype=torch.bool)
    if n_waves <= 1:
        return desc_waves

    for h in range(H):
        # orientation 0: asc, 1: desc
        starts = [wave_start[h], wave_end[h]]
        ends = [wave_end[h], wave_start[h]]
        dp = torch.zeros(n_waves, 2, device=device, dtype=torch.float32)
        parent = torch.zeros(n_waves, 2, device=device, dtype=torch.long)
        for w in range(1, n_waves):
            cost = torch.empty(2, 2, device=device, dtype=torch.float32)
            for prev_o in range(2):
                for cur_o in range(2):
                    overlap = (ends[prev_o][w - 1] & starts[cur_o][w]).sum().float()
                    cost[prev_o, cur_o] = dp[w - 1, prev_o] - overlap
            dp[w], parent[w] = cost.min(dim=0)
        cur = int(dp[-1].argmin().item())
        for w in range(n_waves - 1, -1, -1):
            desc_waves[h, w] = bool(cur)
            cur = int(parent[w, cur].item()) if w > 0 else 0
    return desc_waves


def build_blocksparse_tensors(mask, perm, block_size, wave_size, kv_order, kv_edge_blocks):
    reordered = apply_row_perm(mask.bool(), perm).contiguous()
    H, MB, NB = reordered.shape

    cnt_all = reordered.sum(dim=-1, dtype=torch.int32)
    col_range = torch.arange(NB, device=mask.device).view(1, 1, NB)
    if kv_order == "asc":
        chunk_rows = max(1, int(os.environ.get("FA4_METADATA_CHUNK_ROWS", "64")))
        idx_4d = torch.empty((1, H, MB, NB), dtype=torch.int32, device=mask.device)
        for start in range(0, MB, chunk_rows):
            end = min(start + chunk_rows, MB)
            sorted_chunk = torch.argsort(~reordered[:, start:end, :], dim=2, stable=True).int()
            valid_chunk = col_range < cnt_all[:, start:end].unsqueeze(-1)
            idx_4d[0, :, start:end, :] = sorted_chunk * valid_chunk.int()
            del sorted_chunk, valid_chunk

        cnt_4d = cnt_all.unsqueeze(0).contiguous()
        return cnt_4d, idx_4d.contiguous()

    sorted_cols = torch.argsort(~reordered, dim=2, stable=True).int()
    valid = col_range < cnt_all.unsqueeze(-1)
    if kv_order != "asc":
        src = torch.where(
            valid,
            (cnt_all.unsqueeze(-1) - 1 - col_range).clamp(min=0),
            col_range,
        )
        desc_cols = torch.gather(sorted_cols, 2, src.long())
        if kv_order == "desc":
            sorted_cols = desc_cols
        elif kv_order in ("snake", "snake_inv"):
            wave_id = torch.arange(MB, device=mask.device).view(1, MB, 1) // int(wave_size)
            # snake: 1-based odd waves ascend, even waves descend.
            desc_wave = (wave_id % 2 == 1)
            if kv_order == "snake_inv":
                desc_wave = ~desc_wave
            sorted_cols = torch.where(desc_wave, desc_cols, sorted_cols)
        elif kv_order == "boundary_dp":
            wave_desc = compute_boundary_dp_desc_waves(reordered, int(wave_size))
            desc_rows = wave_desc.repeat_interleave(int(wave_size), dim=1)[:, :MB].unsqueeze(2)
            sorted_cols = torch.where(desc_rows, desc_cols, sorted_cols)
        elif kv_order == "edge_dp":
            wave_desc = compute_edge_dp_desc_waves(
                sorted_cols,
                cnt_all,
                int(wave_size),
                int(kv_edge_blocks),
            )
            desc_rows = wave_desc.repeat_interleave(int(wave_size), dim=1)[:, :MB].unsqueeze(2)
            sorted_cols = torch.where(desc_rows, desc_cols, sorted_cols)
        else:
            raise ValueError(f"Unsupported kv_order={kv_order}")
    sorted_cols = sorted_cols * valid.int()

    cnt_4d = cnt_all.unsqueeze(0).contiguous()
    idx_4d = sorted_cols.unsqueeze(0).contiguous()
    return cnt_4d, idx_4d


def reorder_q_for_fa4(q_bhsd, perm, block_size):
    B, H, S, D = q_bhsd.shape
    MB = S // block_size
    q_fa4 = q_bhsd.transpose(1, 2).contiguous()  # (B, S, H, D)
    q_blocks = q_fa4.view(B, MB, block_size, H, D)
    gather_idx = (
        perm.T.unsqueeze(0)
        .unsqueeze(2)
        .unsqueeze(4)
        .expand(B, MB, block_size, H, D)
    )
    return torch.gather(q_blocks, 1, gather_idx).reshape(B, S, H, D).contiguous()


def benchmark_fa4(q, k, v, mask, perm, block_size, wave_size, kv_order, kv_edge_blocks, warmup, repeat, profile):
    from flash_attn.cute.interface import _flash_attn_fwd as _fa4_fwd
    try:
        from flash_attn.cute.block_sparsity import BlockSparseTensorsTorch
    except Exception:
        from vllm_omni.diffusion.attention.backends.flash_attn import BlockSparseTensorsTorch

    B, H, S, D = q.shape
    MB = S // block_size
    NB = MB
    q_fa4 = reorder_q_for_fa4(q, perm, block_size)
    k_fa4 = k.transpose(1, 2).contiguous()
    v_fa4 = v.transpose(1, 2).contiguous()
    cnt_4d, idx_4d = build_blocksparse_tensors(mask, perm, block_size, wave_size, kv_order, kv_edge_blocks)
    sig = inspect.signature(_fa4_fwd)
    if "tile_mn" in sig.parameters:
        block_kwargs = {"tile_mn": (block_size, block_size)}
    else:
        block_kwargs = {"m_block_size": block_size, "n_block_size": block_size}

    bst = BlockSparseTensorsTorch(
        full_block_cnt=cnt_4d,
        full_block_idx=idx_4d,
        mask_block_cnt=torch.zeros_like(cnt_4d),
        mask_block_idx=torch.zeros(B, H, MB, NB, dtype=torch.int32, device=q.device),
        block_size=(block_size, block_size),
    )

    for _ in range(warmup):
        out, _ = _fa4_fwd(
            q_fa4,
            k_fa4,
            v_fa4,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(repeat):
        out, _ = _fa4_fwd(
            q_fa4,
            k_fa4,
            v_fa4,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
    end.record()
    torch.cuda.synchronize()
    avg_ms = start.elapsed_time(end) / max(repeat, 1)

    if profile:
        print("=== NCU PROFILE REGION ===", flush=True)
        torch.cuda.cudart().cudaProfilerStart()
        out, _ = _fa4_fwd(
            q_fa4,
            k_fa4,
            v_fa4,
            block_sparse_tensors=bst,
            **block_kwargs,
        )
        torch.cuda.synchronize()
        torch.cuda.cudart().cudaProfilerStop()
        print("=== NCU PROFILE DONE ===", flush=True)

    # Keep out live until after synchronization.
    del out, bst, q_fa4, k_fa4, v_fa4, cnt_4d, idx_4d
    torch.cuda.empty_cache()
    return avg_ms


def append_csv(path, row, fieldnames):
    file_exists = Path(path).exists()
    with open(path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def run_one(args, dump_path, threshold, mode):
    q, k, v, orig_len, padded_len, dump_label = load_qkv(
        dump_path,
        block_size=args.block_size,
        chunk_size=args.chunk_size,
        heads=args.heads,
        blocks=args.blocks,
        layer=args.layer,
        timestep=args.timestep,
        head_start=args.head_start,
    )
    method_label = format_method_label(args, mode)
    B, H, S, D = q.shape
    MB = S // args.block_size
    print(
        f"Loaded {dump_path} | B={B} H={H} D={D} orig_len={orig_len} "
        f"padded_len={padded_len} MB={MB} threshold={threshold} mode={method_label}",
        flush=True,
    )
    if S != MB * args.block_size:
        raise AssertionError("QKV padding failed: S != MB * block_size")

    print("Building xattn threshold mask ...", flush=True)
    t0 = time.perf_counter()
    mask = build_xattn_threshold_mask(
        q,
        k,
        block_size=args.block_size,
        stride=args.stride,
        threshold=threshold,
        chunk_size=args.chunk_size,
    )
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    mask_ms = (time.perf_counter() - t0) * 1000.0

    if mask.shape != (H, MB, MB):
        raise AssertionError(f"Unexpected mask shape {tuple(mask.shape)}, expected {(H, MB, MB)}")

    print(
        f"Mask shape={tuple(mask.shape)} density={mask.float().mean().item():.4f} "
        f"avg_nnz={mask.sum(dim=2).float().mean().item():.1f} mask_ms={mask_ms:.1f}",
        flush=True,
    )

    print("Computing reorder permutation ...", flush=True)
    t1 = time.perf_counter()
    perm = compute_perm(
        mask,
        mode=mode,
        wave_size=args.wave_size,
        waves_per_block=args.waves_per_block,
        fiedler_iters=args.fiedler_iters,
        fiedler_trivial_mix=args.fiedler_trivial_mix,
        spectral_dim=args.spectral_dim,
        cluster_waves=args.cluster_waves,
        kmeans_iters=args.kmeans_iters,
        adaptive_min_gain=args.adaptive_min_gain,
        adaptive_reuse_iters=args.adaptive_reuse_iters,
        band_size=args.band_size,
        max_band_rows=args.max_band_rows,
        greedy_window=args.greedy_window,
        refine_init=args.refine_init,
        refine_passes=args.refine_passes,
        refine_neighbor_waves=args.refine_neighbor_waves,
        refine_candidate_rows=args.refine_candidate_rows,
        refine_shear_weight=args.refine_shear_weight,
        joint_window=args.joint_window,
        joint_nnz_weight=args.joint_nnz_weight,
        center_scale_floor=args.center_scale_floor,
        union_candidate_window=args.union_candidate_window,
        union_select_chunk=args.union_select_chunk,
        union_rank_weight=args.union_rank_weight,
        union_shear_weight=args.union_shear_weight,
        union_popularity_power=args.union_popularity_power,
        auction_group_waves=args.auction_group_waves,
        auction_oversample=args.auction_oversample,
        auction_candidate_window=args.auction_candidate_window,
        auction_chunk_per_wave=args.auction_chunk_per_wave,
        auction_rank_weight=args.auction_rank_weight,
        auction_shear_weight=args.auction_shear_weight,
        auction_borrow_weight=args.auction_borrow_weight,
        auction_elastic_window=args.auction_elastic_window,
        auction_max_candidate_window=args.auction_max_candidate_window,
        auction_tie_tol=args.auction_tie_tol,
        auction_guarded_elastic=args.auction_guarded_elastic,
        auction_elastic_margin=args.auction_elastic_margin,
        auction_sequence_start_first=args.auction_sequence_start_first,
        auction_sequence_overlap_window=args.auction_sequence_overlap_window,
        auction_sliding_cache_waves=args.auction_sliding_cache_waves,
        auction_sliding_cache_weight=args.auction_sliding_cache_weight,
        auction_row_window_size=args.auction_row_window_size,
        auction_row_window_weight=args.auction_row_window_weight,
        rolling_cache_waves=args.rolling_cache_waves,
        rolling_current_weight=args.rolling_current_weight,
        rolling_cache_weight=args.rolling_cache_weight,
        union_spectral_window=args.union_spectral_window,
        union_spectral_weight=args.union_spectral_weight,
        segment_union_weight=args.segment_union_weight,
        segment_transition_weight=args.segment_transition_weight,
        segment_interval_weight=args.segment_interval_weight,
        segment_q_span_weight=args.segment_q_span_weight,
    )
    torch.cuda.synchronize()
    reorder_ms = (time.perf_counter() - t1) * 1000.0
    validate_perm(perm)

    static = compute_static_metrics(mask, perm, args.wave_size)
    print(
        f"Static: wave_nnz_cv={static['wave_nnz_cv']:.4f} "
        f"wave_range={static['wave_nnz_range']:.1f} wave_reuse={static['wave_reuse']:.4f} "
        f"reorder_ms={reorder_ms:.1f}",
        flush=True,
    )

    print("Running FA4 benchmark ...", flush=True)
    torch.cuda.empty_cache()
    kernel_ms = benchmark_fa4(
        q,
        k,
        v,
        mask,
        perm,
        block_size=args.block_size,
        wave_size=args.wave_size,
        kv_order=args.kv_order,
        kv_edge_blocks=args.kv_edge_blocks,
        warmup=args.warmup,
        repeat=args.repeat,
        profile=args.profile,
    )
    print(f"[{method_label}] avg kernel time: {kernel_ms:.3f} ms", flush=True)

    row = {
        "dump": dump_label,
        "orig_len": orig_len,
        "padded_len": padded_len,
        "seq_len": S,
        "heads": H,
        "blocks": MB,
        "threshold": threshold,
        "method": method_label,
        "density": static["density"],
        "avg_nnz_per_row": static["avg_nnz_per_row"],
        "sparse_blocks": int(mask.sum().item()),
        "reorder_ms": reorder_ms,
        "mask_ms": mask_ms,
        "kernel_ms": kernel_ms,
        "dram_read": "",
        "dram_write": "",
        "l2_hit": "",
        "wave_nnz_cv": static["wave_nnz_cv"],
        "wave_nnz_range": static["wave_nnz_range"],
        "wave_reuse": static["wave_reuse"],
    }
    fieldnames = [
        "dump",
        "orig_len",
        "padded_len",
        "seq_len",
        "heads",
        "blocks",
        "threshold",
        "method",
        "density",
        "avg_nnz_per_row",
        "sparse_blocks",
        "reorder_ms",
        "mask_ms",
        "kernel_ms",
        "dram_read",
        "dram_write",
        "l2_hit",
        "wave_nnz_cv",
        "wave_nnz_range",
        "wave_reuse",
    ]
    print("RESULT_CSV," + ",".join(str(row[k]) for k in fieldnames), flush=True)
    if args.csv:
        append_csv(args.csv, row, fieldnames)

    del q, k, v, mask, perm
    torch.cuda.empty_cache()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dump", default="dense_dump_161f",
                        help="'dense_dump_161f', 'dense_dump_401f', 'all', 'ltx_all', a .pt file, or a dump directory")
    parser.add_argument("--layer", type=int, default=0,
                        help="LTX layer index when --dump points to output_ltx_step*")
    parser.add_argument("--timestep", type=int, default=-1,
                        help="LTX timestep suffix; default infers from output_ltx_step*")
    parser.add_argument("--threshold", type=float, default=0.9)
    parser.add_argument("--thresholds", default="",
                        help="Comma-separated thresholds. Overrides --threshold.")
    parser.add_argument("--mode", default="wave_reorder", choices=REORDER_MODES)
    parser.add_argument("--modes", default="",
                        help="Comma-separated modes or 'all'. Overrides --mode.")
    parser.add_argument("--waves-per-block", type=int, default=1)
    parser.add_argument("--fiedler-iters", type=int, default=20)
    parser.add_argument("--fiedler-trivial-mix", type=float, default=0.5,
                        help="For fiedler_mixed_nnz_reorder: 0=ones deflation, 1=sqrt(deg)")
    parser.add_argument("--spectral-dim", type=int, default=3,
                        help="Number of non-trivial spectral vectors for bootes_spectral_wave_reorder")
    parser.add_argument("--cluster-waves", type=int, default=4,
                        help="Target cluster size in waves for bootes_spectral_wave_reorder")
    parser.add_argument("--kmeans-iters", type=int, default=8,
                        help="KMeans iterations for bootes_spectral_wave_reorder")
    parser.add_argument("--adaptive-min-gain", type=float, default=0.10,
                        help="Skip reorder if adaptive_spectral_reorder estimates lower fractional DRAM gain")
    parser.add_argument("--adaptive-reuse-iters", type=float, default=0.0,
                        help="Expected FA4 calls reusing this permutation; 0 disables amortization gating")
    parser.add_argument("--band-size", type=int, default=4,
                        help="NNZ quantization band size for CUDA banded greedy modes")
    parser.add_argument("--max-band-rows", type=int, default=512,
                        help="Max rows per band chunk for CUDA banded greedy modes")
    parser.add_argument("--greedy-window", type=int, default=132,
                        help="Lookback/cache window for CUDA banded greedy modes")
    parser.add_argument("--refine-init", default="seeded",
                        choices=("seeded", "morton", "fiedler", "mixed", "wave"),
                        help="Initial order for capacity_refined_wave_reorder")
    parser.add_argument("--refine-passes", type=int, default=2,
                        help="Local swap passes for capacity_refined_wave_reorder")
    parser.add_argument("--refine-neighbor-waves", type=int, default=1,
                        help="Neighboring wave distance considered by capacity_refined_wave_reorder")
    parser.add_argument("--refine-candidate-rows", type=int, default=12,
                        help="Bad-fit candidate rows per wave for capacity_refined_wave_reorder")
    parser.add_argument("--refine-shear-weight", type=float, default=0.10,
                        help="NNZ range weight in capacity_refined_wave_reorder")
    parser.add_argument("--joint-window", type=int, default=768,
                        help="Lookahead rows for joint_overlap_nnz_reorder")
    parser.add_argument("--joint-nnz-weight", type=float, default=0.50,
                        help="Penalty for skipping lower in the descending-NNZ frontier")
    parser.add_argument("--center-scale-floor", type=float, default=0.05,
                        help="Variance floor for centered_morton_wave_reorder column scaling")
    parser.add_argument("--union-candidate-window", type=int, default=768,
                        help="High-NNZ frontier size for marginal_union_wave_reorder")
    parser.add_argument("--union-select-chunk", type=int, default=8,
                        help="Rows selected before updating the wave union in marginal_union_wave_reorder")
    parser.add_argument("--union-rank-weight", type=float, default=32.0,
                        help="Rank penalty, in marginal-KV columns, for marginal_union_wave_reorder")
    parser.add_argument("--union-shear-weight", type=float, default=0.0,
                        help="Penalty for increasing wave NNZ range in marginal_union_wave_reorder")
    parser.add_argument("--union-popularity-power", type=float, default=0.5,
                        help="KV column popularity discount for banded_weighted_union_wave_reorder; 0 disables weighting")
    parser.add_argument("--auction-group-waves", type=int, default=8,
                        help="Waves opened simultaneously by auction_union_reorder_cuda")
    parser.add_argument("--auction-oversample", type=int, default=2,
                        help="Candidate oversampling factor for auction_union_reorder_cuda")
    parser.add_argument("--auction-candidate-window", type=int, default=1056,
                        help="High-NNZ candidate window for auction_union_reorder_cuda")
    parser.add_argument("--auction-chunk-per-wave", type=int, default=1,
                        help="Rows selected per wave per auction round")
    parser.add_argument("--auction-rank-weight", type=float, default=0.0,
                        help="Rank penalty for auction_union_reorder_cuda")
    parser.add_argument("--auction-shear-weight", type=float, default=0.0,
                        help="NNZ shear penalty for auction_union_reorder_cuda")
    parser.add_argument("--auction-borrow-weight", type=float, default=0.0,
                        help="Penalty for borrowing rows beyond the current output group")
    parser.add_argument("--auction-elastic-window", action="store_true",
                        help="Extend auction candidate window across an NNZ plateau at the macro boundary")
    parser.add_argument("--auction-max-candidate-window", type=int, default=2112,
                        help="Maximum candidate window when --auction-elastic-window extends across boundary ties")
    parser.add_argument("--auction-tie-tol", type=float, default=0.0,
                        help="NNZ tolerance for elastic candidate-window boundary extension")
    parser.add_argument("--auction-guarded-elastic", action="store_true",
                        help="Only use elastic-tail candidates when their score beats the base-window best by --auction-elastic-margin")
    parser.add_argument("--auction-elastic-margin", type=float, default=0.0,
                        help="Required normalized score improvement before selecting a guarded elastic-tail row")
    parser.add_argument("--auction-sequence-start-first", action="store_true",
                        help="Start macro-local wave sequencing from constructed wave 0 instead of highest mean-NNZ wave")
    parser.add_argument("--auction-sequence-overlap-window", type=int, default=1,
                        help="Use previous K emitted waves when choosing the next macro-local wave by KV overlap")
    parser.add_argument("--auction-sliding-cache-waves", type=int, default=0,
                        help="Previous constructed waves used as a cache term while building each wave")
    parser.add_argument("--auction-sliding-cache-weight", type=float, default=0.0,
                        help="Weight for construction-time sliding-cache cold KV term in auction_union_reorder_cuda")
    parser.add_argument("--auction-row-window-size", type=int, default=0,
                        help="Recent selected rows inside the current wave used for row-local cold KV scoring")
    parser.add_argument("--auction-row-window-weight", type=float, default=0.0,
                        help="Weight for row-local sliding-window cold KV term while building each wave")
    parser.add_argument("--rolling-cache-waves", type=int, default=2,
                        help="Previous waves included in rolling_union_wave_reorder cache union")
    parser.add_argument("--rolling-current-weight", type=float, default=1.0,
                        help="Weight for current-wave union growth in rolling_union_wave_reorder")
    parser.add_argument("--rolling-cache-weight", type=float, default=1.0,
                        help="Weight for rolling cold-KV growth in rolling_union_wave_reorder")
    parser.add_argument("--union-spectral-window", type=int, default=768,
                        help="Spectral-neighborhood candidate window for spectral_union_wave_reorder")
    parser.add_argument("--union-spectral-weight", type=float, default=0.0,
                        help="Spectral-distance penalty for spectral_union_wave_reorder")
    parser.add_argument("--segment-union-weight", type=float, default=1.0,
                        help="Weight for sum of per-wave KV unions in segment_partition_reorder")
    parser.add_argument("--segment-transition-weight", type=float, default=1.0,
                        help="Weight for ordered wave cold-start/run cost in segment_partition_reorder")
    parser.add_argument("--segment-interval-weight", type=float, default=0.0,
                        help="Weight for per-wave KV interval hull span in segment_partition_reorder")
    parser.add_argument("--segment-q-span-weight", type=float, default=0.0,
                        help="Weight for per-wave original query-row span in segment_partition_reorder")
    parser.add_argument("--wave-size", type=int, default=132)
    parser.add_argument("--kv-order", default="asc",
                        choices=("asc", "desc", "snake", "snake_inv", "boundary_dp", "edge_dp"),
                        help="Order of selected KV block indices in FA4 metadata; boundary_dp chooses wave directions by adjacent KV interval endpoints")
    parser.add_argument("--kv-edge-blocks", type=int, default=16,
                        help="Number of leading/trailing KV blocks per row used by kv-order=edge_dp")
    parser.add_argument("--block-size", type=int, default=128)
    parser.add_argument("--stride", type=int, default=32)
    parser.add_argument("--chunk-size", type=int, default=1024)
    parser.add_argument("--heads", type=int, default=-1,
                        help="Use first N heads for smoke tests; default all heads")
    parser.add_argument("--head-start", type=int, default=0,
                        help="First head index when --heads is set")
    parser.add_argument("--blocks", type=int, default=-1,
                        help="Crop to first N blocks before padding for smoke tests")
    parser.add_argument("--warmup", type=int, default=3)
    parser.add_argument("--repeat", type=int, default=5)
    parser.add_argument("--profile", action="store_true",
                        help="Enable cudaProfilerStart/Stop around one FA4 call for NCU")
    parser.add_argument("--csv", default="", help="Append Python-side metrics to this CSV")
    args = parser.parse_args()

    if args.chunk_size % args.block_size != 0:
        raise ValueError("--chunk-size must be divisible by --block-size")

    if args.dump == "all":
        dump_paths = list(DUMP_PRESETS.values())
    elif args.dump == "ltx_all":
        dump_paths = sorted(XATTN_ROOT.glob("output_ltx_step*"))
    else:
        dump_paths = [resolve_dump(args.dump)]
    for path in dump_paths:
        if not path.exists():
            raise FileNotFoundError(path)

    thresholds = parse_csv_list(args.thresholds, float) if args.thresholds else [args.threshold]
    if args.modes:
        modes = list(REORDER_MODES) if args.modes == "all" else parse_csv_list(args.modes, str)
    else:
        modes = [args.mode]
    for mode in modes:
        if mode not in REORDER_MODES:
            raise ValueError(f"Unsupported mode {mode}; choices={REORDER_MODES}")

    if args.profile and (len(dump_paths) * len(thresholds) * len(modes) != 1):
        raise ValueError("--profile is intended for exactly one dump/threshold/mode per process")

    for dump_path in dump_paths:
        for threshold in thresholds:
            for mode in modes:
                run_one(args, dump_path, threshold, mode)


if __name__ == "__main__":
    main()
