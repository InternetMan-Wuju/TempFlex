# Production Reorder 端到端实验记录

本文档记录基于 `batch_test.sh` 结构新增的端到端实验。

## 代码改动

新增脚本：

```text
examples/offline_inference/text_to_video/batch_test_production_reorder.sh
```

新增/接入的 production 候选 mode：

```text
auction_union_reorder_cuda
fiedler_mixed_nnz_reorder
nnz_macro_svd2_reorder
```

其中：

```text
auction_union_reorder_cuda:
  默认 VLLM_KV_ORDER=boundary_dp
  默认 VLLM_SEQUENCE_START_FIRST=1

其他 mode:
  默认 VLLM_KV_ORDER=asc
```

注意：`nnz_macro_svd2_reorder` 只作为端到端候选验证，不建议直接作为 production 默认。

## 实验设置

共同设置：

```text
MODEL=/data1/dhelix_shared/daizijian/models/Wan2.1-D
SPARSE_MODE=longcat
threshold=0.7
height=1280
width=720
steps=1
TP=1
LONGCAT_PROFILE=1
```

补充说明：

```text
旧 f65/f103 表是早期 steps=1 结果。
新长帧补测统一使用 steps=4, TP=1。
之后本脚本默认 TP=1, steps=4。
```

## 2026-05-18 更新：4-step 长帧补测

### 新增记录与 mode

新增 LongCat profile 日志：

```text
[LC_SHAPE]
  frames / height / width / steps / TP
  L_orig / L_real
  latent shape / padded latent shape
  FA4 block count

[LC_AUCTION]
  MB / NB
  group_waves / candidate_window / chunk_per_wave
```

新增或接入到 LongCat production path 的候选：

```text
wave_1d_reorder
wave_2d_reorder
svd_deflation_reorder
svd_u2u3_reorder
spectral_morton_wave_reorder
centered_morton_wave_reorder
```

Auction 新增：

```text
VLLM_AUCTION_CHUNK_PER_WAVE=adaptive
VLLM_KV_ORDER_OVERRIDE=<asc|boundary_dp>
```

adaptive `chunk_per_wave` 不是按 frames 字符串判断，而是按实际 block 数估算：

```text
work ~= ceil(MB / (group_waves * 132)) * ceil(131 / cpw) * ceil(NB / 64)
默认 work_budget=800
```

本轮选择结果：

```text
frames=161, MB=1320, NB=1320 -> cpw=8
frames=241, MB=1920, NB=1920 -> cpw=16
```

注意：当前 CUDA auction kernel 中，`chunk_per_wave` 主要减少同步轮数，但每选一行仍会重新扫描 candidate window。因此它不是 compute_perm 的主要控制旋钮。f241 中 cpw=8 与 cpw=16 的 `compute_perm` 基本相同，真正的 overhead 大头仍然是 auction permutation 本身和 `boundary_dp` 的 KV index rebuild。

### frames 对应 seqlen / block 数

固定：

```text
height=1280, width=720
latent spatial = 80 x 45
LongCat chunk = (tq,hq,wq) = (4,4,8)
FA4 block_size = 128
```

| frames | latent shape | L_real | L_orig / 128 pad | padded latent | FA4 blocks `(MB,NB)` | q_3d padded len |
|---:|---:|---:|---:|---:|---:|---:|
| 65 | `(17,80,45)` | 61,200 | 61,312 | `(20,80,48)` | `(600,600)` | 76,800 |
| 103 | `(26,80,45)` | 93,600 | 93,696 | `(28,80,48)` | `(840,840)` | 107,520 |
| 161 | `(41,80,45)` | 147,600 | 147,712 | `(44,80,48)` | `(1320,1320)` | 168,960 |
| 241 | `(61,80,45)` | 219,600 | 219,648 | `(64,80,48)` | `(1920,1920)` | 245,760 |

其中 f161/f241 的 `L_orig` 与 block 数来自实测 `[LC_SHAPE]` 日志；f65/f103 用相同 padding 规则推导。

### f161, steps=4, TP=1

log dirs：

```text
output_prod_reorder_longcat_prod_e2e_f161_s4_more_100319
output_prod_reorder_longcat_prod_e2e_auction_adaptive_asc_f161_f241_s4_101439
```

| mode | KV order | cpw | compute_perm | q_gather+idx | FA4 kernel | LC total/profile | count |
|---|---|---:|---:|---:|---:|---:|---:|
| no_reorder | asc | - | 0.46 ms | 0.46 ms | 55,689.78 ms | 59,337.59 ms | 160 |
| wave_reorder | asc | - | 637.35 ms | 538.20 ms | 55,779.77 ms | 61,959.84 ms | 160 |
| wave_1d_reorder | asc | - | 412.77 ms | 502.27 ms | 59,050.76 ms | 64,951.59 ms | 160 |
| fiedler_mixed_nnz_reorder | asc | - | 518.54 ms | 513.75 ms | 53,962.46 ms | 59,979.42 ms | 160 |
| svd_deflation_reorder | asc | - | 883.74 ms | 497.94 ms | 53,581.23 ms | 59,933.45 ms | 160 |
| spectral_morton_wave_reorder | asc | - | 1,093.04 ms | 502.41 ms | 51,767.18 ms | 58,291.53 ms | 160 |
| auction_union_reorder_cuda | boundary_dp | 8 | 2,601.76 ms | 5,788.61 ms | 46,727.58 ms | 59,737.11 ms | 160 |
| auction_union_reorder_cuda | asc | 8 | 2,598.69 ms | 485.87 ms | 51,447.59 ms | 59,468.39 ms | 160 |

f161 结论：

```text
kernel 最快:
  auction + boundary_dp = 46.73 s

端到端 LC profile 最快:
  spectral_morton_wave_reorder = 58.29 s
```

`auction + asc` 说明了一个关键点：去掉 `boundary_dp` 后 `q_gather+idx` 从 5.79s 降到 0.49s，但 kernel 也从 46.73s 退化到 51.45s，端到端仍不如 spectral Morton。

### f241, steps=4, TP=1

log dirs：

```text
output_prod_reorder_longcat_prod_e2e_f241_s4_top_100759
output_prod_reorder_longcat_prod_e2e_f241_s4_auction_adaptive_101328
output_prod_reorder_longcat_prod_e2e_auction_adaptive_asc_f161_f241_s4_101439
```

| mode | KV order | cpw | compute_perm | q_gather+idx | FA4 kernel | LC total/profile | count |
|---|---|---:|---:|---:|---:|---:|---:|
| no_reorder | asc | - | 0.47 ms | 0.46 ms | 125,758.08 ms | 131,537.50 ms | 160 |
| fiedler_mixed_nnz_reorder | asc | - | 654.46 ms | 722.69 ms | 117,929.73 ms | 127,066.76 ms | 160 |
| svd_deflation_reorder | asc | - | 1,370.57 ms | 720.54 ms | 117,193.47 ms | 127,062.52 ms | 160 |
| spectral_morton_wave_reorder | asc | - | 1,562.06 ms | 717.51 ms | 114,964.99 ms | 124,951.15 ms | 160 |
| auction_union_reorder_cuda | boundary_dp | 8 | 4,786.77 ms | 7,998.04 ms | 101,304.63 ms | 121,220.94 ms | 160 |
| auction_union_reorder_cuda | boundary_dp | 16 adaptive | 4,787.09 ms | 9,222.01 ms | 99,923.45 ms | 121,028.90 ms | 160 |
| auction_union_reorder_cuda | asc | 16 adaptive | 4,776.12 ms | 706.73 ms | 114,411.93 ms | 127,693.84 ms | 160 |

f241 结论：

```text
kernel 最快:
  auction + boundary_dp = 99.92-101.30 s

低 overhead 结构重排最好:
  spectral_morton_wave_reorder = 124.95 s profile

端到端 profile 最快:
  auction + boundary_dp adaptive = 121.03 s
```

但 auction 的收益依赖 `boundary_dp` KV orientation；一旦改成 `asc`，metadata overhead 降了，kernel 也退化，profile 变成 127.69s，反而不如 spectral Morton。

### 4-step 长帧阶段判断

当前 production 候选分两档：

```text
稳健低 overhead:
  spectral_morton_wave_reorder
  svd_deflation_reorder
  fiedler_mixed_nnz_reorder

长序列高收益但应用开销大:
  auction_union_reorder_cuda + boundary_dp
```

如果目标是“现在就进 production 默认”，更保守的选择是：

```text
spectral_morton_wave_reorder
```

理由：

```text
f161: LC profile 最快
f241: 低 overhead 方法中最快
q_gather+idx 与普通 row reorder 同级
没有 auction/boundary_dp 的大 metadata rebuild 风险
```

如果目标是“长序列极致 kernel/DRAM”，auction 仍然值得继续，但下一步不该只调 `chunk_per_wave`，而应该重写 auction scoring/application：

```text
1. 真正 batched top-k / chunk scoring，避免每选一行重扫 candidate window。
2. 降低或融合 boundary_dp 的 KV index rebuild。
3. 让 auction 直接输出 FA4 idx/cnt，避免 dense mask -> argsort -> gather 的二次应用开销。
```

## f65 完整候选

log dir：

```text
output_prod_reorder_longcat_prod_e2e_f65_095028
```

| mode | reorder | compute_perm | q_gather+idx | FA4 kernel | LC total | total generation |
|---|---:|---:|---:|---:|---:|---:|
| no_reorder | 75.97 ms | 0.17 ms | 0.35 ms | 10160.92 ms | 10581.52 ms | 21137.62 ms |
| wave_reorder | 273.63 ms | 138.16 ms | 75.23 ms | 7830.28 ms | 8549.36 ms | 17876.58 ms |
| fiedler_mixed_nnz_reorder | 237.94 ms | 117.18 ms | 61.52 ms | 5541.46 ms | 6226.15 ms | 15344.28 ms |
| nnz_macro_svd2_reorder | 4469.29 ms | 4362.00 ms | 52.92 ms | 5459.91 ms | 10346.09 ms | 19274.95 ms |
| auction_union_reorder_cuda, cpw=1 | 44207.97 ms | 43445.15 ms | 705.40 ms | 5421.72 ms | 50058.93 ms | 59178.98 ms |

### f65 结论

`auction_union_reorder_cuda` 的 `chunk_per_wave=1` 是 NCU 质量版，但端到端每层重排太慢，不适合直接 production。

```text
auction cpw=1:
  kernel 最快: 5421.72 ms
  但 compute_perm = 43.45 s
```

`nnz_macro_svd2_reorder` kernel 接近最优，但重排开销 4.36s，也不适合作默认 production。

当前 f65 最强 production 候选是：

```text
fiedler_mixed_nnz_reorder
```

它相比 `wave_reorder`：

```text
FA4 kernel:
  5541.46 ms vs 7830.28 ms
  降 29.2%

LC total:
  6226.15 ms vs 8549.36 ms
  降 27.2%

total generation:
  15344.28 ms vs 17876.58 ms
  降 14.2%
```

## f65 Auction 快速版

log dir：

```text
output_prod_reorder_longcat_prod_e2e_f65_auction_cpw8_095316
```

设置：

```text
VLLM_AUCTION_CHUNK_PER_WAVE=8
```

| mode | reorder | compute_perm | q_gather+idx | FA4 kernel | LC total | total generation |
|---|---:|---:|---:|---:|---:|---:|
| auction_union_reorder_cuda, cpw=8 | 1034.83 ms | 271.72 ms | 707.85 ms | 5363.06 ms | 6820.92 ms | 16068.61 ms |

### f65 Auction 快速版结论

`chunk_per_wave=8` 把 auction compute_perm 从 43.45s 降到 271.72ms，kernel 仍是最优：

```text
auction cpw=8:
  FA4 kernel = 5363.06 ms
```

但 `q_gather+idx` 仍然很高：

```text
auction q_gather+idx:
  707.85 ms

fiedler_mixed q_gather+idx:
  61.52 ms
```

因此当前端到端 `auction cpw=8` 仍不如 `fiedler_mixed`：

```text
LC total:
  auction cpw=8: 6820.92 ms
  fiedler_mixed: 6226.15 ms
```

## f103 Top Production Candidates

log dir：

```text
output_prod_reorder_longcat_prod_e2e_f103_top_095427
```

设置：

```text
VLLM_AUCTION_CHUNK_PER_WAVE=8
```

| mode | reorder | compute_perm | q_gather+idx | FA4 kernel | LC total | total generation |
|---|---:|---:|---:|---:|---:|---:|
| no_reorder | 111.82 ms | 0.12 ms | 0.12 ms | 11415.69 ms | 11973.01 ms | 26610.82 ms |
| wave_reorder | 286.62 ms | 114.42 ms | 84.94 ms | 8223.56 ms | 9173.08 ms | 22888.43 ms |
| fiedler_mixed_nnz_reorder | 305.92 ms | 123.78 ms | 92.97 ms | 8136.13 ms | 9114.65 ms | 22953.29 ms |
| auction_union_reorder_cuda, cpw=8 | 1480.69 ms | 415.03 ms | 977.68 ms | 7764.01 ms | 9863.55 ms | 23704.60 ms |

### f103 结论

`auction cpw=8` 的 kernel 仍最快：

```text
auction cpw=8:
  FA4 kernel = 7764.01 ms

fiedler_mixed:
  FA4 kernel = 8136.13 ms

wave:
  FA4 kernel = 8223.56 ms
```

但 auction 的 end-to-end LongCat total 反而更慢：

```text
LC total:
  fiedler_mixed: 9114.65 ms
  wave:          9173.08 ms
  auction cpw=8: 9863.55 ms
```

主要瓶颈还是：

```text
auction q_gather+idx = 977.68 ms
```

这不是 permutation compute 本身，而是当前 production path 在应用 row reorder 后重建/gather sparse metadata 的代价。

## 当前 Production 判断

当前可以进 production 路径继续验证的候选排序：

```text
1. fiedler_mixed_nnz_reorder
   - 低 overhead
   - f65/f103 端到端稳定优于 wave 或接近 wave
   - f65 明显最强

2. wave_reorder
   - 已有稳定 baseline
   - f103 与 fiedler_mixed 几乎打平

3. auction_union_reorder_cuda, chunk_per_wave=8
   - kernel 最强
   - 但 q_gather+idx metadata 应用开销过大
   - 需要优化 production apply path 后再考虑默认启用
```

暂不建议进 production 默认：

```text
auction_union_reorder_cuda, chunk_per_wave=1:
  NCU 质量好，但端到端 compute_perm 太慢。

nnz_macro_svd2_reorder:
  kernel 好，但 compute_perm 秒级。
```

## 下一步

最有价值的 production 优化不是继续改 auction wave packing，而是优化应用阶段：

```text
q_gather+idx / metadata rebuild
```

如果 auction 的 `q_gather+idx` 能从 700-980ms 降到接近 `fiedler_mixed/wave` 的 60-90ms，auction 才有机会在端到端上胜出。

## 2026-05-18 继续反思：从“partition”回到“谱结构维度”

这轮新增并测试了几个更激进的方向：

```text
hypergraph_fm_nnz_reorder
  NNZ-desc contiguous waves -> exact hypergraph union-delta swap refinement

spectral_morton_path_reorder
  spectral_morton row/wave partition -> macro 内按 KV cold-start 重排 wave

nnz_macro_centroid_reorder
  NNZ macro skeleton -> active KV centroid sort -> optional wave path

nnz_macro_spectral_bisect_reorder
  NNZ macro skeleton -> spectral embedding balanced recursive bisection
```

### 关键反例

`hypergraph_fm_nnz_reorder` 没赢。

在 `dense_dump_401f, threshold=0.8, H=8` 上：

| method | wave_reuse | wave_nnz_cv | wave_range | kernel |
|---|---:|---:|---:|---:|
| spectral_morton d3/mix0.5 | 0.8946 | 0.2111 | 158.5 | 172.8 ms |
| hypergraph_fm_nnz | 0.7830 | 0.077 | 80.4 | 176-178 ms |

这个反例说明：

```text
纯 NNZ skeleton + local FM 会过度保护 shear，
但搜索半径太小，无法恢复高维 KV 结构。
```

`nnz_macro_spectral_bisect_reorder` 也没赢：

```text
wave_nnz_cv: 0.1503
wave_range:  122.9
wave_reuse:  0.8899
kernel:      174.34 ms
```

它比 default spectral 的 shear 更整齐，但 kernel 更慢。结论是：

```text
NNZ/shear 重要，但不是单调越低越好。
低 density QKV 的主要收益仍来自 KV reuse / L2 locality。
```

`spectral_morton_path_reorder` 也被 NCU 否了：

| method | DRAM read | kernel | L2 hit |
|---|---:|---:|---:|
| spectral_morton d3/mix0.5 | 41.42 GB | 172.80 ms | 88.00% |
| spectral_morton_path | 49.54 GB | 172.92 ms | 86.35% |

直觉上的 wave 间 cold-start 最小化会破坏 FA4 实际访问相位，不能作为默认优化目标。

### 真正有效的新发现

最有价值的突破是 spectral 参数，而不是新 partition 形式。

`dense_dump_401f, threshold=0.8, H=8` NCU：

| method | DRAM read | kernel | L2 hit |
|---|---:|---:|---:|
| spectral_morton d2/mix0.75 | 38.03 GB | 172.60 ms | 88.57% |
| spectral_morton d3/mix0.5 | 41.42 GB | 172.80 ms | 88.00% |
| spectral_morton d1/mix0 | 41.86 GB | 172.95 ms | 87.80% |
| auction + boundary_dp | 43.87 GB | 172.58 ms | 87.52% |

`dense_dump_161f, threshold=0.8, H=8` NCU：

| method | DRAM read | kernel | L2 hit |
|---|---:|---:|---:|
| spectral_morton d2/mix0.75 | 5.37 GB | 29.33 ms | 90.33% |
| spectral_morton d3/mix0.5 | 5.86 GB | 29.54 ms | 89.32% |

解释：

```text
d1 信息不足：只保留主结构方向，wave_reuse 低。
d3 信息过多：第三阶结构会把 rows 切得过碎，Morton 排序引入额外扰动。
d2/mix0.75 是当前甜点：
  保留两个主要结构方向；
  trivial deflation 更偏 sqrt(deg)，即更强地剥离 NNZ/degree 主成分；
  剩下的二维坐标更像真正的 KV reuse 结构。
```

### Production 端到端复测：spectral d2/mix0.75

log dir：

```text
output_prod_reorder_longcat_prod_e2e_spectral_d2mix075_f161_f241_s4_113818
```

设置：

```text
steps=4
TP=1
VLLM_SPECTRAL_DIM=2
VLLM_SPECTRAL_TRIVIAL_MIX=0.75
```

| frames | seqlen | blocks | compute_perm | q_gather+idx | FA4 kernel | LC total/profile |
|---:|---:|---:|---:|---:|---:|---:|
| 161 | 147,712 | 1320x1320 | 753.40 ms | 494.39 ms | 51,888.91 ms | 58,063.49 ms |
| 241 | 219,648 | 1920x1920 | 1,105.16 ms | 722.15 ms | 115,068.75 ms | 124,603.49 ms |

对比默认 spectral d3/mix0.5：

```text
f161 profile:
  d3/mix0.5: 58,291.53 ms
  d2/mix0.75: 58,063.49 ms

f241 profile:
  d3/mix0.5: 124,951.15 ms
  d2/mix0.75: 124,603.49 ms
```

收益不大，但方向和 NCU DRAM 一致，而且 overhead 低于 d3。

### 当前最强判断

如果目标是 production 默认候选：

```text
spectral_morton_wave_reorder
VLLM_SPECTRAL_DIM=2
VLLM_SPECTRAL_TRIVIAL_MIX=0.75
VLLM_FIEDLER_ITERS=8
KV order = asc
```

如果目标是继续研究极限：

```text
不要继续纯 FM / NNZ macro。
下一步应该围绕“二维 spectral embedding + exact 132-capacity packing”做更细的局部优化，
但局部优化必须保持 Morton 的 FA4 相位，不要做独立 wave path 重排。
```
