# Reorder 方法全量对比表

本文档汇总目前已经测过的主要 row reorder 方法。注意这些表的测试口径不同：

```text
NCU/QKV:
  用 dump QKV 生成 xattn threshold mask，只测 FA4 forward 的 DRAM/time。

LongCat E2E:
  真实 text_to_video 端到端 LongCat path，记录 compute_perm / q_gather+idx / FA4 kernel / profiled total。

Warm overhead:
  同一进程内重复调用 reorder，尽量去掉首次 import / CUDA extension load。
```

## 1. NCU: dense401 threshold=0.8 H8

测试对象：

```text
/data1/dhelix_shared/daizijian/QKVtensor/dense_dump_401f/longcat_layer0.pt
threshold=0.8
heads=8
MB=2848
density=0.2068
```

### 1.1 核心 sweep

| rank | method | 系列 | DRAM read | NCU time | 相对 best read | 结论 |
|---:|---|---|---:|---:|---:|---|
| 1 | auction_startfirst | auction | 36.013 GB | 172.421 ms | 1.000x | 老 sweep 最低 DRAM，但 production metadata 贵 |
| 2 | fiedler_mixed_nnz_reorder | fiedler | 37.828 GB | 172.641 ms | 1.050x | dense401 上非常强 |
| 3 | spectral_morton_wave_reorder d3/mix0.5 | spectral | 39.394 GB | 172.716 ms | 1.094x | 老默认 spectral |
| 4 | fiedler_wave_reorder | fiedler | 40.068 GB | 172.700 ms | 1.113x | 一维谱结构有效但不最强 |
| 5 | svd_deflation_reorder | SVD | 41.670 GB | 172.528 ms | 1.157x | 中等 |
| 6 | fiedler_seeded_wave_reorder | fiedler | 41.894 GB | 172.775 ms | 1.163x | 中等 |
| 7 | fiedler_local_nnz_reorder | fiedler | 42.581 GB | 172.878 ms | 1.182x | 中等 |
| 8 | centered_morton_wave_reorder | spectral | 43.077 GB | 172.759 ms | 1.196x | 不如普通 spectral |
| 9 | svd_u2u3_reorder | SVD | 45.205 GB | 172.770 ms | 1.255x | 偏弱 |
| 10 | wave_1d_reorder | wave | 48.153 GB | 172.648 ms | 1.337x | 便宜但质量有限 |
| 11 | nnz_macro_svd2 | NNZ-macro/SVD | 55.012 GB | 173.171 ms | 1.528x | dense401 不适合 |
| 12 | wave_reorder | wave | 55.657 GB | 172.639 ms | 1.546x | 明显弱于 spectral/fiedler |
| 13 | wave_2d_reorder | wave | 56.035 GB | 172.737 ms | 1.556x | 明显弱 |
| 14 | bootes_spectral_wave_reorder | spectral/cluster | 57.699 GB | 172.662 ms | 1.602x | clustering 不适合 132 容量 |
| 15 | nnz_macro_svd1 | NNZ-macro/SVD | 76.781 GB | 173.840 ms | 2.132x | 弱 |
| 16 | nnz_macro_fiedler | NNZ-macro/fiedler | 83.755 GB | 174.038 ms | 2.326x | 弱 |
| 17 | nnz_macro_wave | NNZ-only | 91.107 GB | 172.762 ms | 2.530x | 只保 shear 会严重伤 KV reuse |

### 1.2 后续 tuned spectral / 新方法 NCU

同一 case 上后续补测了 spectral 参数和 path/auction 对照：

| method | 系列 | DRAM read | NCU time | L2 hit | 相对 tuned spectral | 结论 |
|---|---|---:|---:|---:|---:|---|
| spectral_morton d2/mix0.75 | spectral | 38.03 GB | 172.60 ms | 88.57% | 1.000x | 当前最好的低开销 spectral 参数 |
| spectral_morton d3/mix0.5 | spectral | 41.42 GB | 172.80 ms | 88.00% | 1.089x | 旧默认，比 d2/mix0.75 多读 8.9% |
| spectral_morton d1/mix0 | spectral | 41.86 GB | 172.95 ms | 87.80% | 1.101x | 一维信息不足 |
| auction + boundary_dp | auction | 43.87 GB | 172.58 ms | 87.52% | 1.154x | 此次复测不如 tuned spectral |
| spectral_morton_path | spectral/path | 49.54 GB | 172.92 ms | 86.35% | 1.303x | wave path 重排破坏 FA4 相位 |

## 2. NCU: dense161 threshold=0.8 H8

测试对象：

```text
/data1/dhelix_shared/daizijian/QKVtensor/dense_dump_161f/longcat_layer0.pt
threshold=0.8
heads=8
MB=1160
density=0.2064
```

| method | 系列 | DRAM read | NCU time | L2 hit | 结论 |
|---|---|---:|---:|---:|---|
| spectral_morton d2/mix0.75 | spectral | 5.37 GB | 29.33 ms | 90.33% | tuned 参数继续更好 |
| spectral_morton d3/mix0.5 | spectral | 5.86 GB | 29.54 ms | 89.32% | 比 tuned 多读 9.1% |

## 3. NCU: LTX step16 layer47 threshold=0.9 H8

测试对象：

```text
/data1/dhelix_shared/daizijian/x-attention/output_ltx_step16
layer=47
threshold=0.9
heads=8
```

| rank | method | 系列 | DRAM read | NCU time | 相对 best read | 结论 |
|---:|---|---|---:|---:|---:|---|
| 1 | auction_startfirst | auction | 72.013 GB | 231.705 ms | 1.000x | LTX 上最强 |
| 2 | nnz_macro_svd2 | NNZ-macro/SVD | 74.748 GB | 232.810 ms | 1.038x | LTX 上接近 auction |
| 3 | nnz_macro_fiedler | NNZ-macro/fiedler | 86.122 GB | 233.547 ms | 1.196x | 中等 |
| 4 | nnz_macro_svd1 | NNZ-macro/SVD | 101.945 GB | 234.086 ms | 1.416x | 偏弱 |
| 5 | bootes_spectral_wave_reorder | spectral/cluster | 108.789 GB | 232.281 ms | 1.511x | classic spectral 弱 |
| 6 | spectral_morton_wave_reorder | spectral | 108.989 GB | 231.981 ms | 1.513x | classic spectral 弱 |
| 7 | centered_morton_wave_reorder | spectral | 109.024 GB | 231.899 ms | 1.514x | classic spectral 弱 |
| 8 | svd_deflation_reorder | SVD | 121.434 GB | 233.109 ms | 1.686x | 弱 |
| 9 | svd_u2u3_reorder | SVD | 125.652 GB | 233.435 ms | 1.745x | 弱 |
| 10 | wave_2d_reorder | wave | 132.077 GB | 233.455 ms | 1.834x | 弱 |
| 11 | wave_reorder | wave | 149.321 GB | 234.306 ms | 2.073x | 弱 |
| 12 | fiedler_local_nnz_reorder | fiedler | 152.808 GB | 233.451 ms | 2.122x | LTX 上失败 |
| 13 | fiedler_wave_reorder | fiedler | 153.614 GB | 234.458 ms | 2.133x | LTX 上失败 |
| 14 | wave_1d_reorder | wave | 154.752 GB | 233.849 ms | 2.149x | 弱 |
| 15 | fiedler_mixed_nnz_reorder | fiedler | 156.926 GB | 234.280 ms | 2.179x | dense401 强，LTX 弱 |
| 16 | fiedler_seeded_wave_reorder | fiedler | 157.200 GB | 234.225 ms | 2.183x | LTX 弱 |
| 17 | nnz_macro_wave | NNZ-only | 268.683 GB | 240.063 ms | 3.731x | 纯 shear 极差 |

## 4. Warm Reorder Overhead

### 4.1 dense401 threshold=0.8 H8

| method | 系列 | warm reorder overhead | vs auction | 评价 |
|---|---|---:|---:|---|
| auction_union_reorder_cuda + start_first | auction | 54.6 ms | 1.00x | CUDA 构造，稳定中等开销 |
| wave_reorder | wave | 153.7 ms | 2.82x | 比想象慢 |
| wave_1d_reorder | wave | 2.0 ms | 0.04x | 极低开销 |
| wave_2d_reorder | wave | 49.7 ms | 0.91x | 接近 auction |
| svd_u2u3_reorder | SVD | 4.9 ms | 0.09x | 很低 |
| svd_deflation_reorder | SVD | 4.2 ms | 0.08x | 很低 |
| fiedler_wave_reorder | fiedler | 27.9 ms | 0.51x | 低 |
| fiedler_local_nnz_reorder | fiedler | 2.0 ms | 0.04x | 极低 |
| fiedler_mixed_nnz_reorder | fiedler | 1.9 ms | 0.04x | 极低 |
| fiedler_seeded_wave_reorder | fiedler | 87.2 ms | 1.60x | 偏高 |
| bootes_spectral_wave_reorder | spectral/cluster | 119.6 ms | 2.19x | 偏高 |
| spectral_morton_wave_reorder | spectral | 44.4 ms | 0.81x | 可接受 |
| centered_morton_wave_reorder | spectral | 35.7 ms | 0.65x | 可接受 |
| nnz_macro_wave_reorder | NNZ-only | 33.4 ms | 0.61x | 可接受但质量差 |
| nnz_macro_svd2_reorder | NNZ-macro/SVD | 71.8 ms | 1.32x | 中等偏高 |

### 4.2 LTX step16 layer47 threshold=0.9 H8

| method | 系列 | warm reorder overhead | vs auction | 评价 |
|---|---|---:|---:|---|
| auction_union_reorder_cuda + start_first | auction | 70.6 ms | 1.00x | 中等 |
| wave_reorder | wave | 151.1 ms | 2.14x | 偏高 |
| wave_1d_reorder | wave | 2.4 ms | 0.03x | 极低 |
| wave_2d_reorder | wave | 47.9 ms | 0.68x | 低 |
| svd_u2u3_reorder | SVD | 5.2 ms | 0.07x | 极低 |
| svd_deflation_reorder | SVD | 5.1 ms | 0.07x | 极低 |
| fiedler_wave_reorder | fiedler | 26.9 ms | 0.38x | 低 |
| fiedler_local_nnz_reorder | fiedler | 2.4 ms | 0.03x | 极低 |
| fiedler_mixed_nnz_reorder | fiedler | 2.2 ms | 0.03x | 极低但 LTX 质量差 |
| fiedler_seeded_wave_reorder | fiedler | 98.2 ms | 1.39x | 偏高 |
| bootes_spectral_wave_reorder | spectral/cluster | 116.2 ms | 1.65x | 偏高 |
| spectral_morton_wave_reorder | spectral | 44.2 ms | 0.63x | 可接受 |
| centered_morton_wave_reorder | spectral | 36.2 ms | 0.51x | 可接受 |
| nnz_macro_wave_reorder | NNZ-only | 39.1 ms | 0.55x | 可接受但质量极差 |
| nnz_macro_svd2_reorder | NNZ-macro/SVD | 92.1 ms | 1.30x | 中等偏高 |

## 5. LongCat E2E: f65 steps=1 TP=1

| method | 系列 | compute_perm | q_gather+idx | FA4 kernel | LC total | total generation | 结论 |
|---|---|---:|---:|---:|---:|---:|---|
| no_reorder | baseline | 0.17 ms | 0.35 ms | 10,160.92 ms | 10,581.52 ms | 21,137.62 ms | baseline |
| wave_reorder | wave | 138.16 ms | 75.23 ms | 7,830.28 ms | 8,549.36 ms | 17,876.58 ms | 有效 |
| fiedler_mixed_nnz_reorder | fiedler | 117.18 ms | 61.52 ms | 5,541.46 ms | 6,226.15 ms | 15,344.28 ms | f65 最佳 production |
| nnz_macro_svd2_reorder | NNZ-macro/SVD | 4,362.00 ms | 52.92 ms | 5,459.91 ms | 10,346.09 ms | 19,274.95 ms | kernel 好但 overhead 太高 |
| auction_union cpw=1 | auction | 43,445.15 ms | 705.40 ms | 5,421.72 ms | 50,058.93 ms | 59,178.98 ms | oracle 质量，production 不可用 |
| auction_union cpw=8 | auction | 271.72 ms | 707.85 ms | 5,363.06 ms | 6,820.92 ms | 16,068.61 ms | kernel 最好，metadata 贵 |

## 6. LongCat E2E: f103 steps=1 TP=1

| method | 系列 | compute_perm | q_gather+idx | FA4 kernel | LC total | total generation | 结论 |
|---|---|---:|---:|---:|---:|---:|---|
| no_reorder | baseline | 0.12 ms | 0.12 ms | 11,415.69 ms | 11,973.01 ms | 26,610.82 ms | baseline |
| wave_reorder | wave | 114.42 ms | 84.94 ms | 8,223.56 ms | 9,173.08 ms | 22,888.43 ms | 强 baseline |
| fiedler_mixed_nnz_reorder | fiedler | 123.78 ms | 92.97 ms | 8,136.13 ms | 9,114.65 ms | 22,953.29 ms | 与 wave 接近 |
| auction_union cpw=8 | auction | 415.03 ms | 977.68 ms | 7,764.01 ms | 9,863.55 ms | 23,704.60 ms | kernel 最强但 total 输 |

## 7. LongCat E2E: f161 steps=4 TP=1

```text
frames=161
L_orig=147,712
blocks=1320x1320
count=160
```

| method | 系列 | KV order | cpw | compute_perm | q_gather+idx | FA4 kernel | LC profile | 相对 best profile | 结论 |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| spectral_morton d2/mix0.75 | spectral | asc | - | 753.40 ms | 494.39 ms | 51,888.91 ms | 58,063.49 ms | 1.000x | 当前 f161 最佳 |
| spectral_morton d3/mix0.5 | spectral | asc | - | 1,093.04 ms | 502.41 ms | 51,767.18 ms | 58,291.53 ms | 1.004x | 旧默认，略差 |
| no_reorder | baseline | asc | - | 0.46 ms | 0.46 ms | 55,689.78 ms | 59,337.59 ms | 1.022x | baseline |
| auction_union | auction | asc | 8 | 2,598.69 ms | 485.87 ms | 51,447.59 ms | 59,468.39 ms | 1.024x | 去掉 boundary 后 total 不赢 |
| auction_union | auction | boundary_dp | 8 | 2,601.76 ms | 5,788.61 ms | 46,727.58 ms | 59,737.11 ms | 1.029x | kernel 最强，metadata 太贵 |
| svd_deflation_reorder | SVD | asc | - | 883.74 ms | 497.94 ms | 53,581.23 ms | 59,933.45 ms | 1.032x | 中等 |
| fiedler_mixed_nnz_reorder | fiedler | asc | - | 518.54 ms | 513.75 ms | 53,962.46 ms | 59,979.42 ms | 1.033x | 中等 |
| wave_reorder | wave | asc | - | 637.35 ms | 538.20 ms | 55,779.77 ms | 61,959.84 ms | 1.067x | 此 case 变差 |
| wave_1d_reorder | wave | asc | - | 412.77 ms | 502.27 ms | 59,050.76 ms | 64,951.59 ms | 1.119x | 不建议 |

## 8. LongCat E2E: f241 steps=4 TP=1

```text
frames=241
L_orig=219,648
blocks=1920x1920
count=160
```

| method | 系列 | KV order | cpw | compute_perm | q_gather+idx | FA4 kernel | LC profile | 相对 best profile | 结论 |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| auction_union adaptive | auction | boundary_dp | 16 | 4,787.09 ms | 9,222.01 ms | 99,923.45 ms | 121,028.90 ms | 1.000x | f241 最佳，但 overhead 大 |
| auction_union | auction | boundary_dp | 8 | 4,786.77 ms | 7,998.04 ms | 101,304.63 ms | 121,220.94 ms | 1.002x | 与 adaptive 接近 |
| spectral_morton d2/mix0.75 | spectral | asc | - | 1,105.16 ms | 722.15 ms | 115,068.75 ms | 124,603.49 ms | 1.030x | 最佳低 overhead |
| spectral_morton d3/mix0.5 | spectral | asc | - | 1,562.06 ms | 717.51 ms | 114,964.99 ms | 124,951.15 ms | 1.032x | 旧默认，略差 |
| svd_deflation_reorder | SVD | asc | - | 1,370.57 ms | 720.54 ms | 117,193.47 ms | 127,062.52 ms | 1.050x | 中等 |
| fiedler_mixed_nnz_reorder | fiedler | asc | - | 654.46 ms | 722.69 ms | 117,929.73 ms | 127,066.76 ms | 1.050x | 中等 |
| auction_union adaptive | auction | asc | 16 | 4,776.12 ms | 706.73 ms | 114,411.93 ms | 127,693.84 ms | 1.055x | asc 不够，说明 boundary_dp 关键 |
| no_reorder | baseline | asc | - | 0.47 ms | 0.46 ms | 125,758.08 ms | 131,537.50 ms | 1.087x | baseline |

## 9. 实验性新方法 smoke: dense401 threshold=0.8 H8

这些不是完整 NCU sweep，只用于判断方向是否值得继续。

| method | 系列 | wave_reuse | wave_nnz_cv | wave_range | kernel timing | 结论 |
|---|---|---:|---:|---:|---:|---|
| spectral_morton d3/mix0.5 | spectral | 0.8946 | 0.2111 | 158.5 | 172.1-172.8 ms | 强 baseline |
| spectral_morton d2/mix0.75 | spectral | 0.8755 | 0.1700 | 135.2 | 172.0-175.5 ms | NCU DRAM 最好，timing 接近 |
| hypergraph_fm_nnz | hypergraph/FM | 0.7830 | 0.077 | 80.4 | 176-178 ms | shear 很好但 KV reuse 差 |
| capacity_refined init=morton | capacity refinement | 0.8976 | 0.1857 | 149.4 | 172.94 ms | 没明显超过 spectral，overhead 高 |
| nnz_macro_centroid | centroid | 0.7960 | 0.2057 | 153.5 | 174.88 ms | centroid 过弱 |
| nnz_macro_spectral_bisect | balanced spectral | 0.8899 | 0.1503 | 122.9 | 174.34 ms | shear 更好但 kernel 更慢 |
| spectral_morton_path | wave path | 0.8924 | 0.2095 | 157.5 | 172.9 ms, DRAM 49.54 GB | wave path 破坏相位 |

## 10. 综合排序

### Production 默认候选

| rank | method | 理由 |
|---:|---|---|
| 1 | spectral_morton_wave_reorder d2/mix0.75 | 低 overhead，QKV NCU DRAM 明显优于旧默认，f161/f241 E2E 都稳定 |
| 2 | fiedler_mixed_nnz_reorder | f65/f103 很强，overhead 很低，但 f161/f241/LTX 不如 spectral/auction |
| 3 | wave_reorder | 简单 baseline，f103 有效，但 f161 可能变差 |

### 长序列特化

| rank | method | 理由 |
|---:|---|---|
| 1 | auction_union + boundary_dp | f241 E2E 最强，LTX NCU 最强 |
| 2 | nnz_macro_svd2 | LTX NCU 接近 auction，但 E2E overhead 仍需谨慎 |

### 不建议默认

| method | 原因 |
|---|---|
| pure NNZ / nnz_macro_wave | shear 好但 KV reuse/DRAM 极差 |
| wave_1d | overhead 极低但质量差 |
| hypergraph_fm_nnz | 从 NNZ skeleton 出发局部最优，无法恢复结构簇 |
| spectral_morton_path | 直觉上优化 wave transition，但 NCU DRAM 变差 |
| nnz_macro_centroid | 真实 mask 不是简单单峰 interval |
| centered_morton | 没有超过普通 spectral |
