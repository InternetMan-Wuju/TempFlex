# Sparse Attention Row Reorder 候选方法说明

本文档记录当前值得保留和继续维护的行重排方法。结论来自 xattn / sparge 端到端实验、QKV-derived threshold mask 实验和 NCU DRAM/kernel-time 对比。

## 快速结论

| 方法 | 推荐级别 | 适用场景 | 主要风险 |
| --- | --- | --- | --- |
| `wave_reorder` | production baseline | 低 density、部分短序列 | 与 `wave_1d_reorder` 只是 spectral path 相位不同，非总是最优 |
| `wave_1d_reorder` | production candidate | xattn t0.7/f169/f305、t0.8/f65/f305 等 | 与 `wave_reorder` 胜负依赖 frames/threshold |
| `wave_2d_reorder` | production candidate / profiling | 长序列或多结构 mask | 比 1D 多一维 spectral 计算，overhead 更高 |
| `spectral_morton_wave_reorder` | experimental candidate | kernel time 常接近最优，Sparge/长序列有参考价值 | total time 可能被 reorder overhead 抵消 |
| `auction_union_reorder_cuda` | experimental CUDA candidate | union/partition 路线代表，适合继续优化 CUDA overhead | 当前 overhead 偏大，不建议默认启用 |
| `idf_wave_reorder` | research candidate | hot KV column 主导、需要强调 cold KV 结构的 mask | 局部有效，泛化不稳定 |
| `modularity_wave_reorder` | research candidate | 需要去掉 row/column degree 背景的 mask | 局部有效，泛化不稳定 |
| `hotcold_wave_reorder` | research candidate | 同时调 IDF 和 degree correction | 参数敏感，不建议默认 |
| `adaptive_macro_wave_reorder` | experimental adaptive | NNZ 骨架 + macro 内结构调整 | overhead 仍偏高，属于半成功探索 |
| `marginal_union_wave_reorder` / `banded_union_wave_reorder` / `banded_union_sequenced_wave_reorder` | oracle / upper bound | 离线分析、质量上界、NCU 对比 | Python/贪心开销高，不进 production path |

当前默认建议：生产路径优先比较 `wave_reorder`、`wave_1d_reorder`、`wave_2d_reorder`。其它方法保留为 experimental/research/oracle。

## 方法细节

### `wave_1d_reorder`

`wave_1d_reorder` 和已有 `wave_reorder` 本质都是 top-1 spectral row path。

区别是 path 相位：

```text
wave_reorder:    U[:, :, 0].argsort(descending=True)
wave_1d_reorder: U[:, :, 0].argsort(descending=False)
```

二者后处理相同：

1. 按 spectral score 得到 row order。
2. 固定切成 `wave_size=132` 的 wave。
3. 每个 wave 内按 NNZ 降序。
4. wave 间按 mean NNZ 降序执行。

由于 `MB` 经常不是 132 的整数倍，反转 path 后 wave 边界会切在不同 row 对之间，因此两个 phase 不是等价 permutation。端到端结果显示 `wave_1d_reorder` 经常比原 `wave_reorder` 更强，但并非所有配置都赢。

使用：

```bash
VLLM_MODE=wave_1d_reorder SPARSE_MODE=xattn ...
```

### `spectral_morton_wave_reorder`

这个方法用多维 normalized spectral embedding，再用 Morton/space-filling key 将多维结构压成一维顺序，最后仍走固定 132-row wave 后处理。

关键环境变量：

```bash
VLLM_SPECTRAL_DIM=3
VLLM_SPECTRAL_TRIVIAL_MIX=0.75
VLLM_FIEDLER_ITERS=8
```

常用 sweep label：

```text
spectral_morton_wave_reorder@d3m075
```

含义：

- `d3`: spectral dimension = 3
- `m075`: trivial vector mix = 0.75

经验结论：

- kernel time 经常很强，尤其 f169/f305 或 Sparge 场景。
- total time 不一定最好，因为 reorder overhead 明显高于 `wave_1d_reorder`。
- 推荐作为 profiling/experimental mode，不建议默认 production。

### `auction_union_reorder_cuda`

CUDA 版 multi-wave union/auction solver，目标是直接构造固定容量 wave：

```text
score =
  marginal_union
+ rank_weight * NNZ-rank pressure
+ shear_weight * NNZ shear pressure
+ borrow_weight * candidate-window borrow distance
```

它的意义是把“NNZ 降序骨架”和“KV union 最小化”合进一个 wave 构造过程，而不是先 spectral 再 wave 后处理。

关键环境变量：

```bash
VLLM_AUCTION_GROUP_WAVES=8
VLLM_AUCTION_CANDIDATE_WINDOW=1056
VLLM_AUCTION_CHUNK_PER_WAVE=adaptive
VLLM_AUCTION_WORK_BUDGET=800
```

FA4 KV index order 会自动走 `boundary_dp`，用于减少 wave 间 KV cold-start。

经验结论：

- 代表 partition/union 路线，算法研究价值高。
- 当前 reorder/metadata overhead 偏大，经常抵消 kernel/DRAM 改善。
- 建议保留 CUDA experimental path，后续重点优化 bitset 访问和 metadata 生成开销。

### `idf_wave_reorder`

IDF-weighted spectral reorder。普通 SVD/谱方法容易被 hot KV column 主导，但 hot column 本来就容易复用；IDF 会降低 hot column 权重，让 cold KV column 更影响 row 坐标。

权重：

```text
weight[col] = (mean_col_nnz / col_nnz[col]) ** idf_power
```

关键环境变量：

```bash
VLLM_IDF_POWER=0.5
VLLM_IDF_MIN_WEIGHT=0.25
VLLM_IDF_MAX_WEIGHT=4.0
VLLM_FIEDLER_ITERS=8
```

经验结论：

- f65 等短序列/局部场景有小胜。
- 长序列上不稳定，不建议默认。

### `modularity_wave_reorder`

Degree-corrected spectral reorder。它把 mask 看成 row/KV 二部图，去掉 configuration-model 背景：

```text
B = A - row_degree * col_degree / total_edges
```

这样谱向量强调“不由 NNZ 和全局 hot column 解释”的结构。

关键环境变量：

```bash
VLLM_IDF_POWER=0.0
VLLM_FIEDLER_ITERS=8
```

经验结论：

- 对部分中等 density / mid sequence case 有局部收益。
- 不是通用最优。

### `hotcold_wave_reorder`

`hotcold_wave_reorder` 是 `idf_wave_reorder` 和 `modularity_wave_reorder` 的连续组合：

```text
A' = A * idf(col)
B  = A' - beta * row_degree(A') * col_degree(A') / total_edges(A')
```

关键环境变量：

```bash
VLLM_IDF_POWER=0.5
VLLM_DEGREE_CORRECTION=0.25
VLLM_IDF_MIN_WEIGHT=0.25
VLLM_IDF_MAX_WEIGHT=4.0
```

经验结论：

- 解释性强，适合分析 hot/cold KV 是否重要。
- 参数敏感，端到端没有稳定超过 wave 系。

### `adaptive_macro_wave_reorder`

低开销 adaptive 尝试：

1. 先按 NNZ 降序形成硬骨架。
2. 根据 row/col CV 和 NNZ 相邻 Jaccard 估计 overlap pressure。
3. 选择 local macro size。
4. macro 内混合 NNZ rank 和 spectral rank。
5. 切回 132-row wave，wave 内仍按 NNZ 降序。

关键环境变量：

```bash
VLLM_ADAPTIVE_WAVE_MAX_MACRO_WAVES=4
VLLM_ADAPTIVE_WAVE_ITERS=8
VLLM_ADAPTIVE_WAVE_SAMPLE_PAIRS=96
VLLM_ADAPTIVE_WAVE_DIM2_MIX=0.25
```

经验结论：

- 算法方向合理，能体现“NNZ skeleton + local structural refinement”。
- 但 overhead 仍偏大，当前只建议作为 experimental adaptive baseline。

### Union oracle 系

这些方法用于离线 upper bound，不建议生产使用：

- `marginal_union_wave_reorder`
- `banded_union_wave_reorder`
- `banded_union_sequenced_wave_reorder`

它们直接优化 wave 内 KV union / marginal union，能帮助判断“理论上还有多少 DRAM 空间”。缺点是 Python/贪心开销高，且 kernel time 不一定随 DRAM read 线性下降。

## 为什么不提交失败 adaptive 为 production mode

已经实验否掉或不建议 exposure 的方向：

- per-head phase adaptive：会破坏同层 head 的访问相位，f305 明显退化。
- sliding phase：短序列可能接近 best，长序列 kernel 明显退化。
- low-iteration fast wave：overhead 降了，但 f169/f305 kernel 退化，说明 spectral path 收敛不能随便砍。
- raw/idf blend 与 adaptive idf/metric：额外计算和 sort 容易吃掉小幅 kernel 收益。

因此当前 commit 只把稳定候选、研究候选和 oracle 上界保留为可用路径；失败 adaptive 不作为推荐入口。

## 推荐 benchmark 命令

端到端 xattn/Wan2.2：

```bash
RUN_TAG=e2e_reorder_candidates \
SPARSE_MODES_STR="xattn" \
FRAMES_LIST_STR="65 169 305" \
THRESHOLDS_STR="0.7 0.8" \
XATTN_MODES_STR="wave_reorder wave_1d_reorder wave_2d_reorder spectral_morton_wave_reorder@d3m075 idf_wave_reorder@ip05 modularity_wave_reorder@ip05 hotcold_wave_reorder@ip05@b025 auction_union_reorder_cuda" \
XATTN_TP=2 SPARGE_TP=1 GPU_IDS_STR="0 1 2 3 4 5 6 7" \
STEPS=4 HEIGHT=1280 WIDTH=720 \
bash examples/offline_inference/text_to_video/batch_test_xattn_sparge_reorder.sh
```

只看低 density case 时，建议先过滤 `density < 0.43`，再比较：

- total time
- kernel time
- reorder time
- DRAM read
- L2 hit

NCU 评价优先级：

```text
1. kernel time
2. DRAM read
3. L2 hit
4. reorder overhead
5. total e2e time
```

DRAM read 降幅和 kernel time 不是线性关系。DRAM 降到一定程度后，kernel 可能受 compute、metadata、occupancy 或 launch/phase 约束，继续降低 DRAM 不一定继续带来同等 time 收益。
