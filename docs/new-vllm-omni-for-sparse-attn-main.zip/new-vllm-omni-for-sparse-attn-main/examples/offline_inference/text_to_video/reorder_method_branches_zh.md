# Row Reorder 方法分支与演进图

本文档总结目前 Sparse Video / XAttention threshold mask 上探索过的 row reorder 方法分支、递进关系和阶段性结论。

## 总览图

```mermaid
flowchart TD
    A["Row Reorder 总问题<br/>目标: 降 DRAM / 保 NNZ wavefront / 控 overhead"]

    A --> B["NNZ / Wave 基线系"]
    B --> B1["no_reorder<br/>原始顺序"]
    B1 --> B2["nnz_reorder<br/>全局 NNZ 降序"]
    B2 --> B3["nnz_3step_reorder<br/>NNZ 分段/局部修正"]
    B3 --> B4["wave_reorder / wave_1d<br/>wave 内 NNZ 更规整"]
    B4 --> B5["结论<br/>NNZ 降序必要<br/>但不够降 DRAM"]

    A --> C["Spectral / SVD / Fiedler 系"]
    C --> C1["SVD u2/u3<br/>低维结构排序"]
    C1 --> C2["SVD deflation<br/>去掉 trivial/NNZ 主方向"]
    C2 --> C3["Fiedler reorder<br/>row-overlap graph normalized cut"]
    C3 --> C4["Fiedler + local NNZ<br/>先结构排序再 macro 内 NNZ"]
    C4 --> C5["NNZ-first macro spectral<br/>先 NNZ 骨架再 macro 内 SVD/Fiedler"]
    C5 --> C6["Bootes spectral clustering<br/>谱聚类后塞 wave"]
    C6 --> C7["Morton / multi-dim spectral<br/>减少 1D 投影损失"]
    C7 --> C8["结论<br/>适合结构诊断/论文解释<br/>不适合作最终 solver"]

    A --> D["Global Greedy / BCG CUDA 系"]
    D --> D1["global_greedy<br/>S = M M^T 全局 row overlap"]
    D1 --> D2["banded_greedy<br/>NNZ band + overlap greedy"]
    D2 --> D3["banded_window_greedy<br/>band 内 window overlap"]
    D3 --> D4["optimal_reorder_cuda / bcg_l2<br/>旧 CUDA production 候选"]
    D4 --> D5["结论<br/>row-to-row overlap 不等于 wave-level KV union"]

    A --> E["Union Oracle 系"]
    E --> E1["marginal_union_wave<br/>直接最小化当前 wave KV union"]
    E1 --> E2["banded_union_wave<br/>NNZ macro 内 union packing"]
    E2 --> E3["banded_union_sequenced<br/>macro 内 wave overlap 排序"]
    E3 --> E4["weighted / rolling / spectral_union<br/>KV popularity / cache / spectral candidate"]
    E4 --> E5["结论<br/>质量上界强<br/>但 Python overhead 太大"]

    A --> F["Auction CUDA 系"]
    F --> F1["auction v1<br/>simultaneous multi-wave assignment"]
    F1 --> F2["lane-aware auction<br/>加 shear/lane 约束"]
    F2 --> F3["auction v2<br/>macro 内 sequential wave construction"]
    F3 --> F4["boundary_dp<br/>KV index 方向按边界 DP"]
    F4 --> F5["start_first<br/>macro path 固定从 wave0 开始"]
    F5 --> F6["当前最强低开销候选<br/>auction + boundary_dp + start_first"]

    A --> G["Elastic / Adaptive Window 系"]
    G --> G1["elastic candidate window<br/>NNZ plateau 边界扩窗"]
    G1 --> G2["guarded elastic<br/>只有显著更优才借未来 row"]
    G2 --> G3["结论<br/>搜索空间更大但破坏未来 macro<br/>不默认启用"]

    A --> H["Partition / Segment 系"]
    H --> H1["partition_refined_union<br/>fixed-capacity wave swap"]
    H1 --> H2["segment_partition<br/>加入 ordered transition/run cost"]
    H2 --> H3["geometry penalty<br/>KV interval / query span guard"]
    H3 --> H4["结论<br/>dense 有收益<br/>LTX 变差<br/>说明不是纯 partition"]

    A --> I["Sliding Window 系"]
    I --> I1["wave-level seqwin<br/>next wave 看前 K 个 wave"]
    I1 --> I2["construction sliding cache<br/>构造 wave 时看 previous wave cache"]
    I2 --> I3["row-window<br/>candidate row 看最近 K 个已选 row"]
    I3 --> I4["结论<br/>连续 sliding score 都不如 start_first<br/>最多未来做 tie-break"]
```

## 胜负关系图

```mermaid
flowchart LR
    N["NNZ/Wave<br/>保 shear"] --> U["Union Oracle<br/>直接降 wave KV union"]
    S["Spectral/Fiedler/SVD<br/>看全局结构"] --> U
    G["Global Greedy/BCG<br/>row overlap path"] --> U

    U --> A["Auction CUDA v2<br/>低 overhead 近似 union"]
    A --> B["boundary_dp<br/>KV index 方向优化"]
    B --> C["start_first<br/>保 macro 构造相位"]
    C --> BEST["当前最佳<br/>auction + boundary_dp + start_first"]

    E["Elastic"] -. "不稳" .-> X["淘汰为默认"]
    P["Partition/Segment"] -. "dense 有效, LTX 伤害" .-> R["研究工具"]
    W["Sliding Window"] -. "连续项不赢" .-> T["只保留 tie-break 可能性"]
```

## 当前主线

```text
anchored fixed-capacity wave packing

wave 内:
  marginal KV union

wave 内输出:
  NNZ 降序

macro 内:
  start = wave0
  next = overlap(previous wave)

KV index:
  boundary_dp
```

当前推荐 benchmark 参数：

```bash
--mode auction_union_reorder_cuda \
--kv-order boundary_dp \
--auction-sequence-start-first
```

## 递进关系总结

```text
NNZ 系发现：
  降序骨架必须保。

Spectral 系发现：
  全局结构有解释力，但不能满足 132 容量。
  即使反过来先 NNZ 骨架、再 macro 内 SVD/Fiedler 调整，
  仍明显输给 auction 的 fixed-capacity union packing。

Union 系发现：
  真正目标是 wave-level KV union。

Auction 系：
  把 Union 目标 CUDA 化，降低 overhead。

start_first：
  发现 macro 内 wave path 起点不能乱，必须保构造相位。

Partition / Sliding 系：
  进一步验证过度追求局部/cache proxy 会伤害真实 FA4。
```
