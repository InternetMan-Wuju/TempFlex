#!/usr/bin/env python3
"""Run no-reorder sparse-mask parameter sweeps under NCU.

This script intentionally varies only sparse mask parameters. It profiles the
same FlashInfer per-head BSA kernel with mode=no_reorder.
"""

from __future__ import annotations

import argparse
import csv
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


REPO = Path("/data/daizijian/daizijian/new-vllm-omni-for-sparse-attn")
ENV = Path("/data/daizijian/daizijian/activate_vllm_omni_sparse_new.sh")
PROFILE = Path("/data/daizijian/daizijian/vllm-omni/examples/offline_inference/text_to_video/profile_reorder_l2.py")
BUILDER = REPO / "examples/offline_inference/text_to_video/build_sparse_param_profile_inputs.py"


@dataclass(frozen=True)
class Case:
    name: str
    method: str
    block_m: int = 128
    block_n: int = 128
    topk_ratio: float | None = None
    cdf_threshold: float | None = None
    q_keep_ratio: float | None = None
    min_blocks: int = 4
    density: float | None = None
    row_mode: str | None = None
    target_cv: float | None = None
    xattn_threshold: float | None = None


def _tag(x: float) -> str:
    return f"{x:.2f}".replace(".", "p")


def _shell(cmd: str, log: Path) -> int:
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w") as f:
        proc = subprocess.run(cmd, shell=True, cwd=REPO, stdout=f, stderr=subprocess.STDOUT, executable="/bin/bash")
    return proc.returncode


def _build_cmd(case: Case, out: Path, gpu: int, seq_len: int) -> str:
    parts = [
        f"source {ENV} &&",
        f"CUDA_VISIBLE_DEVICES={gpu}",
        sys.executable,
        str(BUILDER),
        f"--method {case.method}",
        f"--block-m {case.block_m}",
        f"--block-n {case.block_n}",
        f"--seq-len {seq_len}",
        f"--output {out}",
        "--device cuda:0",
    ]
    if case.topk_ratio is not None:
        parts.append(f"--topk-ratio {case.topk_ratio}")
    if case.cdf_threshold is not None:
        parts.append(f"--cdf-threshold {case.cdf_threshold}")
    if case.q_keep_ratio is not None:
        parts.append(f"--q-keep-ratio {case.q_keep_ratio}")
    if case.density is not None:
        parts.append(f"--density {case.density}")
    if case.row_mode is not None:
        parts.append(f"--row-mode {case.row_mode}")
    if case.target_cv is not None:
        parts.append(f"--target-cv {case.target_cv}")
    parts.append(f"--min-blocks {case.min_blocks}")
    return " ".join(parts)


def _profile_cmd(case: Case, profile_inputs: Path, out_prefix: Path, summary_md: Path, gpu: int, seq_len: int, runs: int) -> str:
    parts = [
        f"source {ENV} &&",
        f"CUDA_VISIBLE_DEVICES={gpu}",
        sys.executable,
        str(PROFILE),
        f"--profile-inputs {profile_inputs}",
        "--mode no_reorder",
        f"--seq-len {seq_len}",
        f"--runs {runs}",
        "--ncu-main-kernel-only",
        f"--summary-md {summary_md}",
        f"--output-prefix {out_prefix}",
    ]
    if case.xattn_threshold is not None:
        parts.append(f"--xattn-threshold {case.xattn_threshold}")
        parts.append(f"--block-m {case.block_m}")
        parts.append(f"--block-n {case.block_n}")
    return " ".join(parts)


def _parse_summary(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.exists():
        return data
    for line in path.read_text(errors="ignore").splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            data[key.strip()] = value.strip()
    return data


def _case_grid(kind: str) -> list[Case]:
    cases: list[Case] = []
    if kind == "new_modes":
        for thr in (0.10, 0.30, 0.50, 0.70, 0.90):
            cases.append(Case(name=f"minference_vs_t{_tag(thr)}_b128", method="minference_vs", cdf_threshold=thr))
            cases.append(Case(name=f"flexprefill_g{_tag(thr)}_b128", method="flexprefill", cdf_threshold=thr))
            cases.append(Case(name=f"vmoba_thr_t{_tag(thr)}_b128", method="vmoba_thr", cdf_threshold=thr))
        return cases
    if kind in ("all", "methods"):
        for ratio in (0.10, 0.30, 0.50, 0.70, 0.90):
            for method in ("sparge_topk", "vsa_topk", "sla_topk"):
                cases.append(Case(name=f"{method}_r{_tag(ratio)}_b128", method=method, topk_ratio=ratio))
        for thr in (0.10, 0.30, 0.50, 0.70, 0.90):
            cases.append(Case(name=f"longcat_cdf_t{_tag(thr)}_b128", method="longcat_cdf", cdf_threshold=thr))
            cases.append(Case(name=f"xattn_t{_tag(thr)}_b128", method="xattn", cdf_threshold=thr))
        for q_keep in (0.25, 0.50, 1.00):
            for thr in (0.30, 0.50, 0.70, 0.90):
                cases.append(
                    Case(
                        name=f"bsa_cdf_q{_tag(q_keep)}_t{_tag(thr)}_b128",
                        method="bsa_cdf",
                        cdf_threshold=thr,
                        q_keep_ratio=q_keep,
                    )
                )
    if kind in ("all", "random"):
        for density in (0.10, 0.20, 0.30, 0.50, 0.70, 0.90):
            cases.append(
                Case(
                    name=f"random_d{_tag(density)}_cv0p50_b128",
                    method="random",
                    density=density,
                    row_mode="target_cv",
                    target_cv=0.50,
                )
            )
        for cv in (0.00, 0.25, 0.50, 0.75, 1.00, 1.25):
            row_mode = "uniform" if cv == 0.00 else "target_cv"
            cases.append(
                Case(
                    name=f"random_d0p30_cv{_tag(cv)}_b128",
                    method="random",
                    density=0.30,
                    row_mode=row_mode,
                    target_cv=cv,
                )
            )
        cases.append(Case(name="random_d0p30_highcv_b128", method="random", density=0.30, row_mode="high_cv"))
    if kind == "block":
        for bm, bn in ((64, 64), (64, 128), (128, 64), (128, 128)):
            cases.append(Case(name=f"random_d0p30_cv0p50_b{bm}x{bn}", method="random", block_m=bm, block_n=bn, density=0.30, row_mode="target_cv", target_cv=0.50))
            cases.append(Case(name=f"sla_topk_r0p30_b{bm}x{bn}", method="sla_topk", block_m=bm, block_n=bn, topk_ratio=0.30))
            cases.append(Case(name=f"longcat_cdf_t0p70_b{bm}x{bn}", method="longcat_cdf", block_m=bm, block_n=bn, cdf_threshold=0.70))
    return cases


def _worker(gpu: int, cases: list[Case], root: Path, seq_len: int, runs: int) -> None:
    for case in cases:
        case_dir = root / case.name
        case_dir.mkdir(parents=True, exist_ok=True)
        profile_inputs = case_dir / "profile_inputs.pt"
        if not profile_inputs.exists():
            rc = _shell(_build_cmd(case, profile_inputs, gpu, seq_len), case_dir / "build.log")
            if rc != 0:
                (case_dir / "FAILED").write_text("build failed\n")
                continue
        out_prefix = case_dir / "no_reorder" / "no_reorder"
        summary_path = out_prefix.parent / "no_reorder_summary.txt"
        if summary_path.exists():
            continue
        rc = _shell(
            _profile_cmd(case, profile_inputs, out_prefix, root / "L2_CACHE_SUMMARY.md", gpu, seq_len, runs),
            case_dir / "profile.log",
        )
        if rc != 0:
            (case_dir / "FAILED").write_text("profile failed\n")


def _partition(items: list[Case], n: int) -> list[list[Case]]:
    buckets = [[] for _ in range(n)]
    for i, item in enumerate(items):
        buckets[i % n].append(item)
    return buckets


def _collect(root: Path, cases: Iterable[Case], csv_path: Path) -> None:
    fieldnames = [
        "case",
        "method",
        "block_m",
        "block_n",
        "param",
        "seq_len",
        "density",
        "density_min",
        "density_max",
        "attn_time_ms",
        "l2_request_hit_pct",
        "l2_sector_hit_pct",
        "dram_pct_of_peak",
        "compute_sm_pct",
        "dram_gbps",
        "status",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for case in cases:
            summary = _parse_summary(root / case.name / "no_reorder/no_reorder_summary.txt")
            if summary:
                status = "ok"
            elif (root / case.name / "FAILED").exists():
                status = "failed"
            else:
                status = "missing"
            param = ""
            if case.method == "xattn":
                param = f"xattn_threshold={case.cdf_threshold}"
            elif case.xattn_threshold is not None:
                param = f"xattn_threshold={case.xattn_threshold}"
            elif case.topk_ratio is not None:
                param = f"topk_ratio={case.topk_ratio}"
            elif case.method == "minference_vs":
                param = f"budget_ratio={case.cdf_threshold}"
            elif case.method == "flexprefill":
                param = f"gamma={case.cdf_threshold}"
            elif case.method == "vmoba_thr":
                param = f"threshold={case.cdf_threshold}"
            elif case.method == "bsa_cdf":
                param = f"q_keep={case.q_keep_ratio},cdf={case.cdf_threshold}"
            elif case.cdf_threshold is not None:
                param = f"cdf={case.cdf_threshold}"
            elif case.method == "random":
                param = f"density={case.density},row_mode={case.row_mode},cv={case.target_cv}"
            writer.writerow(
                {
                    "case": case.name,
                    "method": case.method,
                    "block_m": case.block_m,
                    "block_n": case.block_n,
                    "param": param,
                    "seq_len": summary.get("seq_len", ""),
                    "density": summary.get("density", ""),
                    "density_min": summary.get("density_min", ""),
                    "density_max": summary.get("density_max", ""),
                    "attn_time_ms": summary.get("attn_time_ms", ""),
                    "l2_request_hit_pct": summary.get("l2_request_hit_pct", ""),
                    "l2_sector_hit_pct": summary.get("l2_sector_hit_pct", ""),
                    "dram_pct_of_peak": summary.get("dram_pct_of_peak", ""),
                    "compute_sm_pct": summary.get("compute_sm_pct", ""),
                    "dram_gbps": summary.get("dram_gbps", ""),
                    "status": status,
                }
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=REPO / "examples/offline_inference/text_to_video/no_reorder_param_l2_sweep_20260523")
    parser.add_argument("--seq-len", type=int, default=131072)
    parser.add_argument("--runs", type=int, default=1)
    parser.add_argument("--gpus", type=str, default="0,1,2,3,4,5,6,7")
    parser.add_argument("--kind", choices=("all", "methods", "random", "block", "new_modes"), default="all")
    args = parser.parse_args()

    gpus = [int(x) for x in args.gpus.split(",") if x.strip()]
    cases = _case_grid(args.kind)
    args.root.mkdir(parents=True, exist_ok=True)
    (args.root / "cases.txt").write_text("\n".join(c.name for c in cases) + "\n")
    print(f"[sweep] root={args.root}")
    print(f"[sweep] seq_len={args.seq_len} runs={args.runs} cases={len(cases)} gpus={gpus}")

    procs: list[subprocess.Popen[bytes]] = []
    for gpu, bucket in zip(gpus, _partition(cases, len(gpus)), strict=False):
        if not bucket:
            continue
        cmd = [
            sys.executable,
            __file__,
            "--root",
            str(args.root),
            "--seq-len",
            str(args.seq_len),
            "--runs",
            str(args.runs),
            "--gpus",
            str(gpu),
            "--kind",
            args.kind,
            "--_worker",
        ]
        env = os.environ.copy()
        env["SPARSE_PARAM_SWEEP_GPU"] = str(gpu)
        env["SPARSE_PARAM_SWEEP_CASES"] = ",".join(c.name for c in bucket)
        procs.append(subprocess.Popen(cmd, cwd=REPO, env=env))

    while any(p.poll() is None for p in procs):
        alive = sum(p.poll() is None for p in procs)
        print(f"[sweep] {alive} workers alive", flush=True)
        time.sleep(30)
        _collect(args.root, cases, args.root / "summary.csv")

    for p in procs:
        if p.wait() != 0:
            print(f"[sweep] worker failed with rc={p.returncode}", file=sys.stderr)
    _collect(args.root, cases, args.root / "summary.csv")
    print(f"[sweep] wrote {args.root / 'summary.csv'}")


def _worker_entry() -> bool:
    if "--_worker" not in sys.argv:
        return False
    sys.argv.remove("--_worker")
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--seq-len", type=int, required=True)
    parser.add_argument("--runs", type=int, required=True)
    parser.add_argument("--gpus", type=str, required=True)
    parser.add_argument("--kind", choices=("all", "methods", "random", "block", "new_modes"), required=True)
    args = parser.parse_args()
    gpu = int(os.environ["SPARSE_PARAM_SWEEP_GPU"])
    allowed = set(os.environ["SPARSE_PARAM_SWEEP_CASES"].split(","))
    cases = [c for c in _case_grid(args.kind) if c.name in allowed]
    _worker(gpu, cases, args.root, args.seq_len, args.runs)
    return True


if __name__ == "__main__":
    if not _worker_entry():
        main()
