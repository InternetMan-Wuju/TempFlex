#!/usr/bin/env python3
"""Summarize FA4 synthetic NCU reports in a directory."""

from __future__ import annotations

import csv
import subprocess
import sys
from pathlib import Path


def unit_scale(value: str, unit: str, kind: str) -> float:
    x = float(value)
    if kind == "time_ms":
        return x * {
            "ns": 1e-6,
            "nsecond": 1e-6,
            "us": 1e-3,
            "usecond": 1e-3,
            "ms": 1.0,
            "s": 1000.0,
        }.get(unit, 1.0)
    if kind == "bytes":
        return x * {
            "byte": 1.0,
            "Kbyte": 1e3,
            "Mbyte": 1e6,
            "Gbyte": 1e9,
            "Tbyte": 1e12,
        }.get(unit, 1.0)
    return x


def load_static_rows(out_dir: Path) -> list[dict[str, str]]:
    csv_path = out_dir / "results.csv"
    if not csv_path.exists():
        return []
    with csv_path.open() as f:
        return list(csv.DictReader(f))


def match_static(rep: Path, rows: list[dict[str, str]]) -> dict[str, str]:
    stem = rep.stem
    candidates = []
    for row in rows:
        pattern = row["pattern"]
        if pattern not in stem:
            continue
        if f"_h{row['heads']}_" not in stem:
            continue
        if f"_b{row['q_blocks']}_" not in stem:
            continue
        if f"_nnz{round(float(row['avg_nnz']))}" not in stem:
            continue
        seed = row.get("seed")
        if pattern == "random_variable_nnz" and seed and f"_s{seed}" not in stem:
            continue
        candidates.append(row)
    if len(candidates) == 1:
        return candidates[0]
    if candidates:
        return candidates[-1]
    raise KeyError(f"Could not match static CSV row for {rep.name}")


def import_report(rep: Path) -> tuple[dict[str, str], dict[str, str]]:
    text = subprocess.check_output(
        ["ncu", "--import", str(rep), "--csv", "--page", "raw"],
        text=True,
    )
    rows = list(csv.reader(text.splitlines()))
    if len(rows) < 3:
        raise RuntimeError(f"Unexpected NCU CSV for {rep}")
    header, units, values = rows[0], rows[1], rows[2]
    return dict(zip(header, values)), dict(zip(header, units))


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {Path(sys.argv[0]).name} OUT_DIR", file=sys.stderr)
        return 2
    out_dir = Path(sys.argv[1])
    static_rows = load_static_rows(out_dir)
    reports = sorted(out_dir.glob("*.ncu-rep"))
    if not reports:
        print(f"No .ncu-rep files in {out_dir}", file=sys.stderr)
        return 1

    rows = []
    for rep in reports:
        static = match_static(rep, static_rows)
        raw, units = import_report(rep)
        sparse_blocks = float(static["sparse_blocks"])
        time_ms = unit_scale(
            raw["gpu__time_duration.sum"],
            units["gpu__time_duration.sum"],
            "time_ms",
        )
        dram_read = unit_scale(
            raw["dram__bytes_read.sum"],
            units["dram__bytes_read.sum"],
            "bytes",
        )
        dram_write = unit_scale(
            raw["dram__bytes_write.sum"],
            units["dram__bytes_write.sum"],
            "bytes",
        )
        rows.append(
            {
                "pattern": static["pattern"].replace("random_variable_nnz", "random_varcv"),
                "heads": int(static["heads"]),
                "blocks": int(static["q_blocks"]),
                "density": float(static["density"]),
                "avg_nnz": float(static["avg_nnz"]),
                "row_nnz_cv": float(static["nnz_cv"]),
                "nnz_min": int(float(static["nnz_min"])),
                "nnz_max": int(float(static["nnz_max"])),
                "head_total_cv": float(static.get("head_total_cv", 0.0)),
                "seed": int(static.get("seed", 0) or 0),
                "sparse_blocks": int(sparse_blocks),
                "ncu_ms": time_ms,
                "event_ms": float(static["kernel_ms"]),
                "dram_read_mb": dram_read / 1e6,
                "dram_write_mb": dram_write / 1e6,
                "hbm_B_block": dram_read / sparse_blocks,
                "l2_hit": float(raw["lts__t_sector_hit_rate.pct"]),
                "dram_sol": float(raw["gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed"]),
                "l2_sol": float(raw["lts__throughput.avg.pct_of_peak_sustained_elapsed"]),
                "sm_sol": float(raw["sm__throughput.avg.pct_of_peak_sustained_elapsed"]),
                "tensor": float(raw["sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed"]),
                "longsb": float(raw["smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct"]),
                "wait": float(raw["smsp__warp_issue_stalled_wait_per_warp_active.pct"]),
                "barrier": float(raw["smsp__warp_issue_stalled_barrier_per_warp_active.pct"]),
                "gpc_ghz": float(raw["gpc__cycles_elapsed.avg"]) / (time_ms * 1e6),
            }
        )

    rows.sort(key=lambda r: (r["density"], {
        "random_varcv": 0,
        "regular_shared": 1,
        "regular_sliding": 2,
    }.get(r["pattern"], 9), r["seed"]))

    extracted = out_dir / "summary_extracted.csv"
    fieldnames = list(rows[0])
    with extracted.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print("| density | pattern | seed | H | B | avg NNZ | row CV | NNZ min/max | head CV | sparse blocks | NCU ms | DRAM read MB | HBM/block B | L2 hit % | DRAM SOL % | L2 SOL % | SM SOL % | tensor % | long SB % | wait % | barrier % | GPC GHz |")
    print("|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for row in rows:
        print(
            f"| {row['density'] * 100:.1f}% | {row['pattern']} | {row['seed']} | {row['heads']} | {row['blocks']} | "
            f"{row['avg_nnz']:.1f} | {row['row_nnz_cv']:.3f} | {row['nnz_min']}/{row['nnz_max']} | "
            f"{row['head_total_cv']:.3f} | {row['sparse_blocks']:,} | {row['ncu_ms']:.1f} | "
            f"{row['dram_read_mb']:.0f} | {row['hbm_B_block']:.0f} | {row['l2_hit']:.1f} | "
            f"{row['dram_sol']:.1f} | {row['l2_sol']:.1f} | {row['sm_sol']:.1f} | "
            f"{row['tensor']:.1f} | {row['longsb']:.1f} | {row['wait']:.1f} | "
            f"{row['barrier']:.1f} | {row['gpc_ghz']:.3f} |"
        )

    print("\nRatios vs regular_shared:")
    for density in sorted({row["density"] for row in rows}):
        sub = {row["pattern"]: row for row in rows if row["density"] == density}
        base = sub.get("regular_shared")
        if not base:
            continue
        for pattern in ("random_varcv", "regular_sliding"):
            row = sub.get(pattern)
            if not row:
                continue
            print(
                f"density={density:.3f} {pattern}: "
                f"time_ratio={row['ncu_ms'] / base['ncu_ms']:.3f} "
                f"dram_ratio={row['dram_read_mb'] / base['dram_read_mb']:.2f} "
                f"l2_hit_delta={row['l2_hit'] - base['l2_hit']:.1f} "
                f"tensor_delta={row['tensor'] - base['tensor']:.1f}"
            )
    print(f"\nWrote {extracted}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
