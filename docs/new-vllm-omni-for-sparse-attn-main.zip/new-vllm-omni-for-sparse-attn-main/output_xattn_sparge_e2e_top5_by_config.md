# Top-5 E2E Reorder Results By Config

## sparge threshold=0.7 frames=65

- L=61200, blocks=479, density=0.3429

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `no_reorder` | 5858.4 | +0.00% | 4832.0 | +0.00% | 96.0 | 6.5 |
| 2 | `wave_2d_reorder` | 6413.9 | -9.48% | 4317.0 | +10.66% | 532.9 | 429.3 |
| 3 | `spectral_morton_wave_reorder@d3m075` | 6466.2 | -10.37% | 4495.2 | +6.97% | 935.0 | 859.6 |
| 4 | `auction_union_reorder_cuda` | 6515.5 | -11.22% | 4537.8 | +6.09% | 1086.8 | 450.4 |
| 5 | `wave_reorder` | 7340.4 | -25.30% | 6044.1 | -25.08% | 336.5 | 259.6 |

## sparge threshold=0.7 frames=169

- L=154800, blocks=1210, density=0.3230

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `spectral_morton_wave_reorder@d3m075` | 13554.4 | +17.62% | 11319.4 | +15.83% | 843.9 | 614.6 |
| 2 | `spectral_morton_wave_reorder` | 13650.8 | +17.03% | 11413.3 | +15.14% | 718.8 | 488.2 |
| 3 | `nnz_3step_reorder` | 15019.8 | +8.71% | 13021.3 | +3.18% | 303.4 | 66.8 |
| 4 | `auction_union_reorder_cuda` | 15292.0 | +7.06% | 10815.9 | +19.58% | 3068.1 | 1722.3 |
| 5 | `wave_reorder` | 15624.6 | +5.04% | 13601.2 | -1.13% | 529.2 | 286.5 |

## sparge threshold=0.7 frames=305

- L=277200, blocks=2166, density=0.3363

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `spectral_morton_wave_reorder` | 35091.1 | +18.43% | 31622.2 | +15.51% | 1108.3 | 583.3 |
| 2 | `spectral_morton_wave_reorder@d3m075` | 35312.7 | +17.91% | 31706.0 | +15.29% | 1321.6 | 793.6 |
| 3 | `wave_reorder` | 35440.7 | +17.61% | 32043.5 | +14.39% | 874.5 | 336.9 |
| 4 | `wave_1d_reorder` | 36403.2 | +15.38% | 32960.1 | +11.94% | 866.6 | 329.3 |
| 5 | `wave_2d_reorder` | 38139.7 | +11.34% | 34528.1 | +7.75% | 1106.9 | 569.5 |

## xattn threshold=0.6 frames=169

- L=154800, blocks=1210, density=0.2086

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_1d_reorder` | 46555.8 | +3.82% | 29006.5 | +5.56% | 1447.1 | 547.8 |
| 2 | `spectral_morton_wave_reorder` | 46970.7 | +2.96% | 28883.2 | +5.96% | 2039.2 | 1143.7 |
| 3 | `wave_2d_reorder` | 47087.0 | +2.72% | 29263.8 | +4.72% | 1784.5 | 889.8 |
| 4 | `no_reorder` | 48403.4 | +0.00% | 30713.3 | +0.00% | 949.2 | 14.5 |
| 5 | `wave_reorder` | 49110.8 | -1.46% | 31033.5 | -1.04% | 1560.6 | 664.7 |

## xattn threshold=0.6 frames=305

- L=277200, blocks=2166, density=0.2108

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_2d_reorder` | 131530.5 | +8.25% | 85090.1 | +13.39% | 3898.1 | 1771.0 |
| 2 | `wave_1d_reorder` | 131762.7 | +8.09% | 86034.0 | +12.43% | 3194.6 | 1069.1 |
| 3 | `wave_reorder` | 132937.1 | +7.27% | 87221.9 | +11.22% | 3229.3 | 1102.8 |
| 4 | `no_reorder` | 143356.0 | +0.00% | 98248.0 | +0.00% | 2171.7 | 14.7 |

## xattn threshold=0.7 frames=65

- L=61200, blocks=479, density=0.2675

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_reorder` | 15997.9 | +4.86% | 10427.3 | +9.39% | 792.6 | 494.6 |
| 2 | `nnz_3step_reorder` | 16205.1 | +3.62% | 10796.5 | +6.18% | 453.3 | 151.9 |
| 3 | `wave_1d_reorder` | 16361.3 | +2.70% | 10479.4 | +8.94% | 822.9 | 526.5 |
| 4 | `spectral_morton_wave_reorder` | 16687.5 | +0.76% | 10472.5 | +9.00% | 1483.6 | 1189.7 |
| 5 | `no_reorder` | 16814.6 | +0.00% | 11507.7 | +0.00% | 348.3 | 13.6 |

## xattn threshold=0.7 frames=169

- L=154800, blocks=1210, density=0.2762

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_1d_reorder` | 54521.8 | +11.57% | 36943.0 | +16.24% | 1454.6 | 554.6 |
| 2 | `wave_2d_reorder` | 55062.3 | +10.69% | 37119.7 | +15.84% | 1797.3 | 897.6 |
| 3 | `spectral_morton_wave_reorder@d2m05` | 55160.0 | +10.53% | 36900.2 | +16.34% | 2068.3 | 1169.6 |
| 4 | `spectral_morton_wave_reorder` | 55216.3 | +10.44% | 37047.0 | +16.00% | 2120.4 | 1222.1 |
| 5 | `wave_reorder` | 55322.1 | +10.27% | 37691.8 | +14.54% | 1474.0 | 576.8 |

## xattn threshold=0.7 frames=305

- L=277200, blocks=2166, density=0.2887

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_1d_reorder` | 161135.8 | +9.70% | 115222.0 | +13.29% | 3205.1 | 1078.8 |
| 2 | `wave_2d_reorder` | 161195.8 | +9.66% | 114912.9 | +13.53% | 3891.8 | 1765.2 |
| 3 | `spectral_morton_wave_reorder@d3m075` | 161778.1 | +9.34% | 114662.0 | +13.71% | 4678.0 | 2551.2 |
| 4 | `spectral_morton_wave_reorder@d2m05` | 161930.5 | +9.25% | 115394.1 | +13.16% | 3955.3 | 1829.0 |
| 5 | `spectral_morton_wave_reorder` | 162166.9 | +9.12% | 115531.6 | +13.06% | 3970.3 | 1843.0 |

## xattn threshold=0.8 frames=65

- L=61200, blocks=479, density=0.3604

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_1d_reorder` | 17715.4 | +23.20% | 11909.2 | +28.80% | 883.3 | 584.2 |
| 2 | `wave_2d_reorder` | 18017.4 | +21.89% | 12176.6 | +27.20% | 936.3 | 636.5 |
| 3 | `wave_reorder` | 18861.4 | +18.23% | 12920.6 | +22.75% | 846.0 | 544.6 |
| 4 | `spectral_morton_wave_reorder@d3m075` | 19178.9 | +16.85% | 12014.4 | +28.17% | 2079.8 | 1780.8 |
| 5 | `no_reorder` | 23066.1 | +0.00% | 16726.2 | +0.00% | 371.4 | 15.4 |

## xattn threshold=0.8 frames=169

- L=154800, blocks=1210, density=0.3668

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_reorder` | 65474.0 | +4.09% | 47832.7 | +6.60% | 1457.1 | 558.4 |
| 2 | `wave_2d_reorder` | 65746.1 | +3.69% | 47877.4 | +6.51% | 1804.5 | 905.8 |
| 3 | `spectral_morton_wave_reorder` | 65950.1 | +3.39% | 47687.9 | +6.88% | 2041.0 | 1144.4 |
| 4 | `spectral_morton_wave_reorder@d3m075` | 66325.2 | +2.84% | 47615.8 | +7.02% | 2584.3 | 1690.2 |
| 5 | `no_reorder` | 68263.2 | +0.00% | 51210.1 | +0.00% | 939.5 | 13.9 |

## xattn threshold=0.8 frames=305

- L=277200, blocks=2166, density=0.3893

| rank | mode | total ms | total gain | kernel ms | kernel gain | reorder ms | algo ms |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `wave_1d_reorder` | 199585.3 | +10.33% | 153793.9 | +13.17% | 3234.6 | 1108.2 |
| 2 | `wave_2d_reorder` | 199615.7 | +10.31% | 153061.3 | +13.58% | 3895.5 | 1767.9 |
| 3 | `spectral_morton_wave_reorder` | 200880.7 | +9.75% | 154257.4 | +12.91% | 3968.1 | 1839.5 |
| 4 | `wave_reorder` | 201834.5 | +9.32% | 155866.7 | +12.00% | 3249.8 | 1122.4 |
| 5 | `spectral_morton_wave_reorder@d3m075` | 201934.5 | +9.27% | 154659.3 | +12.68% | 4678.3 | 2550.1 |
