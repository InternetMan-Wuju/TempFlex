#!/usr/bin/env bash
set -Eeuo pipefail

# Run a minimal Nsight Compute experiment to decide whether FA4 block-sparse
# attention is sensitive to HBM/L2 traffic on this machine.
#
# Usage:
#   scripts/run_fa4_hbm_ncu_check.sh
#
# Useful overrides:
#   CUDA_VISIBLE_DEVICES=0 HEADS=40 BLOCKS=2320 NNZ=480 REPEAT=5 OUT_DIR=/tmp/fa4_ncu \
#     scripts/run_fa4_hbm_ncu_check.sh

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_PY="${ROOT_DIR}/examples/offline_inference/text_to_video/ncu_fa4_blocksparse_profile.py"
OUT_DIR="${OUT_DIR:-${ROOT_DIR}/fa4_hbm_ncu_$(date +%Y%m%d_%H%M%S)}"
HEADS="${HEADS:-40}"
BLOCKS="${BLOCKS:-2320}"
NNZ="${NNZ:-480}"
BLOCK_SIZE="${BLOCK_SIZE:-128}"
DIM="${DIM:-128}"
DTYPE="${DTYPE:-bf16}"
WARMUP="${WARMUP:-2}"
REPEAT="${REPEAT:-5}"
GPU="${CUDA_VISIBLE_DEVICES:-0}"
BROADCAST_METADATA_HEADS="${BROADCAST_METADATA_HEADS:-0}"

METRICS="$(
  python - <<'PY'
from examples.offline_inference.text_to_video.ncu_fa4_blocksparse_profile import NCU_METRICS
print(",".join(NCU_METRICS))
PY
)"

mkdir -p "${OUT_DIR}"

echo "[info] output: ${OUT_DIR}"
echo "[info] CUDA_VISIBLE_DEVICES=${GPU}"
nvidia-smi
ncu --version | sed -n '1,8p'

python - <<'PY'
import importlib.util
import torch
print("[verify] torch", torch.__version__, "cuda", torch.version.cuda)
print("[verify] gpu", torch.cuda.get_device_name())
print("[verify] capability", torch.cuda.get_device_capability())
for mod in ["flash_attn.cute.interface", "flash_attn.cute.block_sparsity", "cutlass", "cuda.bindings"]:
    ok = importlib.util.find_spec(mod) is not None
    print("[verify]", mod, ok)
    assert ok, mod
PY

echo "[smoke] FA4 without NCU"
python "${PROFILE_PY}" \
  --pattern regular_shared \
  --heads 2 \
  --blocks 64 \
  --nnz 16 \
  --block-size "${BLOCK_SIZE}" \
  --dim "${DIM}" \
  --dtype "${DTYPE}" \
  --warmup 1 \
  --repeat 1 \
  | tee "${OUT_DIR}/smoke.log"

run_case() {
  local pattern="$1"
  local name="fa4_${pattern}_h${HEADS}_mb${BLOCKS}_nnz${NNZ}"
  echo "[ncu] ${pattern}"
  local broadcast_args=()
  if [[ "${BROADCAST_METADATA_HEADS}" == "1" ]]; then
    broadcast_args+=(--broadcast-metadata-heads)
  fi
  CUDA_VISIBLE_DEVICES="${GPU}" ncu \
    --clock-control none \
    --target-processes all \
    --profile-from-start off \
    --metrics "${METRICS}" \
    -f -o "${OUT_DIR}/${name}" \
    python "${PROFILE_PY}" \
      --pattern "${pattern}" \
      --heads "${HEADS}" \
      --blocks "${BLOCKS}" \
      --nnz "${NNZ}" \
      --block-size "${BLOCK_SIZE}" \
      --dim "${DIM}" \
      --dtype "${DTYPE}" \
      --warmup "${WARMUP}" \
      --repeat "${REPEAT}" \
      "${broadcast_args[@]}" \
      --profile \
      | tee "${OUT_DIR}/${name}.log"

  ncu --import "${OUT_DIR}/${name}.ncu-rep" --csv > "${OUT_DIR}/${name}.csv"
}

run_case random
run_case regular_shared
run_case regular_sliding

python "${ROOT_DIR}/scripts/summarize_fa4_hbm_ncu.py" \
  --out-dir "${OUT_DIR}" \
  --heads "${HEADS}" \
  --blocks "${BLOCKS}" \
  --nnz "${NNZ}" \
  | tee "${OUT_DIR}/summary.txt"

echo "[done] ${OUT_DIR}"
