#!/usr/bin/env bash
set -Eeuo pipefail

# Fixed sequence-length threshold sweep for real XAttention QKV dumps.
# This is the right first test when the question is:
#   "at the largest seqlen, does lowering/raising threshold make FA4 exposed-memory-bound?"
#
# Example:
#   TARGET_GPU=4 LOCK_CLOCK_MHZ=900 \
#     THRESHOLDS="0.6 0.7 0.8 0.9 0.95 0.99" \
#     scripts/run_xattn_threshold_memory_sweep.sh

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_PY="${ROOT_DIR}/examples/offline_inference/text_to_video/ncu_xattn_qkv_reorder.py"
OUT_DIR="${OUT_DIR:-${ROOT_DIR}/xattn_threshold_ncu_$(date +%Y%m%d_%H%M%S)}"
DUMP="${DUMP:-/data1/dhelix_shared/daizijian/QKVtensor/dense_dump_401f/longcat_layer0.pt}"
THRESHOLDS="${THRESHOLDS:-0.6 0.7 0.8 0.9 0.95 0.99}"
MODE="${MODE:-no_reorder}"
KV_ORDER="${KV_ORDER:-asc}"
BLOCKS="${BLOCKS:--1}"
HEADS="${HEADS:--1}"
HEAD_START="${HEAD_START:-0}"
LAYER="${LAYER:-0}"
TIMESTEP="${TIMESTEP:--1}"
BLOCK_SIZE="${BLOCK_SIZE:-128}"
CHUNK_SIZE="${CHUNK_SIZE:-1024}"
STRIDE="${STRIDE:-32}"
WARMUP="${WARMUP:-2}"
REPEAT="${REPEAT:-5}"
TARGET_GPU="${TARGET_GPU:-${CUDA_VISIBLE_DEVICES:-0}}"
LOCK_CLOCK_MHZ="${LOCK_CLOCK_MHZ:-0}"
PEAK_TFLOPS="${PEAK_TFLOPS:-989.5}"
PEAK_GBPS="${PEAK_GBPS:-4915}"

METRICS="$(
  python - <<'PY'
from examples.offline_inference.text_to_video.ncu_fa4_blocksparse_profile import NCU_METRICS
print(",".join(NCU_METRICS))
PY
)"

mkdir -p "${OUT_DIR}"

run_nvidia_smi() {
  if [[ "${EUID}" -eq 0 ]]; then
    env -u CUDA_VISIBLE_DEVICES -u GPU nvidia-smi "$@"
  elif command -v sudo >/dev/null 2>&1 && sudo -n true >/dev/null 2>&1; then
    sudo env -u CUDA_VISIBLE_DEVICES -u GPU nvidia-smi "$@"
  else
    return 1
  fi
}

restore_clocks() {
  if [[ "${LOCK_CLOCK_MHZ}" != "0" ]]; then
    run_nvidia_smi -i "${TARGET_GPU}" -rgc >/dev/null 2>&1 || true
  fi
}
trap restore_clocks EXIT

echo "[info] output: ${OUT_DIR}"
echo "[info] target_gpu: ${TARGET_GPU}"
echo "[info] dump: ${DUMP}"
echo "[info] thresholds: ${THRESHOLDS}"
echo "[info] mode: ${MODE} kv_order=${KV_ORDER}"
env -u CUDA_VISIBLE_DEVICES -u GPU nvidia-smi | tee "${OUT_DIR}/nvidia-smi.before.txt"
ncu --version | tee "${OUT_DIR}/ncu-version.txt"

if [[ "${LOCK_CLOCK_MHZ}" != "0" ]]; then
  echo "[clock] locking graphics clock to ${LOCK_CLOCK_MHZ} MHz"
  run_nvidia_smi -i "${TARGET_GPU}" -pm 1 || true
  if ! run_nvidia_smi -i "${TARGET_GPU}" -lgc "${LOCK_CLOCK_MHZ},${LOCK_CLOCK_MHZ}"; then
    echo "[warn] failed to lock clocks; continue unlocked" >&2
  fi
fi

CUDA_VISIBLE_DEVICES="${TARGET_GPU}" python - <<'PY'
import importlib.util
import torch
print("[verify] torch", torch.__version__, "cuda", torch.version.cuda)
print("[verify] gpu", torch.cuda.get_device_name())
print("[verify] capability", torch.cuda.get_device_capability())
for mod in ["flash_attn.cute.interface", "xattn.src.Xattention", "cutlass", "cuda.bindings"]:
    ok = importlib.util.find_spec(mod) is not None
    print("[verify]", mod, ok)
    assert ok, mod
PY

run_case() {
  local threshold="$1"
  local tag="${threshold//./p}"
  local name="xattn_thr${tag}_${MODE}_${KV_ORDER}"
  echo "[ncu] threshold=${threshold}"
  CUDA_VISIBLE_DEVICES="${TARGET_GPU}" ncu \
    --target-processes all \
    --profile-from-start off \
    --metrics "${METRICS}" \
    -f -o "${OUT_DIR}/${name}" \
    python "${PROFILE_PY}" \
      --dump "${DUMP}" \
      --layer "${LAYER}" \
      --timestep "${TIMESTEP}" \
      --threshold "${threshold}" \
      --mode "${MODE}" \
      --kv-order "${KV_ORDER}" \
      --heads "${HEADS}" \
      --head-start "${HEAD_START}" \
      --blocks "${BLOCKS}" \
      --block-size "${BLOCK_SIZE}" \
      --chunk-size "${CHUNK_SIZE}" \
      --stride "${STRIDE}" \
      --warmup "${WARMUP}" \
      --repeat "${REPEAT}" \
      --profile \
      --csv "${OUT_DIR}/python_metrics.csv" \
      | tee "${OUT_DIR}/${name}.log"

  ncu --import "${OUT_DIR}/${name}.ncu-rep" --csv > "${OUT_DIR}/${name}.csv"
}

for threshold in ${THRESHOLDS}; do
  run_case "${threshold}"
done

python "${ROOT_DIR}/scripts/summarize_xattn_seqlen_ncu.py" \
  --out-dir "${OUT_DIR}" \
  --peak-tflops "${PEAK_TFLOPS}" \
  --peak-gbps "${PEAK_GBPS}" \
  | tee "${OUT_DIR}/summary.txt"

env -u CUDA_VISIBLE_DEVICES -u GPU nvidia-smi | tee "${OUT_DIR}/nvidia-smi.after.txt"
echo "[done] ${OUT_DIR}"
