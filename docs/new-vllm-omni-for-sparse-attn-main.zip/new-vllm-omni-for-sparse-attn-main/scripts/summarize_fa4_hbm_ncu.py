#!/usr/bin/env python3
"""Summarize FA4 synthetic NCU reports.

The parser is intentionally tolerant of Nsight Compute CSV variants. It looks
for rows with "Metric Name" / "Metric Value" first, then falls back to any row
whose cells contain one of the requested metric names.
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path


METRICS = [
    "gpu__time_duration.sum",
    "gpu__cycles_elapsed.avg",
    "gpc__cycles_elapsed.avg",
    "sm__cycles_elapsed.avg",
    "smsp__inst_executed.sum",
    "smsp__inst_issued.sum",
    "smsp__inst_issued_per_issue_active.ratio",
    "sm__inst_executed_pipe_tensor.sum",
    "sm__inst_executed_pipe_tensor_op_gmma.sum",
    "smsp__sass_inst_executed_op_shared_gmma.sum",
    "sm__pipe_tensor_op_hmma_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__pipe_tma_cycles_active.avg.pct_of_peak_sustained_elapsed",
    "sm__issue_active.avg.pct_of_peak_sustained_elapsed",
    "smsp__warp_issue_stalled_barrier_per_warp_active.pct",
    "smsp__warp_issue_stalled_dispatch_stall_per_warp_active.pct",
    "smsp__warp_issue_stalled_gmma_per_warp_active.pct",
    "smsp__warp_issue_stalled_lg_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct",
    "smsp__warp_issue_stalled_membar_per_warp_active.pct",
    "smsp__warp_issue_stalled_mio_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_no_instruction_per_warp_active.pct",
    "smsp__warp_issue_stalled_not_selected_per_warp_active.pct",
    "smsp__warp_issue_stalled_short_scoreboard_per_warp_active.pct",
    "smsp__warp_issue_stalled_tex_throttle_per_warp_active.pct",
    "smsp__warp_issue_stalled_wait_per_warp_active.pct",
    "dram__bytes_read.sum",
    "dram__bytes_write.sum",
    "dram__cycles_active_read.sum",
    "lts__t_sector_hit_rate.pct",
    "lts__t_requests_aperture_device_op_read.sum",
    "lts__t_requests_aperture_device_op_read_lookup_hit.sum",
    "lts__t_requests_aperture_device_op_read_lookup_miss.sum",
    "gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed",
    "lts__throughput.avg.pct_of_peak_sustained_elapsed",
    "sm__throughput.avg.pct_of_peak_sustained_elapsed",
    "l1tex__tmain_requests.sum",
    "l1tex__m_xbar2l1tex_read_bytes_mem_global_op_tma_ld.sum",
    "l1tex__m_xbar2l1tex_read_sectors_mem_global_op_tma_ld.sum",
    "l1tex__m_l1tex2xbar_read_requests_replayed_mem_global_op_tma_ld_dest_multicast.sum",
]


def parse_number(text: str) -> float | None:
    if text is None:
        return None
    s = str(text).strip().replace(",", "")
    if not s or s.upper() in {"N/A", "NAN"}:
        return None
    s = s.replace("%", "")
    m = re.search(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", s)
    if not m:
        return None
    return float(m.group(0))


def unit_scale_to_ms(unit: str) -> float:
    u = (unit or "").lower()
    if "nsecond" in u or u == "ns":
        return 1e-6
    if "usecond" in u or "micro" in u or u in {"us", "µs"}:
        return 1e-3
    if "msecond" in u or u == "ms":
        return 1.0
    if "second" in u or u == "s":
        return 1e3
    return 1.0


def unit_scale_to_bytes(unit: str) -> float:
    u = (unit or "").lower()
    if u in {"byte", "bytes", "b"}:
        return 1.0
    if u in {"kbyte", "kbytes", "kb"}:
        return 1e3
    if u in {"mbyte", "mbytes", "mb"}:
        return 1e6
    if u in {"gbyte", "gbytes", "gb"}:
        return 1e9
    if u in {"tbyte", "tbytes", "tb"}:
        return 1e12
    if u in {"kibyte", "kib"}:
        return 1024.0
    if u in {"mibyte", "mib"}:
        return 1024.0**2
    if u in {"gibyte", "gib"}:
        return 1024.0**3
    if u in {"tibyte", "tib"}:
        return 1024.0**4
    return 1.0


def read_metrics(path: Path) -> dict[str, tuple[float, str]]:
    with path.open(newline="") as f:
        rows = list(csv.reader(f))
    if not rows:
        return {}

    header_idx = None
    header = []
    for i, row in enumerate(rows):
        lowered = [c.strip().lower() for c in row]
        if "metric name" in lowered and "metric value" in lowered:
            header_idx = i
            header = row
            break

    out: dict[str, tuple[float, str]] = {}
    if header_idx is not None:
        idx = {name.strip().lower(): j for j, name in enumerate(header)}
        name_col = idx["metric name"]
        value_col = idx["metric value"]
        unit_col = idx.get("metric unit")
        for row in rows[header_idx + 1 :]:
            if len(row) <= max(name_col, value_col):
                continue
            name = row[name_col].strip()
            if name not in METRICS:
                continue
            value = parse_number(row[value_col])
            if value is None:
                continue
            unit = row[unit_col].strip() if unit_col is not None and len(row) > unit_col else ""
            out[name] = (value, unit)
        return out

    # Fallback for compact CSV formats.
    metric_set = set(METRICS)
    for row in rows:
        for i, cell in enumerate(row):
            name = cell.strip()
            if name not in metric_set:
                continue
            for candidate in row[i + 1 :]:
                value = parse_number(candidate)
                if value is not None:
                    out[name] = (value, "")
                    break
    return out


def get(metrics: dict[str, tuple[float, str]], name: str) -> float | None:
    item = metrics.get(name)
    return item[0] if item else None


def get_bytes(metrics: dict[str, tuple[float, str]], name: str) -> float | None:
    item = metrics.get(name)
    return item[0] * unit_scale_to_bytes(item[1]) if item else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--heads", type=int, required=True)
    parser.add_argument("--blocks", type=int, required=True)
    parser.add_argument("--nnz", type=int, required=True)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    denom = args.heads * args.blocks * args.nnz
    rows = []
    for csv_path in sorted(out_dir.glob("fa4_*.csv")):
        metrics = read_metrics(csv_path)
        name = csv_path.stem
        pattern = name.split("_h", 1)[0].replace("fa4_", "")

        time_item = metrics.get("gpu__time_duration.sum")
        time_ms = None
        if time_item:
            time_ms = time_item[0] * unit_scale_to_ms(time_item[1])
        gpc_cycles = get(metrics, "gpc__cycles_elapsed.avg")
        gpc_clock_ghz = gpc_cycles / (time_ms * 1e6) if gpc_cycles is not None and time_ms else None
        dram_read = get_bytes(metrics, "dram__bytes_read.sum")
        dram_write = get_bytes(metrics, "dram__bytes_write.sum")
        hbm_per_block = dram_read / denom if dram_read is not None else None
        l2_hit = get(metrics, "lts__t_sector_hit_rate.pct")
        tensor = (
            get(metrics, "sm__pipe_tensor_op_hmma_cycles_active.avg.pct_of_peak_sustained_elapsed")
            or get(metrics, "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed")
        )
        sm_thr = get(metrics, "sm__throughput.avg.pct_of_peak_sustained_elapsed")
        dram_thr = get(metrics, "gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed")
        lts_thr = get(metrics, "lts__throughput.avg.pct_of_peak_sustained_elapsed")
        long_scoreboard = get(metrics, "smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct")
        rows.append(
            {
                "pattern": pattern,
                "time_ms": time_ms,
                "gpc_clock_ghz": gpc_clock_ghz,
                "dram_read_gb": dram_read / 1e9 if dram_read is not None else None,
                "dram_write_gb": dram_write / 1e9 if dram_write is not None else None,
                "hbm_per_sparse_block_kb": hbm_per_block / 1024 if hbm_per_block is not None else None,
                "l2_hit_pct": l2_hit,
                "tensor_active_pct": tensor,
                "tma_active_pct": get(metrics, "sm__pipe_tma_cycles_active.avg.pct_of_peak_sustained_elapsed"),
                "sm_sol_pct": sm_thr,
                "dram_sol_pct": dram_thr,
                "l2_sol_pct": lts_thr,
                "long_scoreboard_pct": long_scoreboard,
                "membar_pct": get(metrics, "smsp__warp_issue_stalled_membar_per_warp_active.pct"),
                "barrier_pct": get(metrics, "smsp__warp_issue_stalled_barrier_per_warp_active.pct"),
                "gmma_wait_pct": get(metrics, "smsp__warp_issue_stalled_gmma_per_warp_active.pct"),
                "mio_throttle_pct": get(metrics, "smsp__warp_issue_stalled_mio_throttle_per_warp_active.pct"),
                "tex_throttle_pct": get(metrics, "smsp__warp_issue_stalled_tex_throttle_per_warp_active.pct"),
                "lg_throttle_pct": get(metrics, "smsp__warp_issue_stalled_lg_throttle_per_warp_active.pct"),
                "short_scoreboard_pct": get(metrics, "smsp__warp_issue_stalled_short_scoreboard_per_warp_active.pct"),
                "wait_pct": get(metrics, "smsp__warp_issue_stalled_wait_per_warp_active.pct"),
                "no_instruction_pct": get(metrics, "smsp__warp_issue_stalled_no_instruction_per_warp_active.pct"),
                "not_selected_pct": get(metrics, "smsp__warp_issue_stalled_not_selected_per_warp_active.pct"),
                "tensor_inst": get(metrics, "sm__inst_executed_pipe_tensor.sum"),
                "gmma_inst": get(metrics, "sm__inst_executed_pipe_tensor_op_gmma.sum"),
                "sass_gmma_inst": get(metrics, "smsp__sass_inst_executed_op_shared_gmma.sum"),
                "tma_requests": get(metrics, "l1tex__tmain_requests.sum"),
                "tma_l2_read_gb": (
                    get_bytes(metrics, "l1tex__m_xbar2l1tex_read_bytes_mem_global_op_tma_ld.sum") / 1e9
                    if get_bytes(metrics, "l1tex__m_xbar2l1tex_read_bytes_mem_global_op_tma_ld.sum") is not None
                    else None
                ),
                "tma_replay_requests": get(
                    metrics,
                    "l1tex__m_l1tex2xbar_read_requests_replayed_mem_global_op_tma_ld_dest_multicast.sum",
                ),
                "lts_read_requests": get(metrics, "lts__t_requests_aperture_device_op_read.sum"),
                "lts_read_hit_requests": get(metrics, "lts__t_requests_aperture_device_op_read_lookup_hit.sum"),
                "lts_read_miss_requests": get(metrics, "lts__t_requests_aperture_device_op_read_lookup_miss.sum"),
            }
        )

    if not rows:
        raise SystemExit(f"No fa4_*.csv files found in {out_dir}")

    print(
        "pattern,time_ms,gpc_clock_ghz,dram_read_gb,dram_write_gb,hbm_per_sparse_block_kb,"
        "l2_hit_pct,tensor_active_pct,tma_active_pct,sm_sol_pct,dram_sol_pct,l2_sol_pct,"
        "long_scoreboard_pct,membar_pct,barrier_pct,gmma_wait_pct,mio_throttle_pct,"
        "tex_throttle_pct,lg_throttle_pct,short_scoreboard_pct,wait_pct,no_instruction_pct,"
        "not_selected_pct,tensor_inst,gmma_inst,sass_gmma_inst,tma_requests,tma_l2_read_gb,"
        "tma_replay_requests,lts_read_requests,lts_read_hit_requests,lts_read_miss_requests"
    )
    for row in rows:
        print(
            ",".join(
                row["pattern"] if key == "pattern" else "" if row[key] is None else f"{row[key]:.4f}"
                for key in row
            )
        )

    by_pattern = {row["pattern"]: row for row in rows}
    random = by_pattern.get("random")
    shared = by_pattern.get("regular_shared")
    if random and shared and random["time_ms"] and shared["time_ms"]:
        time_gap = random["time_ms"] / shared["time_ms"]
        dram_gap = None
        if random["dram_read_gb"] and shared["dram_read_gb"]:
            dram_gap = random["dram_read_gb"] / shared["dram_read_gb"]
        print("\nInterpretation:")
        print(f"- random/shared time ratio: {time_gap:.3f}x")
        if dram_gap is not None:
            print(f"- random/shared DRAM read ratio: {dram_gap:.3f}x")
        print(
            "- If DRAM read and L2 hit change by orders of magnitude while sparse-block count is fixed, "
            "FA4 is memory-system sensitive on this GPU."
        )
        print(
            "- If time barely changes despite large DRAM differences, the kernel is mostly compute/pipe limited "
            "for this shape and HBM latency is hidden by FA4's async pipeline."
        )
        print(
            "- If random has much higher DRAM SOL/L2 SOL or long scoreboard and higher time, the case is HBM/L2-bound."
        )

    baseline = shared or min((row for row in rows if row["time_ms"]), key=lambda r: r["time_ms"], default=None)
    if baseline and baseline["time_ms"]:
        print("\nFixed-clock memory-bound knee candidates:")
        print("- Definition used here: same sparse-block count, but time >= baseline * {1.02, 1.05}.")
        sorted_rows = sorted(
            (row for row in rows if row["time_ms"] and row["l2_hit_pct"] is not None),
            key=lambda r: r["l2_hit_pct"],
            reverse=True,
        )
        for threshold in (1.02, 1.05):
            candidate = next((row for row in sorted_rows if row["time_ms"] / baseline["time_ms"] >= threshold), None)
            if candidate:
                ratio = candidate["time_ms"] / baseline["time_ms"]
                print(
                    f"- >= {threshold:.2f}x time: first seen at pattern={candidate['pattern']}, "
                    f"L2 hit={candidate['l2_hit_pct']:.2f}%, "
                    f"HBM/block={candidate['hbm_per_sparse_block_kb']:.2f} KB, "
                    f"DRAM SOL={candidate['dram_sol_pct']:.2f}%, "
                    f"time_ratio={ratio:.4f}x"
                )
            else:
                print(f"- >= {threshold:.2f}x time: not reached in this sweep.")

        print(
            "- If no fixed-clock knee appears even at low L2 hit, then for this FA4 shape the extra "
            "HBM traffic is overlapped; default-boost speedups are likely DVFS/power-state effects."
        )


if __name__ == "__main__":
    main()
