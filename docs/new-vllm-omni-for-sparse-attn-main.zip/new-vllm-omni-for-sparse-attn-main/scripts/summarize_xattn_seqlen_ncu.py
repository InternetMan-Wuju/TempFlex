#!/usr/bin/env python3
"""Summarize XAttention dump sequence-length NCU sweep results."""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

from summarize_fa4_hbm_ncu import get, get_bytes, read_metrics, unit_scale_to_ms


def parse_result_csv(log_path: Path) -> dict[str, str]:
    header = None
    result = None
    with log_path.open(errors="replace") as f:
        for line in f:
            if line.startswith("RESULT_CSV,"):
                values = line.rstrip("\n").split(",")[1:]
                if header is None:
                    # Current ncu_xattn_qkv_reorder.py prints RESULT_CSV values
                    # in this exact field order.
                    header = [
                        "dump",
                        "orig_len",
                        "padded_len",
                        "seq_len",
                        "heads",
                        "blocks",
                        "threshold",
                        "method",
                        "density",
                        "avg_nnz_per_row",
                        "sparse_blocks",
                        "reorder_ms",
                        "mask_ms",
                        "kernel_ms",
                        "dram_read",
                        "dram_write",
                        "l2_hit",
                        "wave_nnz_cv",
                        "wave_nnz_range",
                        "wave_reuse",
                    ]
                result = dict(zip(header, values))

    if result is None:
        # Fallback for older logs.
        text = log_path.read_text(errors="replace")
        m_shape = re.search(r"Mask shape=\((\d+),\s*(\d+),\s*(\d+)\).*density=([0-9.]+).*avg_nnz=([0-9.]+)", text)
        m_loaded = re.search(r"B=(\d+)\s+H=(\d+).*padded_len=(\d+)\s+MB=(\d+)", text)
        if not (m_shape and m_loaded):
            raise ValueError(f"Could not parse RESULT_CSV from {log_path}")
        heads, blocks, _, density, avg_nnz = m_shape.groups()
        _, _, seq_len, _ = m_loaded.groups()
        result = {
            "dump": "",
            "orig_len": "",
            "padded_len": seq_len,
            "seq_len": seq_len,
            "heads": heads,
            "blocks": blocks,
            "threshold": "",
            "method": "",
            "density": density,
            "avg_nnz_per_row": avg_nnz,
            "sparse_blocks": str(int(round(float(heads) * float(blocks) * float(avg_nnz)))),
            "kernel_ms": "",
        }
    return result


def f(row: dict[str, str], key: str, default: float = 0.0) -> float:
    value = row.get(key, "")
    return default if value == "" else float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--peak-tflops", type=float, default=989.5)
    parser.add_argument("--peak-gbps", type=float, default=3350.0)
    parser.add_argument(
        "--time-knee-ratio",
        type=float,
        default=1.05,
        help="Fixed-clock memory-sensitive knee if time/model_compute_time exceeds baseline by this ratio.",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    rows = []
    for csv_path in sorted(out_dir.glob("xattn_*.csv")):
        stem = csv_path.stem
        log_path = out_dir / f"{stem}.log"
        if not log_path.exists():
            continue
        py = parse_result_csv(log_path)
        ncu = read_metrics(csv_path)

        time_item = ncu.get("gpu__time_duration.sum")
        time_ms = time_item[0] * unit_scale_to_ms(time_item[1]) if time_item else f(py, "kernel_ms")
        gpc_cycles = get(ncu, "gpc__cycles_elapsed.avg")
        gpc_clock_ghz = gpc_cycles / (time_ms * 1e6) if gpc_cycles is not None and time_ms else None
        dram_read = get_bytes(ncu, "dram__bytes_read.sum")
        dram_write = get_bytes(ncu, "dram__bytes_write.sum")
        sparse_blocks = f(py, "sparse_blocks")
        block_size = 128
        dim = 128
        flops = sparse_blocks * 4.0 * block_size * block_size * dim
        approx_tflops = flops / 1e12
        achieved_tflops = approx_tflops / (time_ms / 1000.0) if time_ms else None
        hbm_per_block = dram_read / sparse_blocks if dram_read is not None and sparse_blocks else None
        oi_flop_per_byte = flops / dram_read if dram_read else None
        compute_roof_ms = approx_tflops / args.peak_tflops * 1000.0
        memory_roof_ms = (dram_read / 1e9) / args.peak_gbps * 1000.0 if dram_read else None
        roofline_bound = (
            "memory" if memory_roof_ms is not None and memory_roof_ms > compute_roof_ms else "compute"
        )
        rows.append(
            {
                "name": stem,
                "seq_len": f(py, "seq_len"),
                "blocks": f(py, "blocks"),
                "heads": f(py, "heads"),
                "threshold": f(py, "threshold"),
                "method": py.get("method", ""),
                "density": f(py, "density"),
                "avg_nnz": f(py, "avg_nnz_per_row"),
                "sparse_blocks": sparse_blocks,
                "time_ms": time_ms,
                "gpc_clock_ghz": gpc_clock_ghz,
                "approx_tflops": approx_tflops,
                "achieved_tflops": achieved_tflops,
                "dram_read_gb": dram_read / 1e9 if dram_read else None,
                "dram_write_gb": dram_write / 1e9 if dram_write else None,
                "hbm_per_block_kb": hbm_per_block / 1024 if hbm_per_block else None,
                "oi_flop_per_byte": oi_flop_per_byte,
                "l2_hit_pct": get(ncu, "lts__t_sector_hit_rate.pct"),
                "dram_sol_pct": get(ncu, "gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed"),
                "l2_sol_pct": get(ncu, "lts__throughput.avg.pct_of_peak_sustained_elapsed"),
                "sm_sol_pct": get(ncu, "sm__throughput.avg.pct_of_peak_sustained_elapsed"),
                "tensor_active_pct": (
                    get(ncu, "sm__pipe_tensor_op_hmma_cycles_active.avg.pct_of_peak_sustained_elapsed")
                    or get(ncu, "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed")
                ),
                "long_scoreboard_pct": get(ncu, "smsp__warp_issue_stalled_long_scoreboard_per_warp_active.pct"),
                "membar_pct": get(ncu, "smsp__warp_issue_stalled_membar_per_warp_active.pct"),
                "gmma_wait_pct": get(ncu, "smsp__warp_issue_stalled_gmma_per_warp_active.pct"),
                "compute_roof_ms": compute_roof_ms,
                "memory_roof_ms": memory_roof_ms,
                "roofline_bound": roofline_bound,
            }
        )

    rows.sort(key=lambda r: (r["seq_len"], r["threshold"]))
    if not rows:
        raise SystemExit(f"No xattn_*.csv + .log pairs found in {out_dir}")

    fields = [
        "seq_len",
        "blocks",
        "threshold",
        "method",
        "density",
        "avg_nnz",
        "sparse_blocks",
        "time_ms",
        "gpc_clock_ghz",
        "approx_tflops",
        "achieved_tflops",
        "dram_read_gb",
        "hbm_per_block_kb",
        "oi_flop_per_byte",
        "l2_hit_pct",
        "dram_sol_pct",
        "l2_sol_pct",
        "sm_sol_pct",
        "tensor_active_pct",
        "long_scoreboard_pct",
        "membar_pct",
        "gmma_wait_pct",
        "compute_roof_ms",
        "memory_roof_ms",
        "roofline_bound",
    ]
    print(",".join(fields))
    for row in rows:
        values = []
        for key in fields:
            value = row[key]
            if isinstance(value, str):
                values.append(value)
            elif value is None:
                values.append("")
            else:
                values.append(f"{value:.4f}")
        print(",".join(values))

    print("\nInterpretation:")
    print(
        f"- Roofline uses peak_tflops={args.peak_tflops:.1f}, peak_gbps={args.peak_gbps:.1f}. "
        "Override these for H100 SXM/NVL/H200/fixed-clock analysis."
    )
    first_roof_mem = next((row for row in rows if row["roofline_bound"] == "memory"), None)
    if first_roof_mem:
        print(
            f"- First roofline-memory case: seq_len={first_roof_mem['seq_len']:.0f}, "
            f"L2 hit={first_roof_mem['l2_hit_pct']:.2f}%, "
            f"HBM/block={first_roof_mem['hbm_per_block_kb']:.2f} KB, "
            f"OI={first_roof_mem['oi_flop_per_byte']:.2f} flop/B."
        )
    else:
        print("- No roofline-memory case under the supplied peak assumptions.")

    # Fixed-clock practical knee: normalize out sparse FLOPs using compute roof.
    normalized = [
        (row, row["time_ms"] / row["compute_roof_ms"])
        for row in rows
        if row["time_ms"] and row["compute_roof_ms"]
    ]
    if normalized:
        base = min(value for _, value in normalized)
        knee = next((row for row, value in normalized if value / base >= args.time_knee_ratio), None)
        if knee:
            print(
                f"- First fixed-clock time knee >= {args.time_knee_ratio:.2f}x normalized compute baseline: "
                f"seq_len={knee['seq_len']:.0f}, L2 hit={knee['l2_hit_pct']:.2f}%, "
                f"DRAM SOL={knee['dram_sol_pct']:.2f}%, HBM/block={knee['hbm_per_block_kb']:.2f} KB."
            )
        else:
            print(
                f"- No fixed-clock time knee >= {args.time_knee_ratio:.2f}x normalized compute baseline. "
                "If clocks were locked, this means the extra traffic is still mostly overlapped."
            )


if __name__ == "__main__":
    main()
